@echo off
cd /d "%~dp0"
if not exist venv ( python -m venv venv )
call venv\Scripts\activate
pip install -r requirements.txt
pip install pyinstaller
pyinstaller --noconfirm --onedir --windowed --name JARVIS ^
  --add-data "tools;tools" --add-data "gui/web;gui/web" ^
  --collect-all speech_recognition --collect-all webview ^
  --hidden-import pyttsx3.drivers --hidden-import pyttsx3.drivers.sapi5 ^
  --collect-submodules uvicorn --collect-submodules websockets --hidden-import fastapi --hidden-import pyautogui --hidden-import pygetwindow ^
  --hidden-import pyperclip --hidden-import psutil --hidden-import comtypes --hidden-import pycaw.pycaw ^
  main_web.py
echo.
echo Done: dist\JARVIS\JARVIS.exe  (put your .env next to JARVIS.exe)
pause
