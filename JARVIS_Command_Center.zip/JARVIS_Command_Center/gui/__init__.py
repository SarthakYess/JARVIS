"""JARVIS GUI."""
