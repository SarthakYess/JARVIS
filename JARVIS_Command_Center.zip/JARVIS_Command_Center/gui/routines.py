"""Voice routines: custom phrases that run a list of steps ("jarvis start", "jarvis game", ...).

Hooked in from main_web.py by wrapping router.process, so core/ and tools/ are untouched.
Routines are edited in the HUD (Settings -> Voice Routines) and stored in data/store.json.

Step types (v = main value, v2 = optional extra):
  open         v = app name, .exe/.lnk path, folder, or URL   (URLs open in Chrome when available)
  close_all    v = comma list of window-title keywords to KEEP; v2 = "ask" to confirm by voice first
  wait         v = seconds
  click_xy     v = "x,y" screen position (use Record position in Settings)
  click_image  v = path to a PNG of the button; v2 = seconds to keep looking (default 20)
  key          v = key or combo, e.g. "enter" or "ctrl+shift+t"
  type         v = text to type into the active window
  say          v = sentence for JARVIS to speak
"""
import logging
import os
import re
import shutil
import subprocess
import time
import webbrowser
from pathlib import Path
from typing import Optional

import config
from core import tool_registry

log = logging.getLogger("jarvis.routines")
_WORDS = re.compile(r"[^a-z0-9' ]+")


def normalize(text: str) -> str:
    text = config.WAKE_WORD_PATTERN.sub(" ", text.lower())
    text = _WORDS.sub(" ", text)
    text = re.sub(r"\b(please|sir)\b", " ", text)
    return re.sub(r"\s+", " ", text).strip()


class RoutineEngine:
    def __init__(self, assistant, store, window) -> None:
        self.a, self.store, self.window = assistant, store, window

    # ------------------------------------------------------------- matching
    def match(self, command: str) -> Optional[dict]:
        heard = normalize(command)
        if not heard:
            return None
        best, best_len = None, 0
        for routine in self.store.data.get("routines", []):
            for phrase in routine.get("phrases", []):
                p = normalize(phrase)
                if not p:
                    continue
                hit = heard == p or (" " in p and re.search(rf"\b{re.escape(p)}\b", heard))
                if hit and len(p) > best_len:
                    best, best_len = routine, len(p)
        return best

    # ------------------------------------------------------------ execution
    def run(self, routine: dict) -> None:
        name = routine.get("name", "routine")
        steps = routine.get("steps", [])
        log.info("ROUTINE %s (%d steps)", name, len(steps))
        self.a._ui(f"Routine: {name}", "info")
        self.a.say(f"Starting {name}, sir.")
        for i, step in enumerate(steps, 1):
            kind, v, v2 = step.get("type", ""), str(step.get("v", "")).strip(), str(step.get("v2", "")).strip()
            try:
                if not self._step(kind, v, v2):
                    self.a._ui(f"Routine stopped at step {i} ({kind}).", "warn")
                    return
            except Exception as exc:
                log.exception("routine step failed")
                self.a._ui(f"Step {i} ({kind} {v}) failed: {exc}", "error")
        self.a.say(f"{name} is done, sir.")

    def _step(self, kind: str, v: str, v2: str) -> bool:
        if kind == "open":
            self._open(v)
        elif kind == "wait":
            time.sleep(max(0.0, min(float(v or 1), 120)))
        elif kind == "say":
            self.a.say(v)
        elif kind == "close_all":
            return self._close_all(v, v2)
        elif kind in ("click_xy", "click_image", "key", "type"):
            return self._input(kind, v, v2)
        else:
            self.a._ui(f"Unknown step type: {kind}", "warn")
        return True

    # ----------------------------------------------------------------- open
    def _open(self, target: str) -> None:
        if not target:
            return
        self.a._ui(f"Opening {target}", "info")
        if re.match(r"https?://", target, re.I):
            if shutil.which("chrome") or self._chrome_exists():
                subprocess.Popen(f'start "" chrome "{target}"', shell=True)
            else:
                webbrowser.open(target)
            return
        path = Path(os.path.expandvars(target)).expanduser()
        if path.exists():
            os.startfile(str(path))  # Windows only, like the rest of JARVIS
            return
        from tools import open_app  # known apps: chrome, vs code, terminal, explorer ...
        known = open_app.ALIASES.get(target.lower(), target.lower())
        if known in open_app.APPS:
            tool_registry.run_tool("open_app", {"name": target})
            return
        lnk = self._find_shortcut(target)
        if lnk:
            os.startfile(str(lnk))
        elif shutil.which(target):
            subprocess.Popen([shutil.which(target)])
        else:
            subprocess.Popen(f'start "" "{target}"', shell=True)  # last resort: Windows resolves it

    @staticmethod
    def _chrome_exists() -> bool:
        return any(Path(os.environ.get(k, "")).joinpath("Google/Chrome/Application/chrome.exe").exists()
                   for k in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"))

    @staticmethod
    def _find_shortcut(name: str) -> Optional[Path]:
        """Search Start Menu and Desktop shortcuts so 'TLauncher' works without a full path."""
        roots = [os.environ.get("APPDATA", "") + r"\Microsoft\Windows\Start Menu\Programs",
                 os.environ.get("PROGRAMDATA", "") + r"\Microsoft\Windows\Start Menu\Programs",
                 str(Path.home() / "Desktop"), os.environ.get("PUBLIC", "") + r"\Desktop"]
        wanted = name.lower().replace(" ", "")
        for root in roots:
            if root and Path(root).exists():
                for lnk in Path(root).rglob("*.lnk"):
                    if wanted in lnk.stem.lower().replace(" ", ""):
                        return lnk
        return None

    # ------------------------------------------------------------ close all
    def _close_all(self, keep_csv: str, mode: str) -> bool:
        import pygetwindow as gw
        keep = [k.strip().lower() for k in keep_csv.split(",") if k.strip()] + ["jarvis", "program manager"]
        targets = [w for w in gw.getAllWindows()
                   if w.title.strip() and w.visible and not any(k in w.title.lower() for k in keep)]
        if not targets:
            return True
        if mode == "ask" and not self.a.confirm(f"This will close {len(targets)} windows. Shall I proceed, sir?"):
            self.a.say("Understood, cancelled.")
            return False
        for w in targets:
            try:
                w.close()  # normal close request: apps can still ask to save
            except Exception:
                log.info("could not close %r", w.title)
        self.a._ui(f"Asked {len(targets)} windows to close.", "info")
        time.sleep(1.5)
        return True

    # --------------------------------------------------------- mouse / keys
    def _input(self, kind: str, v: str, v2: str) -> bool:
        import pyautogui
        pyautogui.FAILSAFE = True  # slam the mouse into a screen corner to abort
        if kind == "click_xy":
            m = re.match(r"\s*(\d+)\s*[, ]\s*(\d+)", v)
            if not m or (m.group(1), m.group(2)) == ("0", "0"):
                self.a._ui("Click position not set. Settings -> Voice Routines -> Record position.", "warn")
                return True
            pyautogui.click(int(m.group(1)), int(m.group(2)))
        elif kind == "click_image":
            if not v or not Path(v).exists():
                self.a._ui("Click image not set. Save a screenshot of the button and put its path in Settings.", "warn")
                return True
            deadline = time.time() + float(v2 or 20)
            while time.time() < deadline:
                try:
                    try:
                        spot = pyautogui.locateCenterOnScreen(v, confidence=0.8)  # needs opencv-python
                    except (TypeError, NotImplementedError):
                        spot = pyautogui.locateCenterOnScreen(v)
                except Exception:  # ImageNotFoundException on newer pyautogui
                    spot = None
                if spot:
                    pyautogui.click(spot.x, spot.y)
                    return True
                time.sleep(1)
            self.a._ui("Could not find the button on screen.", "warn")
            return False
        elif kind == "key":
            pyautogui.hotkey(*[k.strip() for k in v.lower().split("+") if k.strip()])
        elif kind == "type":
            pyautogui.write(v, interval=0.02)
        return True
