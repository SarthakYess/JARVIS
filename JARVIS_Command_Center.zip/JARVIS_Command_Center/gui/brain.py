"""The 'brain' layer between speech and the original router (core/ and tools/ stay untouched).

Order for every command:  voice routines -> natural-language rules -> original router.
Unknown, non-question commands go to the AI planner instead of "should I create a tool?".
Also: real tool tracking/enable-disable, persistent memory, Groq Whisper for commands, tap-to-speak.
"""
import logging
import os
import re
import time
import uuid
import base64
import io
import json
import os
import datetime as dt
import threading
from pathlib import Path
from typing import Callable, Optional

import config
from core import tool_registry
from gui.stt import WhisperSTT
from tools import browser

log = logging.getLogger("jarvis.brain")

# ---- speech clean-up -------------------------------------------------------------------------
MISHEARD = [
    (r"\b(?:you[\s-]?tube|u[\s-]?tube|youtub|yootube)\b", "youtube"),
    (r"\b(?:crome|chrom|krome|google chrome)\b", "chrome"),
    (r"\bchat[\s-]?(?:g[\s-]?p[\s-]?t|gpt|gbt|gp t)\b", "chatgpt"),
    (r"\b(?:clawed|clawd|claud|cloud ai)\b", "claude"),
    (r"\b(?:v\.?\s?s\.?\s?code|visual studio code|vs-code)\b", "vs code"),
    (r"\b(?:t[\s-]?launcher|tee launcher|tea launcher)\b", "tlauncher"),
    (r"\bwhats[\s-]?app\b", "whatsapp"),
    (r"\binsta[\s-]?gram\b", "instagram"),
    (r"\bgit[\s-]?hub\b", "github"),
    (r"\bnote[\s-]?pad\b", "notepad"),
]
POLITE_START = re.compile(
    r"^(?:(?:hey|hi|hello|ok|okay|please|kindly|can you|could you|would you|will you|i want you to|i want to|"
    r"i would like you to|i'd like you to|i need you to|just|now|and|then)\s+)+", re.I)
POLITE_END = re.compile(r"(?:\s+(?:for me|please|now|right now|sir))+$", re.I)


def clean(text: str) -> str:
    text = config.WAKE_WORD_PATTERN.sub(" ", text.strip().lower().replace("’", "'"))
    text = re.sub(r"[^\w\s'.\-]", " ", text)
    for pattern, replacement in MISHEARD:
        text = re.sub(pattern, replacement, text)
    text = re.sub(r"\s+", " ", text).strip(" .")
    text = POLITE_START.sub("", text)
    return POLITE_END.sub("", text).strip(" .")


# name -> (lat, lon). Used by "show me Tokyo" -> globe focus. Countries use their capital/centre.
CITIES = {
    "tokyo": (35.68, 139.69), "japan": (36.2, 138.25), "delhi": (28.61, 77.21), "new delhi": (28.61, 77.21),
    "india": (22.5, 79.0), "mumbai": (19.08, 72.88), "kurukshetra": (29.97, 76.88), "chandigarh": (30.73, 76.78),
    "brazil": (-10.0, -52.0), "sao paulo": (-23.55, -46.63), "rio": (-22.9, -43.17), "london": (51.51, -0.13),
    "uk": (54.0, -2.0), "paris": (48.86, 2.35), "france": (46.6, 2.2), "berlin": (52.52, 13.4), "germany": (51.0, 10.4),
    "new york": (40.71, -74.0), "usa": (39.8, -98.6), "america": (39.8, -98.6), "san francisco": (37.77, -122.42),
    "los angeles": (34.05, -118.24), "canada": (56.1, -106.3), "toronto": (43.65, -79.38), "mexico": (23.6, -102.5),
    "sydney": (-33.87, 151.21), "australia": (-25.3, 133.8), "china": (35.9, 104.2), "beijing": (39.9, 116.4),
    "shanghai": (31.23, 121.47), "dubai": (25.2, 55.27), "singapore": (1.35, 103.82), "moscow": (55.75, 37.62),
    "russia": (61.5, 105.3), "cairo": (30.04, 31.24), "egypt": (26.8, 30.8), "africa": (1.0, 17.0),
    "nigeria": (9.08, 8.68), "south africa": (-30.6, 22.9), "cape town": (-33.92, 18.42), "europe": (50.0, 15.0),
    "asia": (34.0, 100.0), "antarctica": (-80.0, 0.0), "pakistan": (30.4, 69.3), "nepal": (28.4, 84.1),
    "italy": (42.8, 12.6), "rome": (41.9, 12.5), "spain": (40.4, -3.7), "seoul": (37.57, 126.98),
    "korea": (36.5, 127.9), "indonesia": (-2.5, 118.0), "argentina": (-38.4, -63.6), "earth": (20.0, 0.0),
}
GLOBE = re.compile(r"^(?:show me|show|focus on|focus|go to|zoom (?:in )?(?:on|to)|spin (?:the )?(?:globe|earth) to|where is)\s+(.+?)(?:\s+on (?:the )?(?:globe|earth|map))?$")

YT = r"youtube"
RULES = [  # (name, regex) checked in order; the first match wins
    ("remember", re.compile(r"^(?:remember|memorize|note down|take a note|make a note|note)(?: that| this)?[ ,:]+(.+)$")),
    ("recall", re.compile(r"^(?:what do you (?:remember|know) about me|what do you remember|show (?:me )?(?:my )?memor(?:y|ies)|list (?:my )?memor(?:y|ies))")),
    ("yt_open_do", re.compile(rf"^(?:open|go to|launch)\s+{YT}(?:\s+(?:and|then))?\s+(play|search(?: for)?)\s+(.+)$")),
    ("yt_play", re.compile(rf"^(?:play|put on|start playing|stream)\s+(.+?)(?:\s+(?:on|in|from|using)\s+{YT})?$")),
    ("yt_search", re.compile(rf"^(?:search|find|look up|look for|show me)\s+(.+?)\s+(?:on|in)\s+{YT}$")),
    ("yt_search2", re.compile(rf"^(?:search\s+{YT}\s+for|{YT}\s+search(?:\s+for)?|{YT}\s+for)\s+(.+)$")),
    ("google", re.compile(r"^(?:google|search(?: google| the web| online)?(?: for)?|look up|look for)\s+(.+?)"
                          r"(?:\s+(?:on|in|using)\s+(?:google|chrome|the web|web|the internet|internet))?$")),
    ("open", re.compile(r"^(?:open|launch|go to|visit|browse to|start|run)\s+(.+?)"
                        r"(?:\s+(?:in|on|with|using)\s+chrome)?$")),
]
RULE_LABEL = {"remember": "Remember a fact", "recall": "Recall memory", "yt_open_do": "YouTube action",
              "yt_play": "Play on YouTube", "yt_search": "Search YouTube", "yt_search2": "Search YouTube",
              "google": "Google search", "open": "Open app / site"}
FOLDERS = {"downloads": "Downloads", "documents": "Documents", "desktop": "Desktop", "pictures": "Pictures",
           "music": "Music", "videos": "Videos"}


class Brain:
    def __init__(self, assistant, window, engine) -> None:
        self.a, self.w, self.engine = assistant, window, engine
        self.stt = WhisperSTT()
        self.oneshot = False
        self.disabled: set = set()
        self.stats: dict = {}
        self._base_prompt = ""
        self._trace: Optional[dict] = None   # trace of the command being processed (one at a time)
        self._rule = ("", "")
        self._last_cmd = ""

    # ------------------------------------------------------------------ install
    def install(self) -> None:
        router, llm = self.a.router, self.a.llm
        self._orig_process = router.process
        router.process = self.process
        router._no_tool = lambda command: router._use_ai(command)  # AI planner instead of "create a tool?"
        self._orig_run_tool = tool_registry.run_tool
        tool_registry.run_tool = self._tracked_run_tool
        import core.llm as llm_mod
        import core.voice_input as vi
        self._llm_mod, self._base_prompt = llm_mod, llm_mod.ASK_SYSTEM
        orig_ask = llm.ask
        try:  # user-selected TTS voice and speed: same logic as VoiceOutput.speak (fresh engine per call), plus preferences
            import core.voice_output as vo
            from core.voice_output import clean_for_speech, _ensure_com
            vout = self.a.voice_out

            def speak(text: str) -> bool:
                spoken = clean_for_speech(text)
                if not spoken:
                    return True
                with vout._lock:
                    try:
                        import pyttsx3
                        _ensure_com()
                        u = self._ui()
                        engine = pyttsx3.init()
                        engine.setProperty("rate", int(u.get("tts_rate") or config.SPEECH_RATE))
                        engine.setProperty("volume", config.SPEECH_VOLUME)
                        want = u.get("tts_voice")
                        for voice in engine.getProperty("voices") or []:
                            if (want and voice.id == want) or (not want and "david" in (voice.name or "").lower()):
                                engine.setProperty("voice", voice.id)
                                break
                        engine.say(spoken)
                        engine.runAndWait()
                        try:
                            engine.stop()
                        except Exception:
                            pass
                        return True
                    except Exception as exc:
                        vo.log.error("Text to speech failed: %s", exc)
                        vout.beep()
                        return False
            vout.speak = speak
        except Exception:
            pass
        def ask_with_memory(question: str) -> str:
            facts = [m.get("text", "") for m in self.w.store.data["memory"][-25:]]
            llm_mod.ASK_SYSTEM = self._base_prompt + (
                " Facts Sarthak asked you to remember: " + "; ".join(facts) + "." if facts else "")
            return orig_ask(question)

        llm.ask = ask_with_memory
        voice = self.a.voice_in
        vi.END_SILENCE_SECONDS = 1.1  # do not cut the user off mid-sentence

        def listen_once(timeout: float = config.COMMAND_TIMEOUT, phrase_limit: float = config.COMMAND_PHRASE_LIMIT) -> str:
            self.w.emit_voice("listening")
            try:  # wake/listen sensitivity (0-100) lowers or raises the minimum volume that counts as speech
                vi.MIN_THRESHOLD = int(300 * (1.8 - 1.6 * float(self._ui().get("sens", 50)) / 100))
            except Exception:
                pass
            audio = voice.capture(timeout, phrase_limit)
            if audio is None:
                self.w.emit_voice("idle")
                return ""
            self.w.emit_voice("transcribing")
            text = self.stt.transcribe(audio) if (self.stt.available and self._ui().get("stt", "whisper") != "google") else None
            text = text if text is not None else voice.transcribe(audio)  # Google as fallback
            self.w.emit_voice("idle")
            return text

        voice.listen_once = listen_once
        self.w.meta = {"stt": "Groq Whisper" if self.stt.available else "Google (no Groq key)"}
        self.w.brain = self
        self.disabled = {k for k, v in self.w.store.data.get("agents", {}).items() if v is False}

    # -------------------------------------------------------------- tool tracking
    def set_enabled(self, name: str, on: bool) -> None:
        (self.disabled.discard if on else self.disabled.add)(name)

    def _tracked_run_tool(self, name: str, args: dict) -> str:
        if name in self.disabled:
            return f"The {name.replace('_', ' ')} module is switched off, sir."
        info = self.stats.setdefault(name, {"n": 0, "last": 0, "state": "idle"})
        info["state"] = "run"
        self.w.emit_tools(self.stats)
        t0 = time.time()
        try:
            out = self._orig_run_tool(name, args)
            self._trace_tool(name, args, t0, True)
            return out
        except Exception:
            self._trace_tool(name, args, t0, False)
            raise
        finally:
            info.update(n=info["n"] + 1, last=time.time(), state="idle")
            self.w.emit_tools(self.stats)

    # --------------------------------------------------------------- tap / focus
    def listen_now(self) -> None:
        """Tap-to-speak: listen for exactly one command without the wake word."""
        if self.a.mode == "active":
            return
        self.oneshot = True
        self.w.set_oneshot(True)
        self.a._set_mode("active")
        self.w.append_log("Listening... speak your command.", "info")

    def focus_toggle(self) -> None:
        self.oneshot = False
        self.w.set_oneshot(False)
        self.a._set_mode("wake" if self.a.mode == "active" else "active")

    # ------------------------------------------------------------------ routing
    def _trace_tool(self, name: str, args: dict, t0: float, ok: bool) -> None:
        tr = self._trace
        if tr is not None:
            tr["tool"], tr["args"] = name, {k: str(v)[:120] for k, v in (args or {}).items()}
            tr["ms"] = int((time.time() - t0) * 1000)
            if not ok:
                tr["ok"] = False
            self.w.emit_trace(tr)

    def _emit_intent(self, tr: dict, intent: str, tool: str = "", args: Optional[dict] = None) -> None:
        tr.update(intent=intent, tool=tool or tr.get("tool", ""), args=args or tr.get("args", {}), stage="understood")
        self.w.emit_trace(tr)

    def process(self, command: str) -> None:
        tr = {"id": uuid.uuid4().hex[:8], "heard": command, "intent": "", "tool": "", "args": {}, "ms": 0,
              "ok": True, "result": "", "stage": "heard", "ts": time.time()}
        if not command.lower().startswith(("do it again", "do that again", "repeat", "open it again", "run it again", "run that again", "open that again")):
            self._last_cmd = command
        self._trace, t0 = tr, time.time()
        self.w.emit_trace(tr)
        try:
            routine = self.engine.match(command)
            if routine:
                self._emit_intent(tr, f"Voice routine: {routine.get('name', '')}", "routine", {"steps": len(routine.get("steps", []))})
                self.engine.run(routine)
                tr["result"] = f"Routine '{routine.get('name', '')}' finished."
                return
            reply = self.understand(command)
            if reply is None:
                self._emit_intent(tr, "Ask the assistant (router / AI planner)", tr.get("tool", ""), tr.get("args"))
                self._orig_process(command)
                tr["result"] = "Handled by the assistant."
            else:
                if reply:
                    self.a.say(reply)
                tr["result"] = reply or "Done."
        except Exception as exc:
            tr["ok"], tr["result"] = False, f"{type(exc).__name__}: {exc}"[:200]
            raise
        finally:
            tr.update(ms=int((time.time() - t0) * 1000), stage="done")
            self.w.emit_trace(tr)
            self._trace = None
            if self.oneshot:
                self.oneshot = False
                self.w.set_oneshot(False)
                self.a._set_mode("wake")

    # ---------------------------------------------------------------- extra skills (all optional / guarded)
    def _ui(self) -> dict:
        try:
            return self.w.store.data.get("ui", {})
        except Exception:
            return {}

    def extras(self, text: str):
        """Reminders, clipboard summarise/translate, screen description, daily briefing, repeat. Returns reply or None."""
        m = re.match(r"^remind me (?:in (\d+)\s*(second|sec|minute|min|hour|hr)s?|at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?)\s*(?:to|about|that)?\s*(.*)$", text)
        if m:
            now = dt.datetime.now()
            if m.group(1):
                n, u = int(m.group(1)), m.group(2)
                when = now + dt.timedelta(seconds=n) if u.startswith("sec") else now + dt.timedelta(minutes=n * (60 if u.startswith(("hour", "hr")) else 1))
                when += dt.timedelta(seconds=59)  # reminders fire on whole minutes
            else:
                h, mi, ap = int(m.group(3)), int(m.group(4) or 0), m.group(5)
                if ap == "pm" and h < 12: h += 12
                if ap == "am" and h == 12: h = 0
                when = now.replace(hour=h % 24, minute=mi, second=0)
                if when <= now: when += dt.timedelta(days=1)
            title = (m.group(6) or "Reminder").strip().capitalize() or "Reminder"
            self._intent("Set a reminder", "reminder", {"when": when.strftime("%H:%M"), "what": title})
            self.w.store.apply({"op": "add", "coll": "events", "item": {"title": title, "date": when.strftime("%Y-%m-%d"), "time": when.strftime("%H:%M")}})
            self.w._emit({"type": "store", "data": self.w.store.data})
            return f"Reminder set for {when.strftime('%H:%M')}: {title}."
        m = re.match(r"^(summari[sz]e|translate)(?: the)? clipboard(?: (?:to|into) ([a-z ]+))?$", text)
        if m:
            import pyperclip
            try:
                clip = (pyperclip.paste() or "").strip()
            except Exception:
                return "I cannot read the clipboard on this system."
            if not clip:
                return "The clipboard is empty."
            task = f"Summarise this in 3 short sentences:\n{clip[:6000]}" if m.group(1).startswith("summ") else f"Translate this into {m.group(2) or 'English'}. Reply with the translation only:\n{clip[:6000]}"
            self._intent("Clipboard " + m.group(1), "llm", {"chars": len(clip)})
            return self.a.llm.generate_text(task)
        if re.match(r"^(?:what(?:'s| is) on my screen|describe my screen|look at my screen|read my screen)$", text):
            self._intent("Describe the screen", "vision", {})
            return self._screen()
        if re.match(r"^(?:daily briefing|brief me|morning briefing|give me my briefing)$", text):
            self._intent("Daily briefing", "briefing", {})
            d = self.w.store.data; td = dt.date.today().isoformat()
            ev = sorted([e for e in d.get("events", []) if e.get("date") == td], key=lambda e: e.get("time", ""))
            tk = [t for t in d.get("tasks", []) if t.get("done") != "true"]
            parts = [f"It is {dt.datetime.now().strftime('%A, %d %B, %H:%M')}."]
            parts.append(f"You have {len(ev)} event{'s' * (len(ev) != 1)} today" + (": " + ", ".join(f"{e.get('time', '')} {e['title']}" for e in ev[:4]) if ev else "") + ".")
            parts.append(f"{len(tk)} open task{'s' * (len(tk) != 1)}.")
            try:
                import psutil
                b = psutil.sensors_battery()
                if b: parts.append(f"Battery is at {int(b.percent)} percent.")
            except Exception:
                pass
            return " ".join(parts)
        if re.match(r"^(?:do|open|run) (?:it|that) again$|^repeat (?:that|the last command)$", text):
            if self._last_cmd:
                self._intent("Repeat the last command", "repeat", {"command": self._last_cmd})
                self.process(self._last_cmd)
                return ""
            return "There is nothing to repeat yet."
        return None

    def _intent(self, intent: str, tool: str, args: dict) -> None:
        if self._trace is not None:
            self._emit_intent(self._trace, intent, tool, args)

    def _screen(self) -> str:
        try:
            from PIL import ImageGrab
            import requests, config as cfg
            keys = list(getattr(cfg, "GROQ_API_KEYS", []) or [])
            if not keys:
                return "I need a Groq API key to look at the screen."
            img = ImageGrab.grab(); img.thumbnail((1280, 1280))
            buf = io.BytesIO(); img.convert("RGB").save(buf, "JPEG", quality=70)
            b64 = base64.b64encode(buf.getvalue()).decode()
            model = os.getenv("JARVIS_VISION_MODEL", "meta-llama/llama-4-scout-17b-16e-instruct")
            r = requests.post("https://api.groq.com/openai/v1/chat/completions", timeout=40, headers={"Authorization": "Bearer " + keys[0]},
                json={"model": model, "max_tokens": 300, "messages": [{"role": "user", "content": [{"type": "text", "text": "Describe what is on this screen in 3 short sentences."},
                      {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + b64}}]}]})
            if r.status_code != 200:
                return f"The vision model returned {r.status_code}. Set JARVIS_VISION_MODEL in .env to a vision model you have access to."
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as exc:
            return f"I could not read the screen: {type(exc).__name__}."

    def understand(self, raw: str) -> Optional[str]:
        """Return the reply when a rule handled the command, '' when handled silently, None when not handled."""
        text = clean(raw)
        if not text:
            return None
        ex = self.extras(text)
        if ex is not None:
            return ex
        g = GLOBE.match(text)
        if g and g.group(1).strip() in CITIES:
            place = g.group(1).strip()
            lat, lon = CITIES[place]
            self.w.emit_globe(place, lat, lon)
            if self._trace is not None:
                self._emit_intent(self._trace, f"Show {place.title()} on the globe", "globe", {"place": place})
            return f"Showing {place.title()}."
        for name, pattern in RULES:
            m = pattern.match(text)
            if not m:
                continue
            if self._trace is not None:
                self._emit_intent(self._trace, RULE_LABEL.get(name, name), "", {"match": [x.strip() for x in m.groups() if x]})
            try:
                return getattr(self, "_do_" + name)(*[g.strip() for g in m.groups() if g])
            except Exception as exc:
                log.exception("rule %s failed", name)
                return f"Sorry sir, that failed: {type(exc).__name__}."
        return None

    # ------------------------------------------------------------------ actions
    def _run(self, fn: Callable[[str], str], arg: str) -> str:
        if "browser" in self.disabled:
            return "The browser module is switched off, sir."
        info = self.stats.setdefault("browser", {"n": 0, "last": 0, "state": "idle"})
        info["state"] = "run"
        self.w.emit_tools(self.stats)
        t0 = time.time()
        try:
            out = fn(arg)
            self._trace_tool("browser", {"query": arg}, t0, True)
            return out
        except Exception:
            self._trace_tool("browser", {"query": arg}, t0, False)
            raise
        finally:
            info.update(n=info["n"] + 1, last=time.time(), state="idle")
            self.w.emit_tools(self.stats)

    def _do_yt_play(self, query: str) -> str:
        return self._run(browser.youtube_play, query)

    def _do_yt_open_do(self, verb: str, query: str) -> str:
        return self._run(browser.youtube_play if verb.startswith("play") else browser.youtube_search, query)

    def _do_yt_search(self, query: str) -> str:
        return self._run(browser.youtube_search, query)

    _do_yt_search2 = _do_yt_search

    def _do_google(self, query: str) -> str:
        return self._run(browser.google, query)

    def _do_open(self, name: str) -> Optional[str]:
        name = re.sub(r"^(?:the|my|up)\s+", "", name).strip()
        if name in FOLDERS:
            folder = str(Path.home() / FOLDERS[name])
            if hasattr(os, "startfile"):
                os.startfile(folder)  # Windows
            else:
                import subprocess
                subprocess.Popen(["xdg-open", folder])
            return f"Opening {name}."
        url = browser.resolve_site(name)
        if url:
            return self._run(lambda _: (browser.open_url(url), f"Opening {name}.")[1], name)
        from tools import open_app
        known = open_app.ALIASES.get(name, name)
        if known in open_app.APPS:
            return None  # the original open_app tool handles built-in apps (and focuses the window)
        self.a._ui(f"Opening {name}", "info")
        self.engine._open(name)  # Start Menu / Desktop shortcut search, paths, last-resort start
        return f"Opening {name}."

    def _remember(self, text: str) -> None:
        self.w.store.apply({"op": "add", "coll": "memory", "item": {"text": text}})
        self.w._emit({"type": "store", "data": self.w.store.data})

    def _do_remember(self, fact: str) -> str:
        self._remember(fact)
        return "Noted, sir. I will remember that."

    def _do_recall(self) -> str:
        facts = [m.get("text", "") for m in self.w.store.data["memory"][-5:]]
        if not facts:
            return "You haven't asked me to remember anything yet, sir."
        self.a.show("Memory:\n- " + "\n- ".join(facts))
        return "Here is what I remember, sir: " + "; ".join(facts)
