"""Windows desktop integration: global Ctrl+Space summon, tray icon, start-with-Windows. Every part is optional and guarded."""
import logging, os, sys, threading
log = logging.getLogger("jarvis.desktop")
RUN_KEY, RUN_NAME = r"Software\Microsoft\Windows\CurrentVersion\Run", "JARVIS Command Center"

def startup_enabled() -> bool:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, RUN_NAME); return True
    except Exception:
        return False

def set_startup(on: bool, main_script: str) -> bool:
    try:
        import winreg
        py = sys.executable.replace("python.exe", "pythonw.exe")
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, RUN_NAME, 0, winreg.REG_SZ, f'"{py}" "{main_script}"')
            else:
                try: winreg.DeleteValue(k, RUN_NAME)
                except FileNotFoundError: pass
        return True
    except Exception as exc:
        log.warning("startup toggle failed: %s", exc); return False

def start_hotkey(on_press) -> None:
    """Ctrl+Space via RegisterHotKey (no extra dependency). Silently skipped when unavailable or taken."""
    if os.name != "nt":
        return
    def loop():
        try:
            import ctypes
            from ctypes import wintypes
            u = ctypes.windll.user32
            if not u.RegisterHotKey(None, 1, 0x0002 | 0x4000, 0x20):  # MOD_CONTROL|MOD_NOREPEAT, VK_SPACE
                log.warning("Ctrl+Space is already taken by another app"); return
            msg = wintypes.MSG()
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                if msg.message == 0x0312: on_press()
        except Exception:
            log.exception("hotkey failed")
    threading.Thread(target=loop, name="hotkey", daemon=True).start()

def start_tray(on_show, on_quit) -> None:
    try:
        import pystray
        from PIL import Image, ImageDraw
    except Exception:
        return  # pip install pystray to enable the tray icon
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.ellipse((6, 6, 58, 58), outline=(0, 229, 255, 255), width=5); d.ellipse((24, 6, 40, 58), outline=(0, 229, 255, 255), width=3)
    icon = pystray.Icon("JARVIS", img, "JARVIS", pystray.Menu(pystray.MenuItem("Show JARVIS", lambda: on_show(), default=True),
                                                         pystray.MenuItem("Quit", lambda: (icon.stop(), on_quit()))))
    threading.Thread(target=icon.run, name="tray", daemon=True).start()
