"""Accurate command transcription with Groq Whisper (uses your existing Groq keys).

Only used for COMMANDS (after the wake word). Idle wake-word listening still uses the original
recogniser, so it does not burn API quota. If Whisper fails for any reason, the caller falls back to Google.
"""
import logging
import os
import time
from typing import List, Optional

import config

log = logging.getLogger("jarvis.stt")

MODEL = os.getenv("JARVIS_STT_MODEL", "whisper-large-v3-turbo")
# Vocabulary hint: Whisper spells these correctly when it has heard them in the prompt.
PROMPT = ("JARVIS, YouTube, Chrome, ChatGPT, Claude, Gemini, VS Code, TLauncher, Minecraft, Spotify, WhatsApp, "
          "Instagram, GitHub, Windows, Notepad, screenshot, volume, play, open, search, Sarthak.")
HALLUCINATIONS = {"thank you", "thanks", "thanks for watching", "thank you for watching", "you", "bye", "okay",
                  "uh", "um", "hmm", "so", "the", "i", "."}


class WhisperSTT:
    def __init__(self) -> None:
        self.keys: List[str] = list(config.GROQ_API_KEYS)
        self._next = 0
        self._resting: dict = {}
        self._dead: set = set()
        self.last_error = ""

    @property
    def available(self) -> bool:
        return bool(self.keys) and len(self._dead) < len(self.keys)

    def _pick(self) -> Optional[int]:
        now = time.time()
        for _ in range(len(self.keys)):
            i = self._next % len(self.keys)
            self._next += 1
            if i not in self._dead and self._resting.get(i, 0) <= now:
                return i
        return None

    def transcribe(self, audio) -> Optional[str]:
        """Return the transcript ('' when nothing intelligible) or None when Whisper is unavailable."""
        if not self.available:
            return None
        try:
            import groq
        except ImportError:
            return None
        wav = audio.get_wav_data(convert_rate=16000, convert_width=2)
        seconds = max(0.0, (len(wav) - 44) / 32000.0)
        for _ in range(len(self.keys)):
            index = self._pick()
            if index is None:
                break
            try:
                client = groq.Groq(api_key=self.keys[index], timeout=20)
                result = client.audio.transcriptions.create(
                    file=("speech.wav", wav), model=MODEL, language="en", temperature=0.0, prompt=PROMPT,
                    response_format="json")
                text = (getattr(result, "text", "") or "").strip()
                if text.lower().strip(" .,!?") in HALLUCINATIONS and seconds < 1.6:
                    return ""  # Whisper invents "thank you" on near-silence
                log.info("WHISPER (%.1fs, key #%d): %s", seconds, index + 1, text)
                self.last_error = ""
                return text
            except groq.RateLimitError:
                self._resting[index] = time.time() + 60
            except groq.AuthenticationError:
                self._dead.add(index)
            except Exception as exc:  # network problems etc.: let the caller fall back to Google
                self.last_error = type(exc).__name__
                log.warning("Whisper failed: %s", exc)
                return None
        return None
