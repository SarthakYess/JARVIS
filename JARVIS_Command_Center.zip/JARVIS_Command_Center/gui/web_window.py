"""WebWindow: drop-in replacement for gui.app_window.AppWindow.

Exposes the exact methods main.Assistant already calls (set_status, append_log, set_mic,
set_mode, set_submit_callback, protocol, destroy, mainloop) but renders them in the HTML HUD
(gui/web/index.html) over a local WebSocket. The backend is not modified.
"""
import asyncio
import os
import shutil
import socket
import subprocess
import sys
import json
import logging
import threading
import time
import webbrowser
from pathlib import Path
from typing import Callable, Optional

import psutil
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import config
from core import tool_registry
from gui import desktop
from gui.store import Store

log = logging.getLogger("jarvis.web")
WEB_DIR = Path(__file__).resolve().parent / "web"
HOST = "127.0.0.1"


def _free_port(preferred: int = 8765) -> int:
    for port in (preferred, 0):
        with socket.socket() as s:
            try:
                s.bind((HOST, port))
                return s.getsockname()[1]
            except OSError:
                continue
    return preferred


class WebWindow:
    def __init__(self) -> None:
        self.assistant = None            # set by main_web.py (needed for the mic button)
        self._submit: Optional[Callable[[str], None]] = None
        self._on_close: Optional[Callable[[], None]] = None
        self._clients: set = set()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._state = {"status": "Idle", "mic": "wake", "mode": "wake", "oneshot": False}
        self.meta: dict = {"stt": "Google"}
        self.brain = None
        self.tool_stats: dict = {}
        self._feed: list = []            # last events, replayed to a freshly opened UI
        self._done = threading.Event()
        self.port = _free_port()
        self.store = Store()
        self._fired: set = set()
        self._level_on = False
        self._clip_on = False
        self.mic_device = None
        self.app = self._build_app()

    # ---------------------------------------------- AppWindow-compatible API
    def set_submit_callback(self, callback: Callable[[str], None]) -> None:
        self._submit = callback

    def append_log(self, text, tag="info") -> None:
        event = {"type": "log", "text": str(text), "tag": tag, "ts": time.strftime("%H:%M:%S")}
        self._feed = (self._feed + [event])[-80:]
        self._emit(event)

    def set_status(self, status) -> None:
        self._state["status"] = status
        self._emit({"type": "state", **self._state})

    def set_mic(self, state) -> None:
        self._state["mic"] = state
        self._emit({"type": "state", **self._state})

    def set_mode(self, mode) -> None:
        self._state["mode"] = mode
        self._emit({"type": "state", **self._state})

    def set_oneshot(self, flag: bool) -> None:
        self._state["oneshot"] = flag
        self._emit({"type": "state", **self._state})

    def emit_tools(self, stats: dict) -> None:
        self.tool_stats = {k: dict(v) for k, v in stats.items()}
        self._emit({"type": "tools", "stats": self.tool_stats})

    def emit_trace(self, trace: dict) -> None:
        self._emit({"type": "trace", **trace})

    def emit_voice(self, phase: str) -> None:
        """phase: listening | transcribing | idle  (Whisper is batch STT, so there is no word-by-word interim text)."""
        self._emit({"type": "voice", "phase": phase})

    def emit_globe(self, place: str, lat: float, lon: float) -> None:
        self._emit({"type": "globe_focus", "place": place, "lat": lat, "lon": lon})

    def protocol(self, _name: str, callback: Callable[[], None]) -> None:
        self._on_close = callback

    def destroy(self) -> None:
        self._done.set()

    def mainloop(self) -> None:
        """Opens JARVIS as a desktop window and blocks until it is closed."""
        threading.Thread(target=self._serve, name="web-bridge", daemon=True).start()
        threading.Thread(target=self._stats_loop, name="web-stats", daemon=True).start()
        threading.Thread(target=self._reminder_loop, name="web-reminders", daemon=True).start()
        threading.Thread(target=self._media_loop, name="web-media", daemon=True).start()
        threading.Thread(target=self._clip_loop, name="web-clip", daemon=True).start()
        threading.Thread(target=self._level_loop, name="web-level", daemon=True).start()
        for _ in range(50):  # wait until the local server accepts connections
            with socket.socket() as s:
                if s.connect_ex((HOST, self.port)) == 0:
                    break
            time.sleep(0.1)
        url = f"http://{HOST}:{self.port}/"
        try:
            import webview  # native window (Edge WebView2 on Windows)
        except ImportError:
            webview = None
        if webview:
            class Api:
                def fullscreen(self_inner):
                    webview.windows[0].toggle_fullscreen()

                def minimize(self_inner):
                    webview.windows[0].minimize()

                def maximize(self_inner):
                    w = webview.windows[0]
                    (w.restore if getattr(self_inner, "_max", False) else w.maximize)()
                    self_inner._max = not getattr(self_inner, "_max", False)

                def orb(self_inner, on):
                    w = webview.windows[0]
                    if on:
                        w.resize(240, 260); w.on_top = True
                    else:
                        w.on_top = False; w.resize(1440, 860)

                def close(self_inner):
                    webview.windows[0].destroy()

            def summon():
                try:
                    w = webview.windows[0]; w.show(); w.restore(); w.on_top = True; w.on_top = False
                except Exception:
                    pass
            desktop.start_hotkey(summon)
            desktop.start_tray(summon, lambda: (self._on_close and self._on_close(), webview.windows[0].destroy()))
            framed = os.getenv("JARVIS_FRAMED") == "1"   # set JARVIS_FRAMED=1 in .env to get the native title bar back
            webview.create_window("JARVIS Command Center", url, width=1440, height=860, min_size=(1100, 680),
                                  background_color="#02060E", js_api=Api(), frameless=not framed, easy_drag=False)
            webview.start()
        elif self._open_app_window(url):
            self._wait_for_window_close()
        else:
            raise SystemExit("Could not open a window. Run: pip install pywebview")
        if self._on_close:
            self._on_close()

    def _open_app_window(self, url: str) -> bool:
        """Fallback without pywebview: Edge/Chrome 'app mode' = its own window, no tabs or address bar."""
        candidates = [shutil.which("msedge"), shutil.which("chrome")]
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(env, "")
            candidates += [f"{base}/Microsoft/Edge/Application/msedge.exe",
                           f"{base}/Google/Chrome/Application/chrome.exe"]
        for exe in candidates:
            if exe and os.path.exists(exe):
                subprocess.Popen([exe, f"--app={url}", "--window-size=1440,860",
                                  f"--user-data-dir={config.APP_DIR / 'data' / 'webprofile'}"])
                return True
        return False

    def _wait_for_window_close(self) -> None:
        seen, empty_since = False, None
        try:
            while not self._done.is_set():
                if self._clients:
                    seen, empty_since = True, None
                elif seen:
                    empty_since = empty_since or time.time()
                    if time.time() - empty_since > 6:  # window closed (not just a reload)
                        return
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass

    # ------------------------------------------------------------- internals
    def _emit(self, event: dict) -> None:
        """Thread-safe broadcast (the voice loop runs on another thread)."""
        if not self._loop or not self._clients:
            return
        asyncio.run_coroutine_threadsafe(self._broadcast(event), self._loop)

    async def _broadcast(self, event: dict) -> None:
        data = json.dumps(event)
        for ws in list(self._clients):
            try:
                await ws.send_text(data)
            except Exception:
                self._clients.discard(ws)

    def _media_loop(self) -> None:
        """Now playing from the Windows media session. Needs: pip install winrt-runtime winrt-Windows.Media.Control (optional)."""
        if os.name != "nt":
            return
        try:
            import asyncio
            from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as M
        except Exception:
            return
        async def poll():
            mgr, last = await M.request_async(), None
            while not self._done.is_set():
                try:
                    s = mgr.get_current_session()
                    if s and self._clients:
                        p = await s.try_get_media_properties_async()
                        cur = {"title": p.title, "artist": p.artist, "playing": int(s.get_playback_info().playback_status) == 4}
                        if cur != last:
                            last = cur; self._emit({"type": "media", **cur})
                except Exception:
                    pass
                await asyncio.sleep(2)
        asyncio.run(poll())

    def _gpu(self):
        try:
            import pynvml
            if not getattr(self, "_nv", False):
                pynvml.nvmlInit(); self._nv = True
            h = pynvml.nvmlDeviceGetHandleByIndex(0)
            u, m = pynvml.nvmlDeviceGetUtilizationRates(h), pynvml.nvmlDeviceGetMemoryInfo(h)
            try: t = pynvml.nvmlDeviceGetTemperature(h, 0)
            except Exception: t = None
            return {"util": u.gpu, "vram": round(m.used / m.total * 100, 1), "temp": t}
        except Exception:
            return None

    def _clip_loop(self) -> None:
        """Clipboard history, only while the UI widget is switched on (privacy)."""
        last = None
        while not self._done.is_set():
            if self._clip_on:
                try:
                    import pyperclip
                    cur = pyperclip.paste()
                    if cur and cur != last:
                        last = cur
                        self._emit({"type": "clip", "text": cur[:500]})
                except Exception:
                    pass
            time.sleep(1.5)

    def _stats_loop(self) -> None:
        psutil.cpu_percent(None)
        last_net, last_t = psutil.net_io_counters(), time.time()
        cores = psutil.cpu_count() or 1
        while not self._done.is_set():
            try:
                now = time.time()
                net = psutil.net_io_counters()
                dt = max(now - last_t, 0.1)
                down, up = (net.bytes_recv - last_net.bytes_recv) / dt, (net.bytes_sent - last_net.bytes_sent) / dt
                last_net, last_t = net, now
                procs: dict = {}
                for p in psutil.process_iter(["name", "cpu_percent"]):
                    try:
                        n = (p.info["name"] or "?").replace(".exe", "")
                        procs[n] = procs.get(n, 0.0) + (p.info["cpu_percent"] or 0.0) / cores
                    except Exception:
                        continue
                top = sorted(procs.items(), key=lambda kv: kv[1], reverse=True)[:5]
                batt = psutil.sensors_battery()
                self._emit({"type": "stats", "cpu": psutil.cpu_percent(None), "ram": psutil.virtual_memory().percent,
                            "disk": psutil.disk_usage(Path.home().anchor or "/").percent,
                            "down": down, "up": up, "uptime": now - psutil.boot_time(),
                            "batt": batt.percent if batt else None, "plugged": bool(batt and batt.power_plugged),
                            "procs": [[n, round(c, 1)] for n, c in top if n.lower() not in ("system idle process", "idle")],
                            "cores": psutil.cpu_percent(None, percpu=True), "gpu": self._gpu(), "keys": self.key_health()})
            except Exception:
                log.exception("stats failed")
            time.sleep(2)

    def key_health(self) -> list:
        """Per-slot health from core.llm.KeyPool (read only; only slot numbers, never key values)."""
        try:
            pool = self.assistant.llm._pool
            now = time.time()
            out = []
            for i in range(len(pool.keys)):
                if i in pool._dead:
                    out.append({"slot": i + 1, "state": "rejected"})
                elif pool._cooldown.get(i, 0) > now:
                    out.append({"slot": i + 1, "state": "rate-limited", "wait": int(pool._cooldown[i] - now)})
                else:
                    out.append({"slot": i + 1, "state": "ok"})
            return out
        except Exception:
            return [{"slot": i + 1, "state": "ok"} for i in range(len(config.GROQ_API_KEYS))]

    def _level_loop(self) -> None:
        """~10 Hz microphone RMS for the waveform / globe pulse. Own input stream; failure is reported, not hidden."""
        try:
            import numpy as np
            import sounddevice as sd
        except Exception as exc:
            self._emit({"type": "level_error", "error": f"sounddevice unavailable: {exc}"})
            return
        while not self._done.is_set():
            if not self._clients or not self._level_on:
                time.sleep(0.4)
                continue
            try:
                dev = self.mic_device
                with sd.InputStream(channels=1, samplerate=16000, blocksize=1600, device=dev) as stream:
                    while not self._done.is_set() and self._clients and self._level_on and dev == self.mic_device:
                        data, _ = stream.read(1600)
                        rms = float(np.sqrt(np.mean(np.square(data))))
                        self._emit({"type": "level", "v": round(min(1.0, rms * 8), 3)})
            except Exception as exc:
                self._emit({"type": "level_error", "error": str(exc)[:160]})
                time.sleep(3)

    def list_mics(self) -> list:
        try:
            import sounddevice as sd
            return [{"id": i, "name": d["name"]} for i, d in enumerate(sd.query_devices()) if d["max_input_channels"] > 0]
        except Exception:
            return []

    def kill_process(self, name: str) -> None:
        protected = {"system", "registry", "smss", "csrss", "wininit", "winlogon", "services", "lsass", "explorer", "python", "pythonw", "jarvis"}
        base = name.lower().replace(".exe", "")
        if base in protected:
            self.append_log(f"Refusing to end protected process '{name}'.", "warn")
            return
        killed = 0
        for p in psutil.process_iter(["name"]):
            try:
                if (p.info["name"] or "").lower().replace(".exe", "") == base:
                    p.terminate()
                    killed += 1
            except Exception:
                continue
        self.append_log(f"Ended {killed} '{name}' process(es)." if killed else f"No running process named '{name}'.", "info" if killed else "warn")

    def _reminder_loop(self) -> None:
        """Announces calendar events in the feed when their minute arrives."""
        while not self._done.is_set():
            for e in self.store.due_events(time.localtime(), self._fired):
                self.append_log(f"Reminder: {e.get('title', 'event')} is starting now.", "warn")
            time.sleep(15)

    def _capture_pos(self, key: str) -> None:
        """Waits 5 s so the user can hover the target button, then reports the mouse position."""
        try:
            import pyautogui
            for n in (5, 4, 3, 2, 1):
                self._emit({"type": "pos", "key": key, "countdown": n})
                time.sleep(1)
            x, y = pyautogui.position()
            self._emit({"type": "pos", "key": key, "x": int(x), "y": int(y)})
        except Exception as exc:
            self.append_log(f"Could not read mouse position: {exc}", "error")

    def _snapshot(self) -> dict:
        tools = []
        for t in tool_registry.list_tools():
            phrases = getattr(t, "trigger_phrases", None) or getattr(t, "triggers", None) or []
            tools.append({"name": t.name, "description": getattr(t, "description", ""),
                          "trigger": phrases[0] if phrases else t.name.replace("_", " ")})
        return {"type": "init", **self._state, "tools": tools, "feed": self._feed,
                "keys": len(config.GROQ_API_KEYS), "fast": config.FAST_MODEL,
                "strong": config.STRONG_MODEL, "version": "v4.0.0",
                "store": self.store.data, "wake": config.WAKE_WORD, "meta": self.meta, "toolstats": self.tool_stats, "keyhealth": self.key_health(), "startup": desktop.startup_enabled(), "mics": self.list_mics(), "data_dir": str(self.store.path.parent)}

    def _handle(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "command" and self._submit and msg.get("text", "").strip():
            self._submit(msg["text"].strip())
        elif kind == "listen_once" and self.brain:
            self.brain.listen_now()
        elif kind == "focus_toggle" and self.brain:
            self.brain.focus_toggle()
        elif kind == "tool_enable" and self.brain:
            self.brain.set_enabled(msg.get("name", ""), bool(msg.get("on")))
        elif kind == "mic_toggle" and self.assistant:
            # Tap-to-speak: toggles between "say JARVIS first" and "always listening"
            self.assistant._set_mode("wake" if self.assistant.mode == "active" else "active")
        elif kind == "store":
            self.store.apply(msg)
            self._emit({"type": "store", "data": self.store.data})
        elif kind == "run_workflow" and self._submit:
            wf = self.store.find_workflow(msg.get("id", ""))
            if wf:
                self.append_log(f"Workflow started: {wf.get('name')}", "info")
                for step in wf.get("commands", []):  # queued in order by Assistant.submit_text
                    self._submit(step)
        elif kind == "capture_pos":
            threading.Thread(target=self._capture_pos, args=(msg.get("key", ""),), daemon=True).start()
        elif kind == "clip_watch":
            self._clip_on = bool(msg.get("on"))
        elif kind == "startup":
            ok = desktop.set_startup(bool(msg.get("on")), str(config.APP_DIR / "main_web.py"))
            self._emit({"type": "startup", "on": desktop.startup_enabled(), "ok": ok})
        elif kind == "open_folder":
            try:
                os.startfile(str(config.APP_DIR))  # Windows only
            except Exception:
                self.append_log(f"Data folder: {config.APP_DIR}", "info")
        elif kind == "level":
            self._level_on = bool(msg.get("on"))
        elif kind == "process_kill" and msg.get("name"):
            threading.Thread(target=self.kill_process, args=(str(msg["name"]),), daemon=True).start()
        elif kind == "choose_mic":
            self.mic_device = msg.get("id") if isinstance(msg.get("id"), int) else None
            try:
                import sounddevice as sd
                sd.default.device = (self.mic_device, None) if self.mic_device is not None else (None, None)
            except Exception:
                pass
            self.append_log("Microphone changed for the meter and for voice recognition.", "info")
        elif kind == "tts_voices":
            def lst():
                try:
                    import pyttsx3
                    e = pyttsx3.init()
                    self._emit({"type": "tts_voices", "voices": [{"id": v.id, "name": v.name} for v in (e.getProperty("voices") or [])]})
                except Exception as exc:
                    self._emit({"type": "tts_voices", "voices": [], "error": str(exc)[:120]})
            threading.Thread(target=lst, daemon=True).start()
        elif kind == "tts_test":
            threading.Thread(target=lambda: self.assistant.say("Hello. This is how I sound."), daemon=True).start()
        elif kind == "export_store":
            self._emit({"type": "export", "data": self.store.data})
        elif kind == "import_store" and isinstance(msg.get("data"), dict):
            for k, v in msg["data"].items():
                if k in self.store.data and type(v) is type(self.store.data[k]):
                    self.store.data[k] = v
            self.store._save()
            self._emit({"type": "store", "data": self.store.data})
        elif kind == "clear_log":
            self._feed = []
        elif kind == "close" and self._on_close:
            self._on_close()

    def _build_app(self) -> FastAPI:
        app = FastAPI()
        app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")

        @app.get("/health")
        async def health():
            return {"ok": True, "clients": len(self._clients), "tools": len(tool_registry.list_tools())}

        @app.get("/")
        async def index():
            return FileResponse(WEB_DIR / "index.html")

        @app.websocket("/ws")
        async def ws_endpoint(ws: WebSocket):
            await ws.accept()
            self._clients.add(ws)
            await ws.send_text(json.dumps(self._snapshot()))
            try:
                while True:
                    self._handle(json.loads(await ws.receive_text()))
            except WebSocketDisconnect:
                pass
            finally:
                self._clients.discard(ws)

        return app

    def _serve(self) -> None:
        try:
            import websockets  # noqa: F401  (uvicorn needs a websocket library to serve /ws)
        except ImportError:
            if not getattr(sys, "frozen", False):  # self-heal: install it once, then continue
                print("JARVIS HUD: installing missing 'websockets' package...")
                subprocess.call([sys.executable, "-m", "pip", "install", "websockets"])
            try:
                import websockets  # noqa: F401,F811
            except ImportError:
                log.error("The 'websockets' package is missing: run  pip install websockets")
                self.append_log("Backend link needs: pip install websockets (then restart).", "error")
                print("\n*** JARVIS HUD: missing 'websockets'. Run:  pip install websockets  ***\n")
                raise
        server = uvicorn.Server(uvicorn.Config(self.app, host=HOST, port=self.port, log_level="warning", ws="websockets"))
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(server.serve())
