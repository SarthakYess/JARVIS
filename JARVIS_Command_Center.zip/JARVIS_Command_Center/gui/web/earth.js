/* earth.js: holographic Earth. Land mask (earth/land.png, built from Natural Earth via world-atlas) -> one point cloud,
   Fresnel atmosphere, real sub-solar point (UTC) with city lights, drifting clouds, tool arcs, drag/zoom/hover. */
(function(){
const CITIES=[[28.6,77.2],[19.1,72.9],[13.1,80.3],[22.6,88.4],[12.97,77.6],[17.4,78.5],[23,72.6],[18.5,73.9],[26.9,75.8],[30.7,76.8],[27.7,85.3],[23.8,90.4],[24.9,67],[31.5,74.3],[33.7,73],[6.9,79.9],
[35.7,139.7],[34.7,135.5],[37.6,127],[35.2,129],[39.9,116.4],[31.2,121.5],[23.1,113.3],[22.3,114.2],[25,121.5],[30.6,114.3],[29.6,106.5],[30.7,104],[34.3,108.9],[14.6,121],[10.8,106.7],[21,105.8],[13.8,100.5],[3.1,101.7],[1.35,103.8],[-6.2,106.8],[-7.3,112.7],
[25.2,55.3],[24.7,46.7],[21.5,39.2],[35.7,51.4],[33.3,44.4],[41,29],[39.9,32.9],[32.1,34.8],[30,31.2],[31.2,29.9],[36.8,10.2],[33.6,-7.6],[36.7,3],[6.5,3.4],[9.1,7.5],[5.6,-0.2],[14.7,-17.4],[9,38.7],[-1.3,36.8],[-6.8,39.3],[0.3,32.6],[-4.3,15.3],[-26.2,28],[-33.9,18.4],[-29.9,31],[-8.8,13.2],[15.6,32.5],
[51.5,-0.1],[48.9,2.4],[52.5,13.4],[40.4,-3.7],[41.4,2.2],[41.9,12.5],[45.5,9.2],[52.4,4.9],[50.8,4.4],[48.2,16.4],[59.3,18.1],[59.9,10.7],[55.7,12.6],[60.2,24.9],[52.2,21],[50.1,14.4],[47.5,19],[44.4,26.1],[38,23.7],[38.7,-9.1],[53.3,-6.3],[55.8,37.6],[59.9,30.3],[50.4,30.5],[56,37],[55,82.9],[43.2,76.9],
[40.7,-74],[34.1,-118.2],[41.9,-87.6],[29.8,-95.4],[33.4,-112.1],[25.8,-80.2],[47.6,-122.3],[37.8,-122.4],[38.9,-77],[42.4,-71.1],[32.8,-96.8],[39.7,-105],[33.7,-84.4],[45.5,-73.6],[43.7,-79.4],[49.3,-123.1],[19.4,-99.1],[20.7,-103.3],[25.7,-100.3],[9,-79.5],[4.7,-74.1],[6.2,-75.6],[-12,-77],[-0.2,-78.5],[10.5,-66.9],
[-23.6,-46.6],[-22.9,-43.2],[-34.6,-58.4],[-33.5,-70.7],[-15.8,-47.9],[-12.97,-38.5],[-3.7,-38.5],[-34.9,-56.2],[-25.3,-57.6],[-16.5,-68.1],[-33.9,151.2],[-37.8,145],[-27.5,153],[-31.9,115.9],[-34.9,138.6],[-36.8,174.8],[-41.3,174.8],[64.1,-21.9],[61.2,-149.9],[21.3,-157.9],[-18.1,178.4]];
const TZLAT={'Asia/Calcutta':28.6,'Asia/Kolkata':28.6,'Europe/London':51.5,'America/New_York':40.7,'America/Chicago':41.9,'America/Los_Angeles':34,'Asia/Tokyo':35.7,'Asia/Shanghai':31.2,'Asia/Dubai':25.2,'Europe/Paris':48.9,'Europe/Berlin':52.5,'Australia/Sydney':-33.9,'America/Sao_Paulo':-23.6,'Asia/Singapore':1.35,'Africa/Johannesburg':-26.2,'Africa/Lagos':6.5};
const rad=Math.PI/180,ll2v=(lat,lon,r=1)=>new THREE.Vector3(r*Math.cos(lat*rad)*Math.sin(lon*rad),r*Math.sin(lat*rad),r*Math.cos(lat*rad)*Math.cos(lon*rad));
const tz=(Intl.DateTimeFormat().resolvedOptions().timeZone)||'';
const HOME={lat:TZLAT[tz]??25,lon:-new Date().getTimezoneOffset()/4};   // lon is approximately -offsetMinutes/4
const DEST={browser:[37.63,-122.43],web_search:[37.39,-122.08]};
function sunDir(){const d=new Date(),N=Math.floor((d-Date.UTC(d.getUTCFullYear(),0,0))/864e5),decl=-23.44*Math.cos(2*Math.PI/365*(N+10))*rad,
 h=d.getUTCHours()+d.getUTCMinutes()/60+d.getUTCSeconds()/3600,lon=-(h-12)*15*rad;return new THREE.Vector3(Math.cos(decl)*Math.sin(lon),Math.sin(decl),Math.cos(decl)*Math.cos(lon))}
const hash=n=>{const s=Math.sin(n*127.1)*43758.5453;return s-Math.floor(s)};
const vnoise=(x,y,z)=>{const ix=Math.floor(x),iy=Math.floor(y),iz=Math.floor(z),fx=x-ix,fy=y-iy,fz=z-iz,u=t=>t*t*(3-2*t),h=(a,b,c)=>hash(a*57+b*131+c*311);
 const l=(a,b,t)=>a+(b-a)*t;return l(l(l(h(ix,iy,iz),h(ix+1,iy,iz),u(fx)),l(h(ix,iy+1,iz),h(ix+1,iy+1,iz),u(fx)),u(fy)),l(l(h(ix,iy,iz+1),h(ix+1,iy,iz+1),u(fx)),l(h(ix,iy+1,iz+1),h(ix+1,iy+1,iz+1),u(fx)),u(fy)),u(fz))};

window.initEarth=function(){
 const cv=document.getElementById('gl'),box=document.getElementById('orb');let R;
 try{R=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true})}catch(e){box.insertAdjacentHTML('beforeend','<div class="empty" style="position:absolute;inset:0;display:grid;place-items:center">WebGL is unavailable on this system.</div>');return}
 R.setClearColor(0,0);const sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(40,1,.1,60);cam.position.z=5.2;
 const G=new THREE.Group();sc.add(G);const U={uTime:{value:0},uPulse:{value:0},uPx:{value:1},uColor:{value:new THREE.Color(0,.9,1)},uSun:{value:sunDir()}};
 let points,cities,clouds,pts=0,lowQ=false;
 /* solid dark body so it reads as an object (also the picking surface) */
 const body=new THREE.Mesh(new THREE.SphereGeometry(.992,64,48),new THREE.ShaderMaterial({uniforms:{uSun:U.uSun,uColor:U.uColor},
  vertexShader:'varying vec3 vP;varying vec3 vN;void main(){vP=position;vN=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
  fragmentShader:'uniform vec3 uSun,uColor;varying vec3 vP;varying vec3 vN;void main(){float l=dot(normalize(vP),uSun);float day=smoothstep(-.15,.3,l);vec3 c=mix(vec3(.004,.02,.04),vec3(.01,.09,.2),day);c+=uColor*.05*pow(1.0-max(vN.z,0.),2.0);gl_FragColor=vec4(c,1.0);}'}));G.add(body);
 /* graticule */
 const gp=[];for(let la=-60;la<=60;la+=30)for(let i=0;i<96;i++){gp.push(ll2v(la,i/96*360-180,1.001),ll2v(la,(i+1)/96*360-180,1.001))}
 for(let lo=-180;lo<180;lo+=30)for(let i=0;i<48;i++){gp.push(ll2v(-90+i*180/48,lo,1.001),ll2v(-90+(i+1)*180/48,lo,1.001))}
 const gm=new THREE.LineBasicMaterial({color:0x00e5ff,transparent:true,opacity:.07,blending:THREE.AdditiveBlending,depthWrite:false});G.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(gp),gm));
 /* atmosphere: back-face halo + front Fresnel rim, tinted by state */
 const atmo=(r,side,fs)=>new THREE.Mesh(new THREE.SphereGeometry(r,48,40),new THREE.ShaderMaterial({uniforms:{uColor:U.uColor,uInt:{value:1}},transparent:true,side,depthWrite:false,blending:THREE.AdditiveBlending,
  vertexShader:'varying vec3 vN;void main(){vN=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'uniform vec3 uColor;uniform float uInt;varying vec3 vN;void main(){'+fs+'gl_FragColor=vec4(uColor*i*uInt,i*uInt);}'}));
 const halo=atmo(1.16,THREE.BackSide,'float i=pow(max(.72-dot(vN,vec3(0.,0.,1.)),0.),3.0)*1.0;'),rim=atmo(1.025,THREE.FrontSide,'float i=pow(1.0-max(dot(vN,vec3(0.,0.,1.)),0.),3.2)*.5;');sc.add(halo,rim);
 const cc=document.createElement('canvas');cc.width=cc.height=128;const cx=cc.getContext('2d'),gr=cx.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(255,255,255,.5)');gr.addColorStop(.4,'rgba(255,255,255,.08)');gr.addColorStop(1,'rgba(255,255,255,0)');cx.fillStyle=gr;cx.fillRect(0,0,128,128);
 const spr=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(cc),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false,opacity:.5,color:0x00e5ff}));spr.scale.set(4.2,4.2,1);sc.add(spr);
 /* orbit rings + satellites */
 const lm=o=>new THREE.LineBasicMaterial({color:0x00e5ff,transparent:true,opacity:o,blending:THREE.AdditiveBlending,depthWrite:false}),mats=[spr.material,gm];
 const ringsO=[[1.22,.45,[.35,0,.2]],[1.34,.35,[-.6,0,.9]],[1.48,.28,[1.1,0,-.4]]].map(([r,o,rot])=>{const p=[];for(let i=0;i<=200;i++){const a=i/200*Math.PI*2;p.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r))}
  const m=lm(o);mats.push(m);const l=new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(p),m);l.rotation.set(...rot);sc.add(l);
  const sm=new THREE.PointsMaterial({color:0xffffff,size:.07,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}),sg=new THREE.BufferGeometry();sg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(3),3));const s=new THREE.Points(sg,sm);l.add(s);mats.push(sm);return{m:l,s,r}});
 /* home pin + ripples */
 const homeV=ll2v(HOME.lat,HOME.lon,1.004),pinG=new THREE.Group();G.add(pinG);
 const dotM=new THREE.MeshBasicMaterial({color:0xffffff}),dot=new THREE.Mesh(new THREE.SphereGeometry(.018,12,12),dotM);dot.position.copy(homeV);pinG.add(dot);
 const rip=[0,.5].map(ph=>{const m=new THREE.Mesh(new THREE.RingGeometry(.02,.026,48),new THREE.MeshBasicMaterial({color:0x00e5ff,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide}));m.position.copy(homeV);m.lookAt(homeV.clone().multiplyScalar(2));m.userData.ph=ph;pinG.add(m);return m});
 let pinBoost=0;
 /* arcs */
 const arcs=[];function arcTo(lat,lon){const a=homeV.clone().normalize(),b=ll2v(lat,lon,1),ang=a.angleTo(b),N=64,pos=new Float32Array((N+1)*3);
  for(let i=0;i<=N;i++){const t=i/N,s=Math.sin(ang)||1e-4,v=a.clone().multiplyScalar(Math.sin((1-t)*ang)/s).add(b.clone().multiplyScalar(Math.sin(t*ang)/s)).normalize().multiplyScalar(1.004+(.06+.28*ang/Math.PI)*Math.sin(Math.PI*t));pos.set([v.x,v.y,v.z],i*3)}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));g.setDrawRange(0,0);const m=new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:1,blending:THREE.AdditiveBlending,depthWrite:false}),l=new THREE.Line(g,m);G.add(l);
  const d=new THREE.Mesh(new THREE.RingGeometry(.02,.03,32),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide}));d.position.copy(b.clone().multiplyScalar(1.004));d.lookAt(b.clone().multiplyScalar(2));G.add(d);arcs.push({l,g,m,d,t:0,N})}
 /* data-driven layers */
 function build(mask,W,H){const smp=(la,lo)=>mask[(Math.min(H-1,Math.max(0,Math.floor((90-la)/180*H)))*W+(((Math.floor((lo+180)/360*W))%W+W)%W))*4]>127;
  const N=34000,P=[],LA=[],ED=[],SD=[];for(let i=0;i<N;i++){const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),a=i*2.399963,lat=Math.asin(y)/rad;let lon=(a/rad)%360;if(lon>180)lon-=360;
   const land=smp(lat,lon),e=(smp(lat+1.3,lon)!==land||smp(lat-1.3,lon)!==land||smp(lat,lon+1.6)!==land||smp(lat,lon-1.6)!==land);
   if(!land&&!e&&Math.random()>.17)continue;P.push(Math.sin(a)*r,y,Math.cos(a)*r);LA.push(land?1:0);ED.push(e?1:0);SD.push(Math.random())}
  const n=P.length/3,idx=[...Array(n).keys()];for(let i=n-1;i>0;i--){const j=Math.random()*(i+1)|0;[idx[i],idx[j]]=[idx[j],idx[i]]}   // shuffled so a draw range is a uniform subset
  const pa=new Float32Array(n*3),la=new Float32Array(n),ea=new Float32Array(n),sa=new Float32Array(n);idx.forEach((k,i)=>{pa.set([P[k*3],P[k*3+1],P[k*3+2]],i*3);la[i]=LA[k];ea[i]=ED[k];sa[i]=SD[k]});
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pa,3));g.setAttribute('aLand',new THREE.BufferAttribute(la,1));g.setAttribute('aEdge',new THREE.BufferAttribute(ea,1));g.setAttribute('aSeed',new THREE.BufferAttribute(sa,1));
  points=new THREE.Points(g,new THREE.ShaderMaterial({uniforms:U,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
   vertexShader:'attribute float aLand,aEdge,aSeed;uniform float uTime,uPulse,uPx;uniform vec3 uSun;varying float vLand,vEdge,vLight,vA;void main(){vec3 p=position;vLight=dot(normalize(p),uSun);vLand=aLand;vEdge=aEdge;vec3 q=p*(1.0+uPulse*.014*sin(uTime*2.0+aSeed*30.0));vec4 mv=modelViewMatrix*vec4(q,1.0);float f=normalize(normalMatrix*p).z;vA=.16+.84*smoothstep(-.2,.5,f);float sz=(aLand>.5?2.5:1.4)+aEdge*1.1;sz*=.8+aSeed*.5;gl_PointSize=uPx*sz*(5.2/-mv.z)*(1.0+uPulse*.35);gl_Position=projectionMatrix*mv;}',
   fragmentShader:'uniform vec3 uColor;varying float vLand,vEdge,vLight,vA;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;float a=pow(1.0-d*2.0,1.4);float day=smoothstep(-.12,.2,vLight);vec3 landC=mix(uColor*.9,vec3(.75,1.,.95),.45);vec3 oceanC=mix(vec3(.02,.2,.5),uColor*.5,.25);vec3 c=mix(oceanC,landC,vLand)*mix(.25,1.,day);c=mix(c,vec3(1.),vEdge*.3*day);gl_FragColor=vec4(c,a*vA*mix(.3,.95,vLand)*(.5+.5*day)*(1.+vEdge*.7));}'}));
  G.add(points);pts=n;
  const cp=[],cs=[];CITIES.forEach(([la2,lo2],ci)=>{for(let k=0;k<4;k++){const v=ll2v(la2+(hash(ci*9+k)-.5)*2.2*(k?1:0),lo2+(hash(ci*7+k+3)-.5)*2.6*(k?1:0),1.003);cp.push(v.x,v.y,v.z);cs.push(hash(ci*13+k))}});
  const cg=new THREE.BufferGeometry();cg.setAttribute('position',new THREE.Float32BufferAttribute(cp,3));cg.setAttribute('aSeed',new THREE.Float32BufferAttribute(cs,1));
  cities=new THREE.Points(cg,new THREE.ShaderMaterial({uniforms:U,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,vertexShader:'attribute float aSeed;uniform float uTime,uPx;uniform vec3 uSun;varying float vK;void main(){float l=dot(normalize(position),uSun);vec4 mv=modelViewMatrix*vec4(position,1.0);float f=normalize(normalMatrix*position).z;vK=smoothstep(.1,-.12,l)*smoothstep(-.05,.35,f)*(.65+.35*sin(uTime*3.0+aSeed*50.0));gl_PointSize=uPx*(2.2+aSeed*1.6)*(5.2/-mv.z);gl_Position=projectionMatrix*mv;}',
   fragmentShader:'varying float vK;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(1.,.76,.38,pow(1.0-d*2.0,1.5)*vK);}'}));G.add(cities);
  const kp=[],ks=[];for(let i=0;i<9000&&kp.length<3*2600;i++){const y=Math.random()*2-1,a=Math.random()*6.2832,r=Math.sqrt(1-y*y),x=Math.sin(a)*r,z=Math.cos(a)*r;if(vnoise(x*2.6+3,y*2.6,z*2.6)*.65+vnoise(x*6,y*6+9,z*6)*.35>.6){kp.push(x*1.022,y*1.022,z*1.022);ks.push(Math.random())}}
  const kg=new THREE.BufferGeometry();kg.setAttribute('position',new THREE.Float32BufferAttribute(kp,3));kg.setAttribute('aSeed',new THREE.Float32BufferAttribute(ks,1));
  clouds=new THREE.Points(kg,new THREE.ShaderMaterial({uniforms:U,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,vertexShader:'attribute float aSeed;uniform float uPx;uniform vec3 uSun;varying float vK;void main(){vec4 mv=modelViewMatrix*vec4(position,1.0);float f=normalize(normalMatrix*position).z;vK=smoothstep(-.3,.4,dot(normalize(position),uSun))*smoothstep(-.1,.4,f);gl_PointSize=uPx*(3.5+aSeed*3.0)*(5.2/-mv.z);gl_Position=projectionMatrix*mv;}',
   fragmentShader:'varying float vK;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(.85,.95,1.,pow(1.0-d*2.0,1.2)*.11*(.3+vK));}'}));G.add(clouds);
  if(lowQ){points.geometry.setDrawRange(0,6000);clouds.visible=false}emitGeo()}
 const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=2048;c.height=1024;const x=c.getContext('2d');x.drawImage(im,0,0);build(x.getImageData(0,0,2048,1024).data,2048,1024)};im.src='/static/earth/land.png';
 function emitGeo(){window.EarthInfo={points:pts,drawn:lowQ?6000:pts,cities:CITIES.length*4,home:HOME,sun:U.uSun.value.toArray()}}
 /* state look + interaction */
 const T={Idle:{c:null,s:.0009,p:.12},Listening:{c:[.2,1,.7],s:.003,p:.5},Thinking:{c:[.7,.35,1],s:.008,p:.35},Speaking:{c:[.55,.95,1],s:.004,p:.9},Off:{c:[.9,.25,.25],s:.0004,p:0}};
 let cur=[0,.9,1],pulse=0,t=0,ry=-HOME.lon*rad,rx=HOME.lat*rad*.7,vy=0,vx=0,drag=false,lastI=0,tgt=null,zoom=5.2,mx=0,my=0,lastT=performance.now(),fr=0,acc=0,slow=0;
 addEventListener('mousemove',e=>{mx=e.clientX/innerWidth-.5;my=e.clientY/innerHeight-.5});
 let px=0,py=0;cv.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;py=e.clientY;vy=vx=0;tgt=null;cv.setPointerCapture(e.pointerId)});
 cv.addEventListener('pointermove',e=>{if(drag){const dx=e.clientX-px,dy=e.clientY-py;px=e.clientX;py=e.clientY;vy=dx*.006;vx=dy*.006;ry+=vy;rx=Math.max(-1.2,Math.min(1.2,rx+vx));lastI=performance.now()}hover(e)});
 cv.addEventListener('pointerup',()=>{drag=false;lastI=performance.now()});cv.addEventListener('pointerleave',()=>{document.getElementById('geo').style.display='none'});
 cv.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(3.8,Math.min(6.2,zoom+e.deltaY*.003))},{passive:false});cv.addEventListener('dblclick',()=>focus(HOME.lat,HOME.lon));
 const ray=new THREE.Raycaster(),geo=document.getElementById('geo');
 function hover(e){const r=cv.getBoundingClientRect();ray.setFromCamera(new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height*2-1)),cam);const h=ray.intersectObject(body)[0];
  if(!h){geo.style.display='none';return}const p=G.worldToLocal(h.point.clone()).normalize(),la=Math.asin(p.y)/rad,lo=Math.atan2(p.x,p.z)/rad;geo.style.display='block';geo.textContent=`${Math.abs(la).toFixed(1)}°${la>=0?'N':'S'}  ${Math.abs(lo).toFixed(1)}°${lo>=0?'E':'W'}`}
 function focus(lat,lon){let ty=-lon*rad;ty=ry+Math.atan2(Math.sin(ty-ry),Math.cos(ty-ry));tgt={y:ty,x:Math.max(-1.2,Math.min(1.2,lat*rad*.85))};vy=vx=0}
 window.Earth={focus,arcTo,home:HOME,pulse:()=>{pinBoost=1},setQuality:q=>{lowQ=q==='low';if(points){points.geometry.setDrawRange(0,lowQ?6000:pts);clouds.visible=!lowQ}R.setPixelRatio(lowQ?1:Math.min(devicePixelRatio,2));rs();emitGeo()}};
 on('globe_focus',d=>{focus(d.lat,d.lon);Earth.pulse()});
 on('tools',d=>{const prev=window._prevTools||{};Object.entries(d.stats||{}).forEach(([k,v])=>{if(v.state==='run'&&(prev[k]||{}).state!=='run'){const dst=DEST[k];dst?arcTo(dst[0],dst[1]):Earth.pulse()}});window._prevTools=JSON.parse(JSON.stringify(d.stats||{}))});
 const rs=()=>{const w=box.clientWidth,h=box.clientHeight;if(!w||!h)return;R.setPixelRatio(lowQ?1:Math.min(devicePixelRatio,2));R.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();U.uPx.value=R.getPixelRatio()*Math.max(.6,h/520)};
 new ResizeObserver(rs).observe(box);setInterval(()=>{U.uSun.value.copy(sunDir())},30000);
 (function frame(now){requestAnimationFrame(frame);if(document.hidden||S.page!=='dash')return;
  const dt=Math.min(.05,(now-lastT)/1000)||.016;lastT=now;t+=dt;const k=S.online?(T[S.status]||T.Idle):T.Off,base=window.ACCENT||[0,.9,1],want=k.c||base;
  /* FPS governor: below 40 fps for ~3 s -> lighter Earth */
  fr++;acc+=dt;if(acc>=1){const fps=fr/acc;fr=0;acc=0;window.FPS=Math.round(fps);if(fps<40&&!lowQ&&points){if(++slow>=3){Earth.setQuality('low');document.body.classList.add('perf');toast('Performance mode on: lighter Earth, fewer effects.')}}else slow=0}
  for(let i=0;i<3;i++)cur[i]+=(want[i]-cur[i])*.06;U.uColor.value.setRGB(...cur);mats.forEach(m=>m.color&&m.color.setRGB(...cur));rip.forEach(m=>m.material.color.setRGB(...cur));
  const speaking=S.status==='Speaking',env=speaking?.55+.45*Math.sin(t*9)*Math.sin(t*3.1):S.status==='Listening'||S.mode==='active'&&S.status==='Idle'?Math.min(1,S.level*1.4):0;
  const tp=k.p*(speaking?.55+.45*env:1)+env*.5;pulse+=(tp-pulse)*.12;U.uPulse.value=pulse;U.uTime.value=t;
  if(tgt){ry+=(tgt.y-ry)*.07;rx+=(tgt.x-rx)*.07;if(Math.abs(tgt.y-ry)<.004&&Math.abs(tgt.x-rx)<.004){tgt=null;lastI=performance.now()+2500}}
  else if(!drag){ry+=vy;rx=Math.max(-1.2,Math.min(1.2,rx+vx));vy*=.95;vx*=.95;if(performance.now()-lastI>2500)ry+=k.s*dt*60}
  G.rotation.set(rx,ry,0);if(clouds)clouds.rotation.y+=.00025*dt*60;cam.position.z+=(zoom*Math.max(1,1/cam.aspect)-cam.position.z)*.1;G.position.x+=(mx*.25-G.position.x)*.03;G.position.y+=(-my*.18-G.position.y)*.03;
  halo.material.uniforms.uInt.value=.7+pulse*.5;rim.material.uniforms.uInt.value=.7+pulse*.4;spr.material.opacity=.34+pulse*.3;
  ringsO.forEach((o,i)=>{o.m.rotation.y+=.0015*(i+1)*(i%2?-1:1)*dt*60;const a=t*(.7+i*.3)*(i%2?-1:1);o.s.position.set(Math.cos(a)*o.r,0,Math.sin(a)*o.r)});
  pinBoost*=.97;rip.forEach(m=>{m.userData.ph=(m.userData.ph+dt*(.45+pinBoost*.9))%1;const p=m.userData.ph;m.scale.setScalar(1+p*(5+pinBoost*4));m.material.opacity=(1-p)*(.6+pinBoost*.4)});
  for(let i=arcs.length-1;i>=0;i--){const a=arcs[i];a.t+=dt;const p=Math.min(1,a.t/1.1);a.g.setDrawRange(0,Math.floor(p*(a.N+1)));a.m.opacity=a.t<1.6?1:Math.max(0,1-(a.t-1.6)/.9);a.d.material.opacity=p>=1?a.m.opacity:0;a.d.scale.setScalar(1+(a.t%1)*2.5);a.m.color.setRGB(...cur);
   if(a.t>2.6){G.remove(a.l,a.d);a.g.dispose();a.m.dispose();arcs.splice(i,1)}}
  R.render(sc,cam)})(performance.now());
};
})();
