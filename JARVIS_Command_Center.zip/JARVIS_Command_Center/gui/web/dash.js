/* dash.js: dashboard behaviour (hero readout, conversation, live caption, action trace, monitor, capabilities, schedule). */
const fmtB=b=>b>1048576?(b/1048576).toFixed(1)+' MB/s':Math.round(b/1024)+' KB/s',fmtU=s=>{s=Math.floor(s);return Math.floor(s/86400)+'d '+Math.floor(s%86400/3600)+'h '+Math.floor(s%3600/60)+'m'};
const hhmm=ms=>new Date(ms).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
/* ---------- tiny SVG helpers ---------- */
function spark(a,color,max,h=34,w=200){if(!a.length)return`<svg class="spk" viewBox="0 0 ${w} ${h}"></svg>`;const m=max||Math.max(1,...a)*1.15,st=w/Math.max(1,(a.length-1)),pts=a.map((v,i)=>`${(i*st).toFixed(1)},${(h-1-Math.min(1,v/m)*(h-3)).toFixed(1)}`).join(' ');
 return`<svg class="spk" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><polygon points="0,${h} ${pts} ${w},${h}" fill="${color}" fill-opacity=".14"/><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`}
function tick(el,to,suf=''){if(!el)return;const from=+el.dataset.v||0;el.dataset.v=to;const t0=performance.now();(function f(n){const k=Math.min(1,(n-t0)/500),e=1-Math.pow(1-k,3);el.textContent=Math.round(from+(to-from)*e)+suf;if(k<1)requestAnimationFrame(f)})(t0)}

/* ---------- state: pill, dock, hero readout ---------- */
const SCOL={Idle:'var(--accent)',Listening:'var(--ok)',Thinking:'var(--ai)',Speaking:'#8ff3ff'};let lastIntent='',lastSaid='';
function state(){const off=!S.online,bad=off||S.mic==='error',live=S.online&&(S.status==='Listening'||S.mode==='active');
 $('#stxt').textContent=off?'Backend offline':S.mic==='error'?'Mic error':'Systems optimal';$('#sdot').style.background=bad?'var(--err)':'var(--ok)';
 document.body.classList.toggle('live',live);const L={Idle:S.mode==='active'?'Listening':'Standby',Listening:'Listening',Thinking:'Processing',Speaking:'Speaking'};
 $('#vtxt').textContent=off?'Offline':L[S.status]||S.status;const w=off?'OFFLINE':S.status==='Idle'&&S.mode==='wake'?'STANDBY':(L[S.status]||S.status).toUpperCase();
 const h=$('#hst');h.textContent=w;h.style.color=off?'var(--err)':SCOL[S.status]||'var(--accent)';
 $('#hsub').textContent=off?'Reconnecting to the backend. Local commands are unavailable.':S.status==='Thinking'?(lastIntent||'Working on your request...'):S.status==='Speaking'?lastSaid:S.status==='Listening'||(S.mode==='active'&&S.status==='Idle')?'I am listening. Speak your command.':`Say "${S.wake}" and a command, or type below.`;
 const f=$('#focus');f.classList.toggle('on',S.mode==='active'&&!S.oneshot);f.setAttribute('aria-pressed',S.mode==='active'&&!S.oneshot);f.textContent=S.mode==='active'&&!S.oneshot?'Focus on':'Focus mode';
 $('#mic').setAttribute('aria-label',S.mode==='active'&&S.oneshot?'Listening for one command':'Tap to speak one command');levelWant();renderCore()}
on('state',state);on('init',()=>{initChat();state();feedInit();renderCaps();renderSched();overdue()});
/* mic level stream only while it is useful */
let lvOn=false;function levelWant(){const w=S.online&&(S.status==='Listening'||S.mode==='active'||S.oneshot||S.page==='settings');if(w!==lvOn){lvOn=w;send({type:'level',on:w})}}
on('dashshow',levelWant);

/* ---------- core status ---------- */
const row=(i,l,v,c)=>`<div class="r"><span class="${c==='g'?'g':c==='r2'?'r2':c==='a'?'a':'cy'}">${ico(i)}</span><b>${l}</b><em class="${c}">${esc(v)}</em></div>`;
function renderCore(){const kh=S.keyhealth||[],okk=kh.filter(k=>k.state==='ok').length,on_=S.tools.filter(t=>ST().agents[t.name]!==false).length,m=ST().memory.length;
 $('#core').innerHTML=row('cpu','Brain',S.online?S.status:'Offline',S.online?'g':'r2')+row('mic','Voice',S.mic==='error'?'Mic error':S.mode==='active'?'Always on':'Wake word',S.mic==='error'?'r2':'g')+
 row('type','Speech',S.meta.stt,'')+row('bolt','AI keys',S.keys?`${okk||S.keys}/${S.keys} ok`:'None',okk===kh.length&&S.keys?'g':S.keys?'a':'r2')+row('box','Modules',`${on_}/${S.tools.length} on`,'')+row('db','Memory',m+' facts','')}
on('store',()=>{renderCore();renderCaps();renderSched();overdue()});

/* ---------- capabilities (grouped, live state, activity sparkline) ---------- */
const HIST=JSON.parse(sessionStorage.getItem('jv_hist')||'{}');
on('tools',d=>{const now=Date.now();Object.entries(d.stats||{}).forEach(([k,v])=>{if(v.state==='run'&&(S.ts[k]||{}).state!=='run'){(HIST[k]=HIST[k]||[]).push(now);HIST[k]=HIST[k].slice(-200)}});sessionStorage.setItem('jv_hist',JSON.stringify(HIST));S.ts=d.stats;renderCaps()});
function buckets(k){const now=Date.now(),a=Array(12).fill(0);(HIST[k]||[]).forEach(t=>{const i=11-Math.floor((now-t)/3e5);if(i>=0)a[i]++});return a}
function mini(k){const a=buckets(k),m=Math.max(1,...a);return`<svg class="mini" viewBox="0 0 46 14" aria-hidden="true">${a.map((v,i)=>`<rect x="${i*3.9}" y="${14-1-v/m*12}" width="3" height="${1+v/m*12}" rx="1" fill="${v?'var(--accent)':'var(--line2)'}"/>`).join('')}</svg>`}
function renderCaps(){const known=new Set(CATS.flatMap(c=>c[1])),extra=S.tools.map(t=>t.name).filter(n=>!known.has(n)),cats=[...CATS,...(extra.length?[['Other',extra]]:[])];
 const h=cats.map(([c,names])=>{const ts=names.map(n=>S.tools.find(t=>t.name===n)).filter(Boolean);return ts.length?`<div class="cat"><div class="lbl">${c}</div>${ts.map(t=>{const s=S.ts[t.name]||{},off=ST().agents[t.name]===false;
  return`<button class="cap ${s.state==='run'?'run':''} ${off?'off':''}" data-mod="${t.name}" aria-label="${t.name.replace(/_/g,' ')}, ${off?'off':s.state==='run'?'running':(s.n||0)+' runs'}">${ico(TOOLICON[t.name]||'box')}<b>${t.name.replace(/_/g,' ')}</b>${off?'<small>Off</small>':(HIST[t.name]||[]).length?mini(t.name):'<small>idle</small>'}<i class="sd"></i></button>`}).join('')}</div>`:''}).join('');
 $('#caps').innerHTML=h||'<div class="empty">No modules loaded.</div>'}
setInterval(()=>{if(S.page==='dash')renderCaps()},60000);

/* ---------- feed = system events only ---------- */
const FEEDTAGS=['info','warn','error'];
window.feedItem=e=>`<div class="fi ${e.tag}"><div>${esc(e.text.slice(0,220))}<time>${e.ts||''}</time></div></div>`;
function feedInit(){$('#feed').innerHTML='';(S.feed||[]).filter(e=>FEEDTAGS.includes(e.tag)).slice(-30).forEach(addFeed);if(!$('#feed').children.length)$('#feed').innerHTML='<div class="empty" id="fe">No system events yet. Reminders, warnings and errors appear here.</div>'}
function addFeed(e){$('#fe')&&$('#fe').remove();if(e.tag==='warn'||e.tag==='error'){S.notes.unshift(e);bell()}const f=$('#feed');f.insertAdjacentHTML('afterbegin',feedItem(e));while(f.children.length>40)f.lastChild.remove()}
function overdue(){const td=today(),od=ST().tasks.filter(t=>t.done!=='true'&&t.due&&t.due<td).length;$$('#feed .od').forEach(x=>x.remove());if(od)$('#feed').insertAdjacentHTML('afterbegin',`<div class="fi error od"><div>${od} overdue task${od>1?'s':''}<br><button class="btn sm" data-go="tasks">View tasks</button></div></div>`)}

/* ---------- markdown + syntax highlighting (no libraries) ---------- */
const KW=/\b(?:def|class|return|if|elif|else|for|while|import|from|as|try|except|finally|with|lambda|None|True|False|and|or|not|in|is|const|let|var|function|async|await|new|this|null|true|false|undefined|echo|cd|ls|pip|npm|git|print|raise|yield|pass)\b/;
const TOK=new RegExp(`(#.*$|//.*$)|("(?:[^"\\\\]|\\\\.)*"|'(?:[^'\\\\]|\\\\.)*')|(${KW.source})|(\\b\\d+(?:\\.\\d+)?\\b)`,'gm');
function hl(code){let o='',i=0,m;TOK.lastIndex=0;while((m=TOK.exec(code))){o+=esc(code.slice(i,m.index));const c=m[1]?'c':m[2]?'s':m[3]?'k':'n';o+=`<span class="tk-${c}">${esc(m[0])}</span>`;i=m.index+m[0].length;if(m[0]==='')TOK.lastIndex++}return o+esc(code.slice(i))}
function md(src){const blocks=[];let s=String(src).replace(/```(\w*)\n?([\s\S]*?)```/g,(_,l,c)=>{blocks.push(`<div class="cb"><header>${esc(l||'code')}<button class="btn sm ghost" data-copy-code>${ico('copy')}Copy</button></header><pre><code>${hl(c.replace(/\n$/,''))}</code></pre></div>`);return`\u0000${blocks.length-1}\u0000`});
 s=esc(s).replace(/`([^`\n]+)`/g,'<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/\bhttps?:\/\/[^\s<)]+/g,u=>`<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`);
 const out=s.split(/\n{2,}/).map(p=>/^\s*[-*] /.test(p)?'<ul>'+p.split('\n').map(l=>`<li>${l.replace(/^\s*[-*] /,'')}</li>`).join('')+'</ul>':`<p>${p.replace(/\n/g,'<br>')}</p>`).join('');
 return out.replace(/\u0000(\d+)\u0000/g,(_,i)=>blocks[+i]).replace(/<p>(<div class="cb">[\s\S]*?<\/div>)<\/p>/g,'$1')}

/* ---------- conversation ---------- */
let CH=[],hIdx=-1,chatQ='';const KMAP={user:'you',jarvis:'jv',output:'out',error:'er',warn:'er'};
function initChat(){if(CH.length)return;try{CH=JSON.parse(localStorage.getItem('jv_chat')||'[]')}catch(e){CH=[]}
 if(!CH.length)(S.feed||[]).filter(e=>['user','jarvis','output','error'].includes(e.tag)).slice(-12).forEach(e=>CH.push(mk(e)));renderChat()}
const mk=e=>({id:Math.random().toString(36).slice(2,9),k:KMAP[e.tag]||'jv',text:e.text.replace(/^(You|JARVIS):\s*/,''),ts:Date.now()});
const persist=()=>{try{localStorage.setItem('jv_chat',JSON.stringify(CH.slice(-1000)))}catch(e){}};
function msgHTML(m){if(m.k==='trace')return'';const who=m.k==='you'?'You':m.k==='jv'?'JARVIS':m.k==='out'?'Output':'Error';
 return`<div class="msg ${m.k}" data-id="${m.id}"><div class="bub">${m.k==='out'?esc(m.text.slice(0,2000)):md(m.text.slice(0,4000))}</div><div class="mm"><span>${who}, ${hhmm(m.ts)}</span><span class="acts">${m.k==='you'?`<button data-act="rerun" aria-label="Run again" data-tip="Run again">${ico('retry')}</button>`:''}<button data-act="copy" aria-label="Copy" data-tip="Copy">${ico('copy')}</button><button data-act="pin" aria-label="Pin to memory" data-tip="Pin to memory">${ico('mark')}</button></span></div></div>`}
function renderChat(){const c=$('#chat'),q=chatQ.toLowerCase(),list=q?CH.filter(m=>m.k!=='trace'&&m.text&&m.text.toLowerCase().includes(q)):CH.slice(-150);
 c.innerHTML=list.length?list.map(m=>m.k==='trace'?traceHTML(TR[m.tid]||{}):msgHTML(m)).join(''):`<div class="empty" style="margin:auto;text-align:center">${q?'No messages match.':'Nothing here yet. Ask something or run a command.'}</div>`;c.scrollTop=c.scrollHeight}
function addMsg(m){CH.push(m);persist();if(chatQ){return}const c=$('#chat');c.querySelector('.empty')&&(c.innerHTML='');const stick=c.scrollHeight-c.scrollTop-c.clientHeight<80;
 c.insertAdjacentHTML('beforeend',msgHTML(m));const el=c.lastElementChild;
 if(m.k==='jv'&&m.text.length<600&&!matchMedia('(prefers-reduced-motion:reduce)').matches&&!document.body.classList.contains('perf')){const b=el.querySelector('.bub'),full=b.innerHTML;b.setAttribute('aria-hidden','true');el.insertAdjacentHTML('afterbegin',`<span class="sr">${esc(m.text)}</span>`);let i=0;b.textContent='';b.classList.add('caret');
  const iv=setInterval(()=>{i+=3;b.textContent=m.text.slice(0,i);if(stick)c.scrollTop=c.scrollHeight;if(i>=m.text.length){clearInterval(iv);b.classList.remove('caret');b.innerHTML=full;b.removeAttribute('aria-hidden');if(stick)c.scrollTop=c.scrollHeight}},16)}
 if(stick)c.scrollTop=c.scrollHeight;while(c.children.length>300)c.firstChild.remove()}
on('log',d=>{S.feed=[...S.feed,d].slice(-80);if(FEEDTAGS.includes(d.tag))addFeed(d);else if(['user','jarvis','output'].includes(d.tag)){addMsg(mk(d));if(d.tag==='jarvis'){lastSaid=d.text.replace(/^JARVIS:\s*/,'');state();snd('ok')}}
 if(d.tag==='error'){addMsg(mk(d));snd('err')}});
document.addEventListener('click',e=>{const t=e.target;let b;
 if(b=t.closest('[data-act]')){const id=b.closest('.msg').dataset.id,m=CH.find(x=>x.id===id);if(!m)return;const a=b.dataset.act;
  if(a==='copy'){navigator.clipboard.writeText(m.text).then(()=>toast('Copied'))}else if(a==='rerun'){cmd(m.text)}else if(a==='pin'){put({op:'add',coll:'memory',item:{text:m.text}});toast('Pinned to memory')}}
 if(b=t.closest('[data-copy-code]')){navigator.clipboard.writeText(b.closest('.cb').querySelector('code').textContent).then(()=>{b.lastChild.textContent='Copied';setTimeout(()=>b.lastChild.textContent='Copy',1200)})}
 if(b=t.closest('[data-retry]')){const tr=TR[b.dataset.retry];tr&&cmd(tr.heard)}});

/* ---------- live caption + action trace ---------- */
const TR={};let capTimer;
function cap(show,html,chip){const c=$('#cap');c.classList.toggle('show',show);if(html!=null)$('#captx').innerHTML=html;const ch=$('#capchip');ch.style.display=chip?'inline-flex':'none';if(chip){ch.className='chip '+chip[0];ch.innerHTML=chip[1]}}
on('voice',d=>{clearTimeout(capTimer);if(d.phase==='listening'){snd('wake');cap(true,'<em>Listening</em>Speak now...')}else if(d.phase==='transcribing')cap(true,'<em>Transcribing</em>...');else if(!TR_live())cap(false)});
const TR_live=()=>Object.values(TR).some(t=>t.stage!=='done');
function stepHTML(k,v,cls){return`<div class="ts ${cls}"><div class="k">${k}</div><div class="v">${v}</div></div>`}
function traceHTML(t){if(!t.id)return'';const u=t.stage!=='heard',d=t.stage==='done',args=Object.entries(t.args||{}).map(([k,v])=>`${k}: ${Array.isArray(v)?v.join(' '):v}`).join(', ');
 return`<div class="trace" data-trace="${t.id}"><div class="steps">${stepHTML('Heard',esc(t.heard),'done')}${stepHTML('Understood',u?esc(t.intent||'-')+(args?`<br><span class="dm">${esc(args.slice(0,70))}</span>`:''):'...',u?'done':'live')}${stepHTML('Executed',d?(t.tool?esc(t.tool.replace(/_/g,' '))+` <span class="dm">${t.ms} ms</span>`:`<span class="dm">${t.ms} ms</span>`):'...',d?(t.ok?'done':'fail'):u?'live':'')}${stepHTML('Result',d?esc((t.result||'Done').slice(0,120)):'...',d?(t.ok?'done':'fail'):'')}</div>
 ${d&&!t.ok?`<div class="tf"><span class="chip err">Failed</span><button class="btn sm" data-retry="${t.id}">${ico('retry')}Retry</button></div>`:''}</div>`}
on('trace',t=>{const first=!TR[t.id];TR[t.id]=t;clearTimeout(capTimer);
 if(first){const m={id:'t'+t.id,k:'trace',tid:t.id,ts:Date.now()};CH.push(m);if(!chatQ){const c=$('#chat');c.querySelector('.empty')&&(c.innerHTML='');c.insertAdjacentHTML('beforeend',traceHTML(t));c.scrollTop=c.scrollHeight}}
 else{const el=document.querySelector(`[data-trace="${t.id}"]`);if(el){el.outerHTML=traceHTML(t)}}
 if(t.stage==='heard')cap(true,`<em>Heard</em>${esc(t.heard)}`,['info','Understanding...']);
 else if(t.stage==='understood'){lastIntent=t.intent;cap(true,`<em>Heard</em>${esc(t.heard)}`,['ai',esc(t.intent)]);snd('understood');state()}
 else if(t.stage==='done'){cap(true,`<em>Heard</em>${esc(t.heard)}`,t.ok?['ok',`Done in ${t.ms} ms`]:['err','Failed']);capTimer=setTimeout(()=>cap(false),t.ok?2800:6000);if(!t.ok)snd('err');lastIntent='';state();
  const k=Object.keys(TR);if(k.length>30)delete TR[k[0]]}
 const c=$('#chat');c.scrollTop=c.scrollHeight});
/* live waveform: real mic level while listening */
const wb=[];$('#wave').innerHTML='<span></span>'.repeat(18);$$('#wave span').forEach(b=>wb.push(b));const cw=$$('#capw i');
setInterval(()=>{if(S.page!=='dash')return;const lis=S.online&&(S.status==='Listening'||S.mode==='active'||S.oneshot);wb.forEach((b,i)=>b.style.height=(lis?3+Math.min(1,S.level*1.2)*(6+Math.abs(Math.sin(Date.now()/130+i*.8))*12):3)+'px');cw.forEach((b,i)=>b.style.height=(4+Math.min(1,S.level*1.3)*(4+Math.abs(Math.sin(Date.now()/110+i))*11))+'px')},90);

/* ---------- composer: history, suggestions ---------- */
const STARTERS=['play lo-fi on youtube','open chatgpt','system status','show me Tokyo','take a screenshot','remember that '];
function pool(){const h=[...new Set(CH.filter(m=>m.k==='you').map(m=>m.text).reverse())].slice(0,40);const tools=(typeof EX!=='undefined'?Object.values(EX):[]);const rt=ST().routines.flatMap(r=>r.phrases||[]);return[...h,...rt,...tools,...STARTERS]}
let sel=-1;function suggest(){const q=$('#txt').value.trim().toLowerCase(),box=$('#sug');let l=pool().filter((x,i,a)=>a.indexOf(x)===i);
 l=q?l.filter(x=>x.toLowerCase().includes(q)&&x.toLowerCase()!==q).sort((a,b)=>(b.toLowerCase().startsWith(q))-(a.toLowerCase().startsWith(q))):(document.activeElement===$('#txt')&&!CH.some(m=>m.k==='you')?STARTERS:[]);
 l=l.slice(0,4);sel=-1;box.innerHTML=l.map(x=>`<button role="option" data-sg="${esc(x)}">${esc(x)}</button>`).join('')}
$('#txt').addEventListener('input',suggest);$('#txt').addEventListener('focus',suggest);
$('#txt').addEventListener('keydown',e=>{const t=e.target,hist=CH.filter(m=>m.k==='you').map(m=>m.text);const sg=$$('#sug button');
 if(e.key==='Enter'){if(sel>=0&&sg[sel]){t.value=sg[sel].dataset.sg;sel=-1;e.preventDefault();return}run()}
 else if(e.key==='Tab'&&sg.length){e.preventDefault();sel=(sel+1)%sg.length;sg.forEach((b,i)=>b.classList.toggle('sel',i===sel));t.value=sg[sel].dataset.sg}
 else if(e.key==='ArrowUp'&&hist.length){e.preventDefault();hIdx=Math.min(hist.length-1,hIdx+1);t.value=hist[hist.length-1-hIdx]}
 else if(e.key==='ArrowDown'){e.preventDefault();hIdx=Math.max(-1,hIdx-1);t.value=hIdx<0?'':hist[hist.length-1-hIdx]}
 else if(e.key==='Escape'){$('#sug').innerHTML=''}});
function run(){const t=$('#txt').value.trim();if(t){cmd(t);$('#txt').value='';hIdx=-1;$('#sug').innerHTML=''}}
$('#send').onclick=run;document.addEventListener('click',e=>{const b=e.target.closest('[data-sg]');if(b){$('#txt').value=b.dataset.sg;$('#txt').focus();suggest()}});
$('#cq').addEventListener('input',e=>{chatQ=e.target.value.trim();renderChat()});$('#cclr').onclick=()=>{CH=[];persist();renderChat();toast('Conversation view cleared')};

/* ---------- system monitor ---------- */
const HS={cpu:[],ram:[],down:[],up:[]};
on('stats',s=>{
 const C=2*Math.PI;[['aC',276,s.cpu],['aR',260,s.ram],['aD',244,s.disk]].forEach(([id,r,v])=>$('#'+id).setAttribute('stroke-dasharray',`${(C*r*.75*v/100).toFixed(1)} 2000`));
 tick($('#mcC'),Math.round(s.cpu),'%');tick($('#mcR'),Math.round(s.ram),'%');tick($('#mcD'),Math.round(s.disk),'%');
 if(s.gpu){(HS.gpu=HS.gpu||[]).push(s.gpu.util);if(HS.gpu.length>30)HS.gpu.shift()}[['cpu',s.cpu],['ram',s.ram],['down',s.down],['up',s.up]].forEach(([k,v])=>{HS[k].push(v);if(HS[k].length>30)HS[k].shift()});
 $('#spk').innerHTML=`<div class="sk"><div class="l"><span>CPU, last 60 s</span><b>${Math.round(s.cpu)}%</b></div>${spark(HS.cpu,'var(--accent)',100)}</div>
  <div class="sk"><div class="l"><span>Memory, last 60 s</span><b>${Math.round(s.ram)}%</b></div>${spark(HS.ram,'var(--ai)',100,26)}</div>
  <div class="sk"><div class="l"><span>Network ${ico('down')} ${fmtB(s.down)} ${ico('up')} ${fmtB(s.up)}</span></div>${spark(HS.down.map((d,i)=>d+HS.up[i]),'var(--ok)',0,26)}</div>
  ${s.gpu?`<div class="sk"><div class="l"><span>GPU, VRAM ${s.gpu.vram}%${s.gpu.temp!=null?', '+s.gpu.temp+'°C':''}</span><b>${s.gpu.util}%</b></div>${spark(HS.gpu,'var(--warn)',100,26)}</div>`:''}${(s.cores||[]).length?`<div class="sk"><div class="l"><span>${s.cores.length} cores</span></div><div class="cores" aria-hidden="true">${s.cores.map(c=>`<i style="height:${Math.max(2,c/100*26)}px"></i>`).join('')}</div></div>`:''}`;
 $('#kv').innerHTML=`<div>Battery <b>${s.batt==null?'AC power':Math.round(s.batt)+'%'+(s.plugged?' (charging)':'')}</b></div><div>Uptime <b>${fmtU(s.uptime)}</b></div>`;
 const mx=Math.max(5,...s.procs.map(p=>p[1]));$('#procs').innerHTML='<div class="lbl" style="margin-bottom:4px">Top processes</div>'+s.procs.map(p=>`<div class="proc"><span title="${esc(p[0])}">${esc(p[0])}</span><i><s style="width:${Math.min(100,p[1]/mx*100)}%"></s></i><u>${p[1]}%</u><button class="x" data-kill="${esc(p[0])}" aria-label="End task ${esc(p[0])}" data-tip="End task">${ico('x')}</button></div>`).join('')});
document.addEventListener('click',e=>{const b=e.target.closest('[data-kill]');if(b){const n=b.dataset.kill;modal(`<div class="pt">End task</div><p style="margin-bottom:12px">End <b>${esc(n)}</b>? Unsaved work in it will be lost.</p><button class="btn dng" id="kyes">End ${esc(n)}</button>`);$('#kyes').onclick=()=>{send({type:'process_kill',name:n});closeM();toast('Ending '+n)}}});

/* ---------- schedule ---------- */
const mins=e=>(new Date(e.date+'T'+(e.time||'00:00'))-Date.now())/6e4,rel=m=>m<0?'Done':m<60?`In ${Math.round(m)} min`:m<1440?`In ${Math.floor(m/60)}h ${Math.round(m%60)}m`:`In ${Math.floor(m/1440)}d`;
function renderSched(){const d=ST(),td=today(),wk=new Date(Date.now()+6048e5).toLocaleDateString('en-CA');
 const ev=d.events.filter(e=>S.tlr==='today'?e.date===td:e.date>=td&&e.date<=wk).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,4),tk=d.tasks.filter(t=>t.done!=='true'&&(S.tlr==='week'||!t.due||t.due<=td)).slice(0,3);let h='';
 ev.forEach(e=>{const m=mins(e);h+=`<div class="r"><time>${e.time||'--:--'}</time><span style="flex:1">${esc(e.title)}</span><em>${rel(m)}</em></div>`});
 tk.forEach(t=>h+=`<div class="r"><time>TASK</time><span style="flex:1">${esc(t.title)}</span><em class="${t.due&&t.due<td?'r2':''}">${t.due?(t.due<td?'Overdue':t.due):'Open'}</em></div>`);
 $('#sched').innerHTML=h||`<div class="empty">Nothing scheduled.<br><a style="color:var(--accent);cursor:pointer" data-go="cal">Add an event</a></div>`}
$('#tlr').onchange=e=>{S.tlr=e.target.value;renderSched()};

/* ---------- buttons ---------- */
$('#mic').onclick=()=>{snd('wake');send({type:'listen_once'})};$('#focus').onclick=()=>send({type:'focus_toggle'});$('#fclr').onclick=()=>{send({type:'clear_log'});S.feed=[];S.notes=[];bell();feedInit()};
$('#gOrb').onclick=()=>orb(true);$('#gHome').onclick=()=>window.Earth&&Earth.focus(Earth.home.lat,Earth.home.lon);
on('ui',u=>{if(window.Earth&&Earth.setQuality&&u.perf!==undefined&&!(window.FPS<40))Earth.setQuality(u.perf?'low':'high')});
addEventListener('visibilitychange',()=>{if(!document.hidden)levelWant()});

/* ---------- ambient background (grid + sparse particles); paused when hidden or in performance mode ---------- */
(function(){const c=$('#bg'),x=c.getContext('2d');let w,h,P=[];const rs=()=>{w=c.width=innerWidth;h=c.height=innerHeight;P=Array.from({length:50},()=>({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.2+.3,v:Math.random()*.2+.04,a:Math.random()*6}))};rs();addEventListener('resize',rs);
 (function f(){requestAnimationFrame(f);if(document.hidden||document.body.classList.contains('perf')||S.page!=='dash')return;x.clearRect(0,0,w,h);const a=(window.ACCENT||[0,.9,1]).map(v=>Math.round(v*255)).join(',');x.strokeStyle=`rgba(${a},.03)`;for(let i=0;i<w;i+=64){x.beginPath();x.moveTo(i,0);x.lineTo(i,h);x.stroke()}for(let j=0;j<h;j+=64){x.beginPath();x.moveTo(0,j);x.lineTo(w,j);x.stroke()}
  P.forEach(p=>{p.y-=p.v;p.a+=.01;if(p.y<0){p.y=h;p.x=Math.random()*w}x.fillStyle=`rgba(${a},${.12+.2*Math.sin(p.a)**2})`;x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()})})()})();
/* ---------- opt-in widgets: weather (open-meteo, no key), world clocks, quick notes ---------- */
const WMO=c=>c===0?'Clear':c<4?'Partly cloudy':c<50?'Fog':c<60?'Drizzle':c<70?'Rain':c<80?'Snow':c<85?'Showers':'Storm';let WX=null,wxT=0,wxErr='';
function wxLoad(){if(Date.now()-wxT<9e5)return;wxT=Date.now();const h=window.Earth?Earth.home:{lat:28.6,lon:77.2};
 fetch(`https://api.open-meteo.com/v1/forecast?latitude=${h.lat}&longitude=${h.lon}&current=temperature_2m,weather_code,wind_speed_10m`).then(r=>r.json()).then(j=>{WX=j.current;wxErr='';renderWid()}).catch(()=>{wxErr='Weather unavailable offline';renderWid()})}
const ZONES=[['Tokyo','Asia/Tokyo'],['London','Europe/London'],['New York','America/New_York']];
function renderWid(){const u=UI(),p=$('#widp');p.style.display=u.widgets?'':'none';if(!u.widgets)return;wxLoad();
 const ta=document.activeElement&&document.activeElement.id==='qn';if(ta)return clk();
 $('#wid').innerHTML=`<div class="wr"><span>Weather</span><b>${WX?Math.round(WX.temperature_2m)+'°C, '+WMO(WX.weather_code)+', '+Math.round(WX.wind_speed_10m)+' km/h':wxErr||'Loading...'}</b></div><div id="clk"></div><div id="np"></div><div id="clipl"></div><textarea id="qn" placeholder="Quick notes" aria-label="Quick notes">${esc(u.qnote||'')}</textarea>`;clk()}
function clk(){npR();const e=$('#clk');if(e)e.innerHTML=ZONES.map(([n,z])=>`<div class="wr"><span>${n}</span><b class="num">${new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',timeZone:z})}</b></div>`).join('')}
setInterval(()=>{if($('#clk'))clk()},15000);
let NP=null;on('media',m=>{NP=m;npR()});function npR(){const e=$('#np');if(e)e.innerHTML=NP&&NP.title?`<div class="wr"><span>${NP.playing?'Now playing':'Paused'}</span><b style="max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(NP.title)}${NP.artist?' - '+esc(NP.artist):''}</b></div>`:''}
let CLIPS=[];on('clip',d=>{CLIPS=[d.text,...CLIPS.filter(x=>x!==d.text)].slice(0,5);clipR()});
function clipR(){const e=$('#clipl');if(e)e.innerHTML=CLIPS.length?'<div class="lbl" style="margin:6px 0 2px">Clipboard</div>'+CLIPS.map((c,i)=>`<button class="cap" data-clip="${i}" title="Copy again">${ico('copy')}<b style="text-transform:none;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">${esc(c.slice(0,60))}</b></button>`).join(''):''}
document.addEventListener('click',e=>{const b=e.target.closest('[data-clip]');if(b)navigator.clipboard.writeText(CLIPS[+b.dataset.clip]).then(()=>toast('Copied'))});
let _cw=null;on('ui',u=>{const w=!!u.widgets;if(w!==_cw){_cw=w;send({type:'clip_watch',on:w})}});on('init',()=>{_cw=null;applyUi()});on('ui',renderWid);on('init',renderWid);let qt;document.addEventListener('input',e=>{if(e.target.id==='qn'){clearTimeout(qt);qt=setTimeout(()=>setUi('qnote',e.target.value),600)}});
hydrate();state();renderCore();renderCaps();renderSched();initEarth();

/* ---------- orb mode: tiny always-on-top globe (desktop app) ---------- */
function orb(on){const api=window.pywebview&&pywebview.api;if(!api||!api.orb)return toast('Orb mode needs the desktop window.',{err:true});document.body.classList.toggle('orbmode',on);api.orb(on)}
document.addEventListener('dblclick',e=>{if(document.body.classList.contains('orbmode')&&e.target.closest('#hero'))orb(false)});
