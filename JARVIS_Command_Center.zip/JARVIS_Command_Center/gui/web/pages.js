/* Pages for the Command Center. Loaded after the core script in index.html. Everything here is real data. */
const pg=(t,body,extra='')=>`<div class="pn"><div class="pt">${t}${extra}</div>${body}</div>`;
const EX={open_app:'open notepad',close_app:'close notepad',type_text:'type hello world',web_search:'search for best laptops',system_info:'system status',volume:'volume up',screenshot:'take a screenshot',file_ops:'list files',time_date:'what time is it',power:'lock the screen',browser:'play lo-fi music on youtube'};
const KIND={user:['you','YOU'],jarvis:['jv','JARVIS'],error:['er','ERROR'],output:['out','OUTPUT'],info:['in','SYSTEM'],warn:['er','ALERT']};
const SAFE=new Set(['system_info','time_date','screenshot']);
const fmtAgo=t=>{if(!t)return 'never';const s=Math.floor(Date.now()/1e3-t);return s<60?s+'s ago':s<3600?Math.floor(s/60)+' min ago':Math.floor(s/3600)+' h ago'};
var modCard=function(t){const s=S.ts[t.name]||{},off=ST().agents[t.name]===false,ex=EX[t.name]||t.trigger;
 return`<div class="li" style="flex-direction:column;align-items:stretch;gap:6px;border-left-color:${off?'var(--dim)':s.state==='run'?'var(--a)':'var(--g)'}"><div style="display:flex;align-items:center;gap:8px"><span class="cy">${ico(TOOLICON[t.name]||'box')}</span><b style="text-transform:uppercase;letter-spacing:.08em;font:600 13px var(--rj)">${t.name.replace(/_/g,' ')}</b><span class="tag" style="margin-left:auto;color:${off?'var(--dim)':'var(--g)'};border-color:currentColor">${off?'OFF':s.state==='run'?'RUNNING':'READY'}</span></div>
  <small>${esc(t.description||'')}</small><small>Say: <span class="cy">"jarvis ${esc(ex)}"</span> · ${s.n||0} runs · last ${fmtAgo(s.last)}</small>
  <div style="display:flex;gap:6px"><button class="btn" data-modtog="${t.name}">${off?'Switch on':'Switch off'}</button>${SAFE.has(t.name)&&!off?`<button class="btn" data-c="${esc(ex)}">Try it</button>`:''}</div></div>`}
window.modModal=name=>{const t=S.tools.find(x=>x.name===name);if(t){modal(`<div class="pt">Module</div>`+modCard(t))}};
const PAGES={
 tasks:{t:'Tasks',coll:'tasks',f:[['title','Task title'],['due','Due','date']],r:x=>`<input type="checkbox" data-chk="${x.id}" ${x.done==='true'?'checked':''}><div><b>${esc(x.title)}</b>${x.due?`<small class="${x.due<today()&&x.done!=='true'?'r2':''}">Due ${x.due}${x.due<today()&&x.done!=='true'?' · OVERDUE':''}</small>`:''}</div>`,cls:x=>x.done==='true'?'done':''},
 cal:{t:'Calendar',coll:'events',f:[['title','Event title'],['date','Date','date'],['time','Time','time']],r:x=>`<div><b>${esc(x.title)}</b><small>${x.date} ${x.time||''} — JARVIS posts a reminder in the feed when it starts</small></div>`,sort:(a,b)=>(a.date+a.time).localeCompare(b.date+b.time)},
 mem:{t:'Memory',coll:'memory',f:[['text','Something for JARVIS to remember…']],r:x=>`<div><b>${esc(x.text)}</b><small>${new Date(x.ts*1e3).toLocaleString()}</small></div>`,hint:'JARVIS uses these facts when answering questions. You can also say: "jarvis remember that ...".'},
 kb:{t:'Knowledge Base',coll:'notes',f:[['title','Title'],['body','Note…','area']],r:x=>`<div><b>${esc(x.title)}</b><small>${esc(x.body||'')}</small></div>`},
 wf:{t:'Workflows',coll:'workflows',f:[['name','Workflow name'],['cmds','One command per line, e.g. open youtube',  'area']],r:x=>`<div><b>${esc(x.name)}</b><small>${(x.commands||[]).map(esc).join('\n')}</small></div><button class="btn" data-wf="${x.id}" style="margin-left:auto">Run ▸</button>`,hint:'Each line is sent to JARVIS exactly as if you had said it, in order.'}};
function listPage(k){const p=PAGES[k];let it=ST()[p.coll].slice();if(p.sort)it.sort(p.sort);
 return pg(`${p.t} · ${it.length}`,`${p.hint?`<div class="empty" style="margin-bottom:8px">${p.hint}</div>`:''}<div class="frm">${p.f.map(([id,ph,ty])=>ty==='area'?`<textarea id="f_${id}" placeholder="${ph}"></textarea>`:`<input id="f_${id}" type="${ty||'text'}" placeholder="${ph}" ${ty?'':'style="flex:1;min-width:220px"'}>`).join('')}<button class="btn" data-add="${k}">${ico('plus')}Add</button></div>
 ${it.map(x=>`<div class="li ${p.cls?p.cls(x):''}">${p.r(x)}<span class="x" data-del="${p.coll}|${x.id}" title="Delete">${ico('x')}</span></div>`).join('')||'<div class="empty">Nothing here yet.</div>'}`)}
function doAdd(k){const p=PAGES[k],it={};p.f.forEach(([id])=>it[id]=val('f_'+id).trim());if(!it[p.f[0][0]])return toast('Please fill in the first field.');
 if(k==='wf'){it.commands=it.cmds.split('\n').map(s=>s.trim()).filter(Boolean);delete it.cmds}if(k==='tasks')it.done='false';put({op:'add',coll:p.coll,item:it})}
const kvp=(a,b,c='cy')=>`<div class="li"><b>${a}</b><span class="${c}" style="margin-left:auto">${esc(b)}</span></div>`;
function corePage(){const s=S.st;return pg('AI Core',kvp('Status',S.status)+kvp('Backend link',S.online?'ONLINE':'OFFLINE',S.online?'g':'r2')+kvp('Voice input',S.mic==='error'?'MIC ERROR':S.mode==='active'?'Always listening':'Wake word "'+S.wake+'"')+kvp('Speech engine',S.meta.stt)+kvp('Fast model',S.fast)+kvp('Strong model',S.strong)+kvp('Groq API keys',S.keys,S.keys?'g':'r2')+kvp('Modules loaded',S.tools.length)+kvp('Memory facts',ST().memory.length)+kvp('System uptime',fmtU(s.uptime)))}
function convoPage(){const q=(window._cq||'').toLowerCase(),it=CH.filter(m=>m.k!=='trace'&&m.text&&(!q||m.text.toLowerCase().includes(q))).slice().reverse();
 return pg(`Conversations - ${it.length}`,`<div class="frm"><input id="cq2" type="search" placeholder="Search history" value="${esc(window._cq||'')}" style="flex:1" aria-label="Search history"><button class="btn" id="cexp">Export</button></div>${it.slice(0,300).map(m=>{const who={you:'You',jv:'JARVIS',out:'Output',er:'Error'}[m.k];const c={you:'cy',jv:'pu',out:'dm',er:'r2'}[m.k];
 return`<div class="li" style="border-left-color:var(--${m.k==='jv'?'ai':m.k==='er'?'err':m.k==='out'?'info':'accent'})"><b class="${c}" style="width:64px;font:700 12px var(--rj);letter-spacing:.1em;text-transform:uppercase">${who}</b><div style="flex:1;min-width:0">${m.k==='out'?`<pre style="white-space:pre-wrap;font:13px ui-monospace,Consolas,monospace">${esc(m.text.slice(0,1200))}</pre>`:md(m.text)}</div><small style="color:var(--dim)">${new Date(m.ts).toLocaleString()}</small></div>`}).join('')||'<div class="empty">No messages match.</div>'}`)}
function modulesPage(){return pg(`Modules · ${S.tools.length}`,`<div class="empty" style="margin-bottom:8px">Each module is a real tool JARVIS can run. Switching one off blocks it for voice commands, routines and the AI planner.</div><div class="grid2">${S.tools.map(modCard).join('')}</div>`)}
const STEP={open:['Open app / site / file','App name, path or URL',''],close_all:['Close all windows','Keep titles containing (comma list)','ask = confirm first'],wait:['Wait (seconds)','5',''],click_xy:['Click position','x,y',''],click_image:['Click a button image','Path to button PNG','Search seconds'],key:['Press key / combo','enter  or  ctrl+shift+t',''],type:['Type text','Text to type',''],say:['Say aloud','Sentence','']};
const stepRow=(s,i)=>`<div class="li st" style="flex-wrap:wrap"><span class="cy">${i+1}</span><select class="t frm-s" style="background:#06182c;color:#fff;border:1px solid var(--line);padding:6px;border-radius:3px">${Object.entries(STEP).map(([k,x])=>`<option value="${k}" ${s.type===k?'selected':''}>${x[0]}</option>`).join('')}</select>
 <input class="v" style="flex:1;min-width:200px;background:rgba(0,229,255,.05);border:1px solid var(--line);color:#fff;padding:7px;border-radius:3px" placeholder="${(STEP[s.type]||['','',''])[1]}" value="${esc(s.v||'')}"><input class="v2" style="width:150px;background:rgba(0,229,255,.05);border:1px solid var(--line);color:#fff;padding:7px;border-radius:3px" placeholder="${(STEP[s.type]||['','',''])[2]||'(optional)'}" value="${esc(s.v2||'')}">
 ${s.type==='click_xy'?`<button class="btn" data-pos="${i}">Record position</button>`:''}<span class="x" data-rmstep="${i}" title="Remove step">${ico('x')}</span></div>`;
const routinesPage=()=>pg('Voice Routines',`<div class="empty" style="margin-bottom:10px">Say <b>"${S.wake} &lt;phrase&gt;"</b> or type the phrase. Phrases are what you say <i>after</i> the wake word — "start jarvis gaming" triggers <b>gaming</b>. Separate several phrases with commas. <a id="rtnew" style="color:var(--c);cursor:pointer">+ New routine</a></div>
 ${ST().routines.map(r=>`<div class="pn" style="margin-bottom:12px;overflow:visible" data-rid="${r.id}"><div class="frm" style="margin-bottom:8px"><input class="rn" style="width:200px" value="${esc(r.name)}" placeholder="Routine name"><input class="rp" style="flex:1;min-width:220px" value="${esc((r.phrases||[]).join(', '))}" placeholder="Phrases, comma separated">
 <button class="btn" data-rtest="${r.id}">▶ Test</button><button class="btn" data-rsave="${r.id}">Save</button><button class="btn" data-radd="${r.id}">+ Step</button><span class="x" data-del="routines|${r.id}" style="color:var(--r);cursor:pointer;align-self:center">${ico('x')}</span></div>
 ${(r.steps||[]).map(stepRow).join('')||'<div class="empty">No steps yet — click + Step.</div>'}</div>`).join('')||'<div class="empty">No routines yet.</div>'}
 <div class="empty">Click steps need pyautogui. Slam the mouse into a screen corner to abort a running click routine.</div>`);
const sw=(id,on,l)=>`<button class="tg" role="switch" aria-checked="${!!on}" aria-label="${l}" id="${id}"></button>`;
const hr=(t,d,c)=>`<div class="hrow"><div class="d"><b>${t}</b><small>${d||''}</small></div>${c}</div>`;
window.keyTable=()=>{const t=$('#ktab');if(!t)return;const k=S.keyhealth||[];t.innerHTML=k.length?`<table class="kt"><tr><th>Slot</th><th>Status</th></tr>${k.map(x=>`<tr><td>Key #${x.slot}</td><td><span class="chip ${x.state==='ok'?'ok':x.state==='rejected'?'err':'warn'}">${x.state}${x.wait?' ('+x.wait+' s)':''}</span></td></tr>`).join('')}</table>`:'<div class="empty">No API keys loaded. Add them to your .env file.</div>'};
function settingsPage(){const u=UI(),ac=[['cyan','#00e5ff','Cyan'],['gold','#ffb020','Stark gold'],['crimson','#ff4d6a','Crimson'],['emerald','#2ee59d','Emerald']];
 const mics=S.mics||[];
 return pg('Appearance',hr('Accent colour','Used for the brand, primary actions and the idle Earth.',`<div class="sw">${ac.map(([k,c,n])=>`<button data-accent="${k}" class="${(u.accent||'cyan')===k?'on':''}" style="background:${c}" aria-label="${n}" data-tip="${n}"></button>`).join('')}</div>`)+
  hr('UI scale',(u.scale||100)+'%',`<input type="range" id="sc" min="80" max="130" step="5" value="${u.scale||100}" aria-label="UI scale">`)+
  hr('High contrast','Brighter text and borders.',sw('hc',u.contrast,'High contrast'))+
  hr('Layout','Command, Focus (globe and conversation) or Monitor.',`<div class="seg">${['command','focus','monitor'].map(l=>`<button data-lay="${l}" class="${(u.layout||'command')===l?'on':''}" style="width:auto;padding:0 10px;font:600 13px var(--rj)">${l[0].toUpperCase()+l.slice(1)}</button>`).join('')}</div>`)+
  hr('Sidebar','Icon-only rail saves space (Ctrl+B). Automatic below 1400 px.',`<select id="railsel" aria-label="Sidebar"><option value="auto">Automatic</option><option value="full">Always full</option><option value="compact">Always compact</option></select>`)+
  hr('Performance mode',`Fewer effects and a lighter Earth. Turns on by itself below 40 fps. Current: ${window.FPS||'-'} fps.`,sw('perf',u.perf,'Performance mode')))+
 pg('Desktop and widgets',hr('Ambient widgets','Weather (open-meteo, internet needed), world clocks and quick notes on the dashboard.',sw('wid',u.widgets,'Widgets'))+hr('Start with Windows','Launch JARVIS when you sign in.',sw('stup',S.startup,'Start with Windows'))+hr('Summon hotkey','Ctrl+Space brings JARVIS to the front (desktop app only).',''))+
 pg('Sound',hr('Interface sounds','Short cues for wake, understood, success and error.',sw('snd',u.sound!==false,'Interface sounds'))+hr('Volume',(u.vol==null?35:u.vol)+'%',`<input type="range" id="vol" min="0" max="100" value="${u.vol==null?35:u.vol}" aria-label="Volume">`))+
 pg('Voice',hr('Microphone level',S.online?'Live input level. Shows whether JARVIS can hear you.':'Backend offline.',`<div class="meter" aria-hidden="true"><i id="mlev"></i></div>`)+
  hr('Input device','Used for the level meter and for voice recognition.',`<select id="micsel" aria-label="Input device"><option value="">System default</option>${mics.map(m=>`<option value="${m.id}">${esc(m.name)}</option>`).join('')}</select>`)+
  hr('Listening mode',S.mode==='active'&&!S.oneshot?'Always listening.':'Wake word "'+S.wake+'".',`<button class="btn" id="focus2">${S.mode==='active'&&!S.oneshot?'Switch to wake word':'Always listen'}</button>`)+
  hr('Speech engine','Whisper is more accurate (needs a Groq key); Google works without one.',`<select id="sttsel" aria-label="Speech engine"><option value="whisper">Whisper (Groq)</option><option value="google">Google</option></select>`)+
  hr('Listening sensitivity','Higher picks up quieter speech; lower ignores room noise. '+(u.sens==null?50:u.sens)+'%',`<input type="range" id="sens" min="0" max="100" value="${u.sens==null?50:u.sens}" aria-label="Listening sensitivity">`)+
  hr('Voice','Voice JARVIS speaks with.',`<select id="ttsv" aria-label="TTS voice"><option value="">Default (David if installed)</option>${(window.TTSV||[]).map(v=>`<option value="${esc(v.id)}" ${u.tts_voice===v.id?'selected':''}>${esc(v.name)}</option>`).join('')}</select>`)+
  hr('Speaking speed',(u.tts_rate||'default')+' wpm',`<input type="range" id="ttsr" min="110" max="260" step="5" value="${u.tts_rate||175}" aria-label="Speaking speed"><button class="btn sm" id="ttst" style="margin-left:8px">Test voice</button>`)+hr('Fast / strong model',esc(S.fast)+' / '+esc(S.strong),''))+
 pg('API key health',`<div id="ktab"></div>`)+
 pg('Data',hr('Export','Tasks, events, memory, notes, workflows and routines as JSON.',`<button class="btn" id="dexp">Export</button>`)+hr('Import','Replaces matching collections from a JSON export.',`<button class="btn" id="dimp">Import</button><input type="file" id="dfile" accept="application/json" hidden>`)+
  hr('Data folder',esc(S.dataDir||''),`<button class="btn" id="dopen">Open folder</button>`)+hr('Clear system events','Empties the event feed.',`<button class="btn dng" id="clr">Clear</button>`)+hr('Clear conversation history','Removes the saved dialogue from this app.',`<button class="btn dng" id="cclr2">Clear</button>`))}
window.renderPage=()=>{const k=S.page,v=$('#page');const fn=PAGES[k]?()=>listPage(k):{core:corePage,modules:modulesPage,convo:convoPage,routines:routinesPage,settings:settingsPage}[k];v.innerHTML=fn?fn():'';hydrate(v)};
function collect(rid){const el=document.querySelector(`[data-rid="${rid}"]`);if(!el)return null;return{name:el.querySelector('.rn').value.trim()||'Routine',phrases:el.querySelector('.rp').value.split(',').map(s=>s.trim()).filter(Boolean),steps:[...el.querySelectorAll('.st')].map(r=>({type:r.querySelector('.t').value,v:r.querySelector('.v').value.trim(),v2:r.querySelector('.v2').value.trim()}))}}
const saveR=(rid,mut)=>{const c=collect(rid);if(!c)return;if(mut)mut(c);put({op:'update',coll:'routines',id:rid,item:c})};
document.addEventListener('click',e=>{const t=e.target;let m;
 if(m=t.closest('[data-modtog]')){const n=m.dataset.modtog,on=ST().agents[n]===false;put({op:'agent',coll:n,on});send({type:'tool_enable',name:n,on});setTimeout(()=>{if($('#mdl').classList.contains('show'))window.modModal(n)},50);return}
 if(m=t.closest('[data-add]'))return doAdd(m.dataset.add);
 if(m=t.closest('[data-del]')){const[c,id]=m.dataset.del.split('|'),old=(ST()[c]||[]).find(x=>x.id===id);put({op:'delete',coll:c,id});if(old){const{id:_i,ts:_t,...rest}=old;toast('Deleted',{undo:()=>put({op:'add',coll:c,item:rest})})}return}
 if(m=t.closest('[data-chk]'))return put({op:'update',coll:'tasks',id:m.dataset.chk,item:{done:String(m.checked)}});
 if(t.id==='clr'){send({type:'clear_log'});S.feed=[];feedInit();toast('Events cleared');return}
  if(t.closest('#focus2'))return send({type:'focus_toggle'});
 if(t.id==='rtnew')return put({op:'add',coll:'routines',item:{name:'New routine',phrases:['new phrase'],steps:[{type:'open',v:'',v2:''}]}});
 if(m=t.closest('[data-rsave]')){saveR(m.dataset.rsave);return toast('Saved')}
 if(m=t.closest('[data-radd]'))return saveR(m.dataset.radd,c=>c.steps.push({type:'open',v:'',v2:''}));
 if(m=t.closest('[data-rmstep]')){const rid=m.closest('[data-rid]').dataset.rid,i=+m.dataset.rmstep;return saveR(rid,c=>c.steps.splice(i,1))}
 if(m=t.closest('[data-rtest]')){const c=collect(m.dataset.rtest);if(c&&c.phrases[0]){saveR(m.dataset.rtest);setTimeout(()=>cmd(c.phrases[0]),300)}return}
 if(m=t.closest('[data-pos]')){const rid=m.closest('[data-rid]').dataset.rid;window._posKey=rid+'|'+m.dataset.pos;m.textContent='Hover the button… 5';send({type:'capture_pos',key:window._posKey})}},true);
document.addEventListener('change',e=>{if(e.target.matches('.st .t'))saveR(e.target.closest('[data-rid]').dataset.rid)});
document.addEventListener('input',e=>{});
window.onExtra=d=>{if(d.type==='init'){S.dataDir=d.data_dir}
 if(d.type==='pos'&&d.key===window._posKey){const[rid,i]=d.key.split('|'),row=document.querySelector(`[data-rid="${rid}"]`)?.querySelectorAll('.st')[+i],b=row&&row.querySelector('[data-pos]');
  if(d.countdown&&b)b.textContent='Hover the button… '+d.countdown;if(d.x!==undefined&&row){row.querySelector('.v').value=d.x+','+d.y;if(b)b.textContent='Record position';saveR(rid)}}
 if((d.type==='tools'||d.type==='state')&&['core','modules','settings'].includes(S.page))renderPage()};

document.addEventListener('click',e=>{const t=e.target;let m;
 if(m=t.closest('[data-accent]')){setUi('accent',m.dataset.accent);renderPage();return}
 const tg=t.closest('.tg');if(tg&&S.page==='settings'){const v=tg.getAttribute('aria-checked')!=='true';({wid:()=>setUi('widgets',v),stup:()=>send({type:'startup',on:v}),hc:()=>setUi('contrast',v),perf:()=>setUi('perf',v),snd:()=>{setUi('sound',v);if(v)snd('ok')}})[tg.id]?.();tg.setAttribute('aria-checked',v);return}
 if(t.id==='dexp')return send({type:'export_store'});if(t.id==='dimp')return $('#dfile').click();if(t.id==='dopen')return send({type:'open_folder'});
 if(t.id==='cclr2'){CH=[];persist();toast('Conversation history cleared');return}if(t.id==='cexp'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([CH.filter(x=>x.k!=='trace').map(x=>`[${new Date(x.ts).toLocaleString()}] ${x.k}: ${x.text}`).join('\n')],{type:'text/plain'}));a.download='jarvis-conversation.txt';a.click()}},true);
document.addEventListener('change',e=>{const t=e.target;if(t.id==='dfile'&&t.files[0]){t.files[0].text().then(x=>{try{send({type:'import_store',data:JSON.parse(x)});toast('Imported')}catch(err){toast('That file is not valid JSON',{err:true})}})}
 if(t.id==='railsel')setUi('rail',t.value==='auto'?'':t.value);if(t.id==='micsel')send({type:'choose_mic',id:t.value===''?null:+t.value})});
document.addEventListener('input',e=>{const t=e.target;if(t.id==='sc')setUi('scale',+t.value);if(t.id==='vol'){setUi('vol',+t.value);tone(660,.08)}if(t.id==='cq2'){window._cq=t.value;const p=t.selectionStart;renderPage();const n=$('#cq2');n&&(n.focus(),n.setSelectionRange(p,p))}});
on('level',d=>{const i=$('#mlev');if(i)i.style.width=Math.min(100,d.v*100)+'%'});on('level_error',d=>{if(S.page==='settings'&&!window._lvErr){window._lvErr=1;toast('Mic meter: '+d.error,{err:true})}});
const _rp=window.renderPage;window.renderPage=()=>{_rp();if(S.page==='settings'){keyTable();const r=$('#railsel');if(r)r.value=UI().rail||'auto'}levelWant()};

/* ---- Tasks board + Calendar month grid ---- */
const PRI={high:['hi','High','err'],normal:['','Normal','info'],low:['lo','Low','']};
function taskCard(x){const td=today(),od=x.due&&x.due<td&&x.done!=='true',pr=PRI[x.p]||PRI.normal;
 return`<div class="tcard ${pr[0]} ${x.done==='true'?'done':''}"><input type="checkbox" data-chk="${x.id}" ${x.done==='true'?'checked':''} aria-label="Done: ${esc(x.title)}"><div class="b"><b>${esc(x.title)}</b><div class="chips">${x.due?`<span class="chip ${od?'err':''}">${od?'Overdue ':''}${x.due}</span>`:''}${x.p&&x.p!=='normal'?`<span class="chip ${pr[2]}">${pr[1]}</span>`:''}</div></div><span class="x" role="button" tabindex="0" aria-label="Delete task" data-del="tasks|${x.id}" style="cursor:pointer;color:var(--dim)">${ico('x')}</span></div>`}
function tasksBoard(){const td=today(),T=ST().tasks,open=T.filter(t=>t.done!=='true'),col=(n,a)=>`<div class="bcol"><h3>${n}<span class="chip">${a.length}</span></h3>${a.map(taskCard).join('')||'<div class="empty">Nothing here.</div>'}</div>`;
 return pg('Tasks',`<div class="frm"><input id="tt" placeholder="New task" style="flex:1;min-width:220px" aria-label="Task title"><input id="td" type="date" aria-label="Due date"><select id="tp" aria-label="Priority"><option value="normal">Normal</option><option value="high">High</option><option value="low">Low</option></select><button class="btn pri" id="tadd">Add task</button></div>
 <div class="board">${col('Today',open.filter(t=>!t.due||t.due<=td))}${col('Upcoming',open.filter(t=>t.due&&t.due>td))}${col('Done',T.filter(t=>t.done==='true').slice(-20))}</div>`)}
window._cm=window._cm||new Date();
function calPage(){const m=window._cm,y=m.getFullYear(),mo=m.getMonth(),first=new Date(y,mo,1),start=new Date(y,mo,1-((first.getDay()+6)%7)),td=today(),E=ST().events;let cells='';
 for(let i=0;i<42;i++){const d=new Date(start.getFullYear(),start.getMonth(),start.getDate()+i),k=d.toLocaleDateString('en-CA'),ev=E.filter(e=>e.date===k).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
  cells+=`<button class="dc ${d.getMonth()!==mo?'o':''} ${k===td?'t':''}" data-day="${k}" aria-label="${k}, ${ev.length} events"><b>${d.getDate()}</b>${ev.slice(0,3).map(e=>`<span class="ev">${e.time?e.time+' ':''}${esc(e.title)}</span>`).join('')}${ev.length>3?`<span class="dm" style="font-size:12px">+${ev.length-3} more</span>`:''}</button>`}
 return pg('Calendar',`<div class="frm" style="align-items:center"><button class="btn ib" data-cal="-1" aria-label="Previous month">${ico('chev')}</button><b class="hd" style="min-width:190px;text-align:center;font-size:16px">${m.toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</b><button class="btn ib" data-cal="1" aria-label="Next month" style="transform:rotate(180deg)">${ico('chev')}</button><button class="btn" data-cal="0">Today</button></div>
 <div class="cal">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d=>`<div class="dh">${d}</div>`).join('')}${cells}</div><div class="empty" style="margin-top:8px">Click a day to add or remove events. JARVIS posts a reminder in System events when one starts.</div>`)}
function dayModal(k){const ev=ST().events.filter(e=>e.date===k).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
 modal(`<div class="pt">${k}</div>${ev.map(e=>`<div class="row"><b>${e.time||'--:--'} ${esc(e.title)}</b><button class="btn sm dng" data-evdel="${e.id}" aria-label="Delete event">${ico('x')}</button></div>`).join('')||'<div class="empty">No events.</div>'}<div class="frm" style="margin-top:12px"><input id="et" placeholder="Event title" style="flex:1" aria-label="Event title"><input id="etm" type="time" aria-label="Time"><button class="btn pri" id="eadd" data-k="${k}">Add</button></div>`)}
const _rp2=window.renderPage;window.renderPage=()=>{if(S.page==='tasks'||S.page==='cal'){const v=$('#page'),sc=v.scrollTop;v.innerHTML=S.page==='tasks'?tasksBoard():calPage();hydrate(v);v.scrollTop=sc;return}_rp2()};
document.addEventListener('click',e=>{const t=e.target;let m;
 if(t.id==='tadd'){const v=val('tt').trim();if(!v)return toast('Type a task first.',{err:true});put({op:'add',coll:'tasks',item:{title:v,due:val('td'),p:val('tp'),done:'false'}});return}
 if(m=t.closest('[data-cal]')){const d=window._cm;window._cm=m.dataset.cal==='0'?new Date():new Date(d.getFullYear(),d.getMonth()+ +m.dataset.cal,1);renderPage();return}
 if(m=t.closest('[data-day]'))return dayModal(m.dataset.day);
 if(t.id==='eadd'){const v=val('et').trim();if(!v)return toast('Give the event a title.',{err:true});put({op:'add',coll:'events',item:{title:v,date:t.dataset.k,time:val('etm')}});dayModal(t.dataset.k);return}
 if(m=t.closest('[data-evdel]')){const id=m.dataset.evdel,k=(ST().events.find(x=>x.id===id)||{}).date;put({op:'delete',coll:'events',id});k&&dayModal(k)}},true);

/* ---- Workflows as step cards (drag-reorder, test step, enable, import/export), Memory cards, module usage ---- */
const sIcon=c=>/youtube|play|music/.test(c)?'play':/open|launch|start/.test(c)?'grid':/search|google|find/.test(c)?'search':/volume|mute/.test(c)?'vol':/screenshot/.test(c)?'camera':/status|system/.test(c)?'act':/type/.test(c)?'type':'chat';
function wfPage(){const W=ST().workflows;
 return pg('Workflows',`<div class="empty" style="margin-bottom:8px">Each step is a command JARVIS runs in order. Drag cards to reorder, test a single step, or switch a workflow off.</div>
 <div class="frm"><input id="wn" placeholder="New workflow name" style="flex:1;min-width:200px" aria-label="Workflow name"><button class="btn pri" id="wadd">Create</button><button class="btn" id="wimp">Import JSON</button><input type="file" id="wfile" accept="application/json" hidden></div>
 ${W.map(w=>{const off=w.off==='true'||w.off===true;return`<div class="pn" data-wid="${w.id}" style="${off?'opacity:.6':''}"><div class="ph"><div class="pt">${esc(w.name)}</div><span class="sp"></span><span class="chip ${off?'':'ok'}">${off?'Off':'On'}</span><button class="tg" role="switch" aria-checked="${!off}" data-wtog="${w.id}" aria-label="Enable ${esc(w.name)}"></button>
  <button class="btn sm pri" data-wf="${w.id}" ${off?'disabled':''}>${ico('play')}Run</button><button class="btn sm" data-wexp="${w.id}">Export</button><button class="btn sm dng" data-del="workflows|${w.id}" aria-label="Delete workflow">${ico('x')}</button></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:stretch">${(w.commands||[]).map((c,i)=>`<div class="wstep" draggable="true" data-wi="${i}"><span class="n">${i+1}</span>${ico(sIcon(c))}<span class="c">${esc(c)}</span><button class="btn sm ghost ib" data-wtest="${esc(c)}" aria-label="Test this step" data-tip="Test this step">${ico('play')}</button><button class="btn sm ghost ib" data-wrm="${w.id}|${i}" aria-label="Remove step">${ico('x')}</button></div>`).join('')||'<div class="empty">No steps yet.</div>'}
  <div class="wstep add"><input data-wnew="${w.id}" placeholder="Add step, e.g. open youtube" aria-label="New step"></div></div></div>`}).join('')||'<div class="empty">No workflows yet.</div>'}`)}
var memPage=function(){const q=(window._mq||'').toLowerCase(),M=ST().memory.filter(m=>!q||m.text.toLowerCase().includes(q)).slice().reverse(),tags=[...new Set(ST().memory.flatMap(m=>(m.text.match(/#\w+/g)||[])))];
 return pg(`Memory - ${M.length}`,`<div class="empty" style="margin-bottom:8px">JARVIS uses these facts when answering. Add #tags to group them. Say: "jarvis remember that ...".</div>
 <div class="frm"><input id="mq" type="search" placeholder="Search memory" value="${esc(window._mq||'')}" style="flex:1" aria-label="Search memory"></div>
 <div class="frm"><input id="mt" placeholder="Remember something (use #tags)" style="flex:1;min-width:220px" aria-label="New memory"><button class="btn pri" id="madd">Remember</button></div>
 ${tags.length?`<div class="frm">${tags.map(t=>`<button class="chip" data-mtag="${t}">${t}</button>`).join('')}</div>`:''}
 <div class="grid2">${M.map(m=>`<div class="tcard"><div class="b"><b style="font-weight:500">${esc(m.text).replace(/#\w+/g,t=>`<span class="cy">${t}</span>`)}</b><div class="chips"><span class="chip">${new Date(m.ts*1e3).toLocaleDateString()}</span></div></div><span class="x" role="button" tabindex="0" aria-label="Delete memory" data-del="memory|${m.id}" style="cursor:pointer;color:var(--dim)">${ico('x')}</span></div>`).join('')||'<div class="empty">Nothing remembered yet.</div>'}</div>`)}
const _rp3=window.renderPage;window.renderPage=()=>{if(S.page==='wf'||S.page==='mem'){const v=$('#page'),sc=v.scrollTop;v.innerHTML=S.page==='wf'?wfPage():memPage();hydrate(v);v.scrollTop=sc;return}_rp3()};
const wfSet=(id,fn)=>{const w=ST().workflows.find(x=>x.id===id);if(w){const c=[...(w.commands||[])];fn(c);put({op:'update',coll:'workflows',id,item:{commands:c}})}};
let dragI=null;document.addEventListener('dragstart',e=>{const s=e.target.closest&&e.target.closest('.wstep[data-wi],.st');if(s){dragI=s;e.dataTransfer.effectAllowed='move'}});
document.addEventListener('dragover',e=>{if(dragI&&e.target.closest('.wstep[data-wi],.st'))e.preventDefault()});
document.addEventListener('drop',e=>{const d=e.target.closest&&e.target.closest('.wstep[data-wi],.st');if(!d||!dragI||d===dragI){dragI=null;return}e.preventDefault();
 if(dragI.matches('.wstep')){const id=d.closest('[data-wid]').dataset.wid,a=+dragI.dataset.wi,b=+d.dataset.wi;wfSet(id,c=>c.splice(b,0,c.splice(a,1)[0]))}
 else if(dragI.parentNode===d.parentNode){const rid=d.closest('[data-rid]').dataset.rid;d.parentNode.insertBefore(dragI,[...d.parentNode.children].indexOf(dragI)<[...d.parentNode.children].indexOf(d)?d.nextSibling:d);saveR(rid)}dragI=null});
document.addEventListener('click',e=>{const t=e.target;let m;
 if(t.id==='wadd'){const n=val('wn').trim();if(!n)return toast('Name the workflow first.',{err:true});put({op:'add',coll:'workflows',item:{name:n,commands:[],off:'false'}});return}
 if(m=t.closest('[data-wtog]')){const id=m.dataset.wtog,w=ST().workflows.find(x=>x.id===id);put({op:'update',coll:'workflows',id,item:{off:String(!(w.off==='true'))}});return}
 if(m=t.closest('[data-wtest]'))return cmd(m.dataset.wtest);
 if(m=t.closest('[data-wrm]')){const[id,i]=m.dataset.wrm.split('|');return wfSet(id,c=>c.splice(+i,1))}
 if(m=t.closest('[data-wexp]')){const w=ST().workflows.find(x=>x.id===m.dataset.wexp),a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({name:w.name,commands:w.commands||[]},null,1)],{type:'application/json'}));a.download=(w.name||'workflow').replace(/\W+/g,'_')+'.json';a.click();return}
 if(t.id==='wimp')return $('#wfile').click();
 if(t.id==='madd'){const v=val('mt').trim();if(!v)return toast('Type something to remember.',{err:true});put({op:'add',coll:'memory',item:{text:v}});return}
 if(m=t.closest('[data-mtag]')){window._mq=m.dataset.mtag;renderPage()}},true);
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.dataset&&e.target.dataset.wnew&&e.target.value.trim()){const v=e.target.value.trim();wfSet(e.target.dataset.wnew,c=>c.push(v))}});
document.addEventListener('change',e=>{if(e.target.id==='wfile'&&e.target.files[0])e.target.files[0].text().then(x=>{try{const o=JSON.parse(x);if(!o.name||!Array.isArray(o.commands))throw 0;put({op:'add',coll:'workflows',item:{name:String(o.name).slice(0,80),commands:o.commands.map(c=>String(c).slice(0,200)),off:'false'}});toast('Workflow imported')}catch(err){toast('Not a valid workflow file',{err:true})}})});
document.addEventListener('input',e=>{if(e.target.id==='mq'){window._mq=e.target.value;const p=e.target.selectionStart;renderPage();const n=$('#mq');n&&(n.focus(),n.setSelectionRange(p,p))}});
/* module usage chart */
const _mc=modCard;modCard=t=>_mc(t).replace(/<div style="display:flex;gap:6px">/,`<div class="lbl">Runs, last hour (this session)</div>${typeof mini==='function'?mini(t.name):''}<div style="display:flex;gap:6px">`);
/* make routine steps draggable */
new MutationObserver(()=>document.querySelectorAll('.st:not([draggable])').forEach(x=>x.setAttribute('draggable','true'))).observe(document.getElementById('page'),{childList:true,subtree:true});

/* Calendar drag-to-create: drag across days, name the event, it is added to every day in the range */
let dg=null;document.addEventListener('mousedown',e=>{const d=e.target.closest('.dc[data-day]');if(d&&S.page==='cal'){dg={a:d.dataset.day,b:d.dataset.day}}});
document.addEventListener('mouseover',e=>{const d=e.target.closest('.dc[data-day]');if(dg&&d){dg.b=d.dataset.day;const[lo,hi]=[dg.a,dg.b].sort();document.querySelectorAll('.dc').forEach(x=>x.classList.toggle('sel',x.dataset.day>=lo&&x.dataset.day<=hi))}});
document.addEventListener('mouseup',e=>{if(!dg)return;const g=dg;dg=null;document.querySelectorAll('.dc.sel').forEach(x=>x.classList.remove('sel'));if(g.a===g.b)return;
 const[lo,hi]=[g.a,g.b].sort();window._suppressDay=true;setTimeout(()=>window._suppressDay=false,50);
 modal(`<div class="pt">New event, ${lo} to ${hi}</div><div class="frm"><input id="rt" placeholder="Event title" style="flex:1" aria-label="Event title"><input id="rtm" type="time" aria-label="Time"><button class="btn pri" id="radd" data-lo="${lo}" data-hi="${hi}">Add to each day</button></div>`)});
document.addEventListener('click',e=>{if(window._suppressDay&&e.target.closest('[data-day]')){e.stopImmediatePropagation();e.preventDefault()}},true);
document.addEventListener('click',e=>{if(e.target.id==='radd'){const v=val('rt').trim();if(!v)return toast('Give the event a title.',{err:true});const t=e.target;for(let d=new Date(t.dataset.lo+'T12:00');d.toLocaleDateString('en-CA')<=t.dataset.hi;d.setDate(d.getDate()+1))put({op:'add',coll:'events',item:{title:v,date:d.toLocaleDateString('en-CA'),time:val('rtm')}});closeM()}},true);

/* voice settings wiring */
on('tts_voices',d=>{window.TTSV=d.voices;if(S.page==='settings')renderPage()});
document.addEventListener('change',e=>{const t=e.target;if(t.id==='sttsel')setUi('stt',t.value);if(t.id==='ttsv')setUi('tts_voice',t.value)});
document.addEventListener('input',e=>{if(e.target.id==='sens')setUi('sens',+e.target.value);if(e.target.id==='ttsr')setUi('tts_rate',+e.target.value)});
document.addEventListener('click',e=>{if(e.target.id==='ttst')send({type:'tts_test'})});
const _rp4=window.renderPage;window.renderPage=()=>{_rp4();if(S.page==='settings'){const s=$('#sttsel');if(s)s.value=UI().stt||'whisper';if(!window.TTSV&&!window._ttsAsk){window._ttsAsk=1;send({type:'tts_voices'})}}};
/* memory: cards or graph (nodes linked by shared #tags or shared keywords) */
function memGraph(){const M=ST().memory.slice(-36),W=900,H=420,cx=W/2,cy=H/2,R=Math.min(W,H)/2-50,kw=m=>new Set((m.text.toLowerCase().match(/[a-z]{5,}/g)||[]).concat(m.text.match(/#\w+/g)||[])),K=M.map(kw);
 const pos=M.map((m,i)=>{const a=i/M.length*Math.PI*2-Math.PI/2;return[cx+Math.cos(a)*R,cy+Math.sin(a)*R*.85]});let L='';
 for(let i=0;i<M.length;i++)for(let j=i+1;j<M.length;j++){let n=0;K[i].forEach(w=>K[j].has(w)&&n++);if(n)L+=`<line x1="${pos[i][0]}" y1="${pos[i][1]}" x2="${pos[j][0]}" y2="${pos[j][1]}" stroke="var(--accent)" stroke-opacity="${Math.min(.7,.18*n)}"/>`}
 return M.length?`<div style="overflow:auto"><svg viewBox="0 0 ${W} ${H}" style="width:100%;min-width:640px" role="img" aria-label="Memory graph">${L}${M.map((m,i)=>`<g><circle cx="${pos[i][0]}" cy="${pos[i][1]}" r="6" fill="var(--accent)"/><text x="${pos[i][0]+(pos[i][0]<cx?-10:10)}" y="${pos[i][1]+4}" text-anchor="${pos[i][0]<cx?'end':'start'}" fill="var(--tx2)" font-size="12">${esc(m.text.slice(0,26))}</text><title>${esc(m.text)}</title></g>`).join('')}</svg></div><div class="empty">Lines connect memories that share a #tag or a keyword.</div>`:'<div class="empty">Nothing remembered yet.</div>'}
const _mp=memPage;memPage=function(){let h=_mp();const g=window._mg;h=h.replace('<div class="frm"><input id="mq"',`<div class="frm"><button class="btn ${g?'':'on'}" id="mcards">Cards</button><button class="btn ${g?'on':''}" id="mgraph">Graph</button></div><div class="frm"><input id="mq"`);
 return g?h.replace(/<div class="grid2">[\s\S]*$/,memGraph()+'</div>'):h};
document.addEventListener('click',e=>{if(e.target.id==='mgraph'){window._mg=true;renderPage()}if(e.target.id==='mcards'){window._mg=false;renderPage()}});
