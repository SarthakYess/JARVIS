/* ui.js: core state, websocket, helpers, icons, nav, toasts, modal, palette, sound, prefs. */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const IC={search:'<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/>',bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',max:'<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
 mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M19 10v1a7 7 0 0 1-14 0v-1M12 18v4M8 22h8"/>',play:'<polygon points="6 3 20 12 6 21 6 3"/>',globe:'<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
 camera:'<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',act:'<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',plus:'<path d="M12 5v14M5 12h14"/>',flow:'<circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M6 9v3a3 3 0 0 0 3 3h6"/>',send:'<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>',
 dash:'<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>',cpu:'<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/>',
 box:'<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',task:'<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
 db:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',chat:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',book:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
 route:'<path d="M5 3v12a4 4 0 0 0 4 4h6"/><circle cx="5" cy="3" r="2"/><circle cx="18" cy="19" r="3"/><path d="M13 7h6M16 4l3 3-3 3"/>',set:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
 grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',x:'<path d="M18 6L6 18M6 6l12 12"/>',type:'<polyline points="4 7 4 4 20 4 20 7"/><path d="M9 20h6M12 4v16"/>',
 vol:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',power:'<path d="M18.4 6.6a9 9 0 1 1-12.8 0M12 2v10"/>',
 link:'<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>'};
const ico=n=>`<svg class="i" viewBox="0 0 24 24">${IC[n]||''}</svg>`,hydrate=(r=document)=>r.querySelectorAll('[data-i]').forEach(e=>{e.innerHTML=ico(e.dataset.i);e.removeAttribute('data-i')});
Object.assign(IC,{
 chev:'<path d="M6 9l6 6 6-6"/>',copy:'<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
 pin:'<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',mark:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
 retry:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',min:'<path d="M5 12h14"/>',sq:'<rect x="5" y="5" width="14" height="14" rx="1"/>',
 check:'<path d="M20 6L9 17l-5-5"/>',warn:'<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
 down:'<path d="M12 5v14M19 12l-7 7-7-7"/>',up:'<path d="M12 19V5M5 12l7-7 7 7"/>',bolt:'<path d="M13 2L3 14h9l-1 8 10-12h-9z"/>',
 pen:'<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',trash:'<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',folder:'<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'});
const TOOLICON={open_app:'grid',close_app:'x',type_text:'type',web_search:'search',system_info:'act',volume:'vol',screenshot:'camera',file_ops:'file',time_date:'clock',power:'power',browser:'globe'};
const CATS=[['Apps',['open_app','close_app','type_text']],['Web',['browser','web_search']],['System',['system_info','power','volume','time_date']],['Files',['file_ops']],['Media',['screenshot']]];
const BUS={},on=(t,f)=>(BUS[t]=BUS[t]||[]).push(f),emit=(t,d)=>(BUS[t]||[]).forEach(f=>{try{f(d)}catch(e){console.error(t,e)}});
const S={status:'Idle',mic:'wake',mode:'wake',oneshot:false,tools:[],feed:[],keys:0,keyhealth:[],mics:[],fast:'',strong:'',ver:'v4.0.0',
 st:{cpu:0,ram:0,disk:0,down:0,up:0,uptime:0,batt:null,plugged:false,procs:[],cores:[]},store:null,online:false,everOnline:false,meta:{stt:'-'},ts:{},page:'dash',wake:'jarvis',notes:[],tlr:'today',level:0,dataDir:''};
const EMPTY={tasks:[],events:[],memory:[],notes:[],workflows:[],routines:[],agents:{},ui:{}};
const ST=()=>S.store||EMPTY,today=()=>new Date().toLocaleDateString('en-CA'),val=id=>(document.getElementById(id)||{}).value||'';
let ws;const send=o=>{if(ws&&ws.readyState===1)ws.send(JSON.stringify(o))};
const cmd=t=>{send({type:'command',text:t})};

/* ---------- prefs (persisted in the backend store, mirrored in localStorage for first paint) ---------- */
const UI=()=>({...JSON.parse(localStorage.getItem('jv_ui')||'{}'),...(ST().ui||{})});
function setUi(k,v){const u={...JSON.parse(localStorage.getItem('jv_ui')||'{}'),[k]:v};localStorage.setItem('jv_ui',JSON.stringify(u));ST().ui=ST().ui||{};if(S.store)S.store.ui[k]=v;send({type:'store',op:'ui',item:{[k]:v}});applyUi()}
function applyUi(){const u=UI(),h=document.documentElement,b=document.body;
 h.dataset.accent=u.accent||'cyan';h.dataset.contrast=u.contrast?'high':'';h.style.setProperty('--ui-scale',(u.scale||100)/100);
 b.dataset.layout=u.layout||'command';$$('#lay button').forEach(x=>x.classList.toggle('on',x.dataset.lay===b.dataset.layout));
 b.classList.toggle('rail-c',u.rail==='compact'||(u.rail!=='full'&&innerWidth<1400));
 b.classList.toggle('perf',!!u.perf);(u.collapsed||[]).forEach(id=>document.getElementById(id)?.classList.add('collapsed'));
 const rgb=getComputedStyle(h).getPropertyValue('--accent-rgb').trim().split(',').map(Number);window.ACCENT=rgb.map(x=>x/255);emit('ui',u)}
addEventListener('resize',()=>{clearTimeout(window._rz);window._rz=setTimeout(applyUi,150)});

/* ---------- sound (all cues off-able, volume in prefs) ---------- */
let AC;const tone=(f,d=.07,v=1,t='sine',at=0)=>{const u=UI(),vol=(u.vol==null?35:u.vol)/100;if(!vol||u.sound===false)return;try{AC=AC||new AudioContext();const o=AC.createOscillator(),g=AC.createGain(),t0=AC.currentTime+at;o.type=t;o.frequency.value=f;g.gain.setValueAtTime(.0001,t0);g.gain.exponentialRampToValueAtTime(.06*vol*v,t0+.01);g.gain.exponentialRampToValueAtTime(.0001,t0+d);o.connect(g);g.connect(AC.destination);o.start(t0);o.stop(t0+d+.02)}catch(e){}};
const CUE={wake:()=>{tone(520,.08);tone(780,.1,1,'sine',.07)},understood:()=>tone(660,.06,.7),ok:()=>{tone(740,.07);tone(990,.1,.8,'sine',.06)},err:()=>{tone(300,.14,1,'triangle');tone(220,.18,1,'triangle',.1)},nav:()=>tone(480,.04,.4)};
const snd=k=>CUE[k]&&CUE[k]();

/* ---------- toasts (stacked, optional Undo) ---------- */
function toast(m,o={}){const t=document.createElement('div');t.className='toast'+(o.err?' err':'');t.setAttribute('role','status');t.innerHTML=`<span>${esc(m)}</span>`;
 if(o.undo){const b=document.createElement('button');b.className='btn sm';b.textContent='Undo';b.onclick=()=>{o.undo();t.remove()};t.appendChild(b)}
 $('#toasts').appendChild(t);while($('#toasts').children.length>4)$('#toasts').firstChild.remove();setTimeout(()=>t.remove(),o.ms||(o.undo?6000:3500))}

/* ---------- modal ---------- */
let lastFocus;function modal(h,wide){lastFocus=document.activeElement;$('#mbody').innerHTML=h+'<div style="margin-top:12px;text-align:right"><button class="btn" id="mx">Close</button></div>';hydrate($('#mbody'));$('#mdl').classList.add('show');$('#mx').onclick=closeM;const f=$('#mbody input,#mbody textarea,#mbody select');(f||$('#mx')).focus()}
const closeM=()=>{$('#mdl').classList.remove('show');lastFocus&&lastFocus.focus&&lastFocus.focus()};

/* ---------- store ---------- */
function applyLocal(o){const d=S.store=ST()===EMPTY?{...EMPTY}:S.store;if(o.op==='ui'){d.ui={...(d.ui||{}),...o.item};return}
 if(o.op==='agent')d.agents[o.coll]=o.on;else if(d[o.coll]){if(o.op==='add')d[o.coll].push({...o.item,id:'tmp'+Date.now(),ts:Date.now()/1e3});else if(o.op==='update')d[o.coll]=d[o.coll].map(x=>x.id===o.id?{...x,...o.item}:x);else if(o.op==='delete')d[o.coll]=d[o.coll].filter(x=>x.id!==o.id)}storeChanged()}
const put=o=>{applyLocal(o);send({type:'store',...o})};

/* ---------- navigation (grouped) ---------- */
const NAVG=[['Operate',[['dash','dash','Command Center'],['convo','chat','Conversations']]],['Automate',[['routines','route','Voice Routines'],['wf','flow','Workflows'],['modules','box','Modules']]],
 ['Data',[['tasks','task','Tasks'],['cal','cal','Calendar'],['mem','db','Memory'],['kb','book','Knowledge']]],['System',[['core','cpu','AI Core'],['settings','set','Settings']]]];
const NAV=NAVG.flatMap(g=>g[1]);
function nav(){const pend=ST().tasks.filter(t=>t.done!=='true').length;let n=0;
 $('#nav').innerHTML=NAVG.map(([g,items])=>`<div class="ng" role="presentation">${g}</div>`+items.map(([k,i,l])=>{n++;return`<button data-go="${k}" class="${S.page===k?'on':''}" ${S.page===k?'aria-current="page"':''} aria-label="${l}" data-tip="${l}">${ico(i)}<span class="t">${l}</span>${k==='tasks'&&pend?`<span class="badge">${pend}</span>`:''}${n<=9?`<kbd>^${n}</kbd>`:''}</button>`}).join('')).join('')}
function go(k){S.page=k;snd('nav');$('#dash').style.display=k==='dash'?'grid':'none';const pg=$('#page');pg.style.display=k==='dash'?'none':'block';
 $('#crumb').textContent=(NAV.find(x=>x[0]===k)||[0,0,'Command Center'])[2];nav();if(k!=='dash'&&window.renderPage){pg.style.animation='none';pg.offsetHeight;pg.style.animation='';renderPage()}else emit('dashshow');closeM();$('#notif').classList.remove('show')}

/* ---------- persistent, actionable banners ---------- */
function banners(){const b=[],k=S.keyhealth||[];
 if(!S.online)b.push(['err','warn',S.everOnline?'Connection to JARVIS lost.':'Connecting to the JARVIS backend...','JARVIS cannot hear or run commands until the link is back.',[['Retry','retry']]]);
 else{if(!S.keys)b.push(['warn','key','No Groq API key found.','AI answers and Whisper speech recognition are off; local commands still work.',[['Open .env folder','folder']]]);
  else if(k.length&&k.every(x=>x.state==='rejected'))b.push(['err','key','Every API key was rejected.','Check the keys in your .env file.',[['Open .env folder','folder']]]);
  else if(k.length&&k.every(x=>x.state!=='ok'))b.push(['warn','key','All API keys are rate limited.','JARVIS will recover automatically; the longest wait is about '+Math.max(...k.map(x=>x.wait||0))+' s.',[]]);
  if(S.mic==='error')b.push(['err','mic','Microphone problem.','JARVIS cannot hear you. Check that a microphone is connected and allowed.',[['Choose microphone','mic']]])}
 $('#banners').innerHTML=b.map(([c,,t,d,a])=>`<div class="bn ${c}">${ico(c==='err'?'warn':'warn')}<span><b>${t}</b> ${d}</span><span class="sp"></span>${a.map(([l,i])=>`<button class="btn sm" data-ban="${i}">${l}</button>`).join('')}</div>`).join('');hydrate($('#banners'))}
document.addEventListener('click',e=>{const b=e.target.closest('[data-ban]');if(!b)return;({retry:()=>{try{ws.close()}catch(x){}connect()},folder:()=>send({type:'open_folder'}),mic:()=>go('settings')})[b.dataset.ban]?.()});

/* ---------- websocket ---------- */
function connect(){ws=new WebSocket(`ws://${location.host}/ws`);ws.onopen=()=>{S.online=true;S.everOnline=true;banners();emit('state')};
 ws.onmessage=m=>{const d=JSON.parse(m.data);
  if(d.type==='init'){Object.assign(S,{status:d.status,mic:d.mic,mode:d.mode,oneshot:!!d.oneshot,tools:d.tools,feed:d.feed,keys:d.keys,keyhealth:d.keyhealth||[],startup:!!d.startup,mics:d.mics||[],fast:d.fast,strong:d.strong,ver:d.version,wake:d.wake,meta:d.meta||S.meta,ts:d.toolstats||{},store:d.store,dataDir:d.data_dir});applyUi();nav();banners()}
  else if(d.type==='state'){Object.assign(S,{status:d.status,mic:d.mic,mode:d.mode,oneshot:!!d.oneshot});banners()}
  else if(d.type==='stats'){S.st=d;S.keyhealth=d.keys||S.keyhealth;if(S.page==='settings'&&window.keyTable)keyTable()}
  else if(d.type==='tools')S.ts=d.stats;
  else if(d.type==='store'){S.store=d.data;storeChanged()}
  else if(d.type==='level')S.level=d.v;
  else if(d.type==='export'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(d.data,null,1)],{type:'application/json'}));a.download='jarvis-data-'+today()+'.json';a.click()}
  window.onExtra&&onExtra(d);emit(d.type,d)};
 ws.onclose=()=>{S.online=false;banners();emit('state');setTimeout(connect,1500)}}
function storeChanged(){nav();emit('store');if(S.page!=='dash'&&window.renderPage)renderPage()}

/* ---------- boot: full sequence once per day, 1s quick boot otherwise, any key skips ---------- */
let booted=false;function bootDone(){if(booted)return;booted=true;document.body.classList.add('ready');emit('ready');snd('wake')}
function boot(){hydrate();const u=JSON.parse(localStorage.getItem('jv_ui')||'{}');Object.assign(S.store={...EMPTY},{ui:u});applyUi();nav();connect();
 const full=localStorage.getItem('jv_boot_day')!==today();addEventListener('keydown',bootDone,{once:true});
 const step=(a,b,ok)=>{$('#bl').insertAdjacentHTML('beforeend',`<div><span>${a}</span><span style="color:var(--${ok?'ok':'err'})">${b}</span></div>`)};
 const wait=setInterval(()=>{if(S.store&&S.store.tasks&&S.tools.length||performance.now()>4000){clearInterval(wait);
  if(!full){$('#bbar i').style.width='100%';setTimeout(bootDone,700);return}localStorage.setItem('jv_boot_day',today());
  const st=[['Backend link',S.online?'ONLINE':'OFFLINE',S.online],['Voice input',S.mic==='error'?'MIC ERROR':'READY',S.mic!=='error'],['Speech engine',String(S.meta.stt).toUpperCase(),true],['Language model',S.keys?S.keys+' KEYS':'NO API KEY',!!S.keys],['Modules',S.tools.length+' LOADED',true]];
  st.forEach((x,i)=>setTimeout(()=>{step(...x);$('#bbar i').style.width=(i+1)*20+'%';tone(500+i*140,.05)},i*220));setTimeout(bootDone,st.length*220+450)}},100)}

/* ---------- command palette + shortcuts ---------- */
let psel=0;function plist(){const q=val('pin').trim().toLowerCase(),it=[];if(q)it.push({t:`Run "${val('pin').trim()}"`,s:'command',f:()=>cmd(val('pin').trim())});
 NAV.forEach(([k,i,n])=>{if(!q||n.toLowerCase().includes(q))it.push({t:'Go to '+n,s:'page',f:()=>go(k)})});
 [['command','Layout: Command'],['focus','Layout: Focus'],['monitor','Layout: Monitor']].forEach(([l,n])=>{if(!q||n.toLowerCase().includes(q))it.push({t:n,s:'layout',f:()=>{setUi('layout',l);go('dash')}})});
 S.tools.forEach(t=>{if(!q||t.name.includes(q)||(t.description||'').toLowerCase().includes(q))it.push({t:t.name.replace(/_/g,' '),s:'module',f:()=>window.modModal&&modModal(t.name)})});
 ST().routines.forEach(r=>{if(!q||r.name.toLowerCase().includes(q))it.push({t:'Run routine: '+r.name,s:'routine',f:()=>cmd((r.phrases||[])[0]||'')})});
 window._pit=it.slice(0,12);psel=0;$('#plist').innerHTML=_pit.map((x,i)=>`<div class="pi ${i?'':'sel'}" role="option" data-pi="${i}">${esc(x.t)}<small>${x.s}</small></div>`).join('')}
const pal=o=>{$('#pal').classList.toggle('show',o);if(o){$('#pin').value='';plist();$('#pin').focus()}};
addEventListener('keydown',e=>{const inField=/INPUT|TEXTAREA|SELECT/.test((e.target||{}).tagName);
 if(e.ctrlKey&&e.key.toLowerCase()==='k'){e.preventDefault();pal(true)}
 else if(e.ctrlKey&&/^[1-9]$/.test(e.key)){e.preventDefault();go(NAV[+e.key-1][0])}
 else if(e.ctrlKey&&e.key.toLowerCase()==='b'){e.preventDefault();setUi('rail',document.body.classList.contains('rail-c')?'full':'compact')}
 else if(e.key==='Escape'){pal(false);closeM()}
 else if(e.key==='/'&&!inField&&S.page==='dash'){e.preventDefault();$('#txt').focus()}});
document.addEventListener('click',e=>{const t=e.target;if(!t.closest('#notif,#bell'))$('#notif').classList.remove('show');
 const b=t.closest('.btn');if(b&&!b.matches('.ghost')){const r=document.createElement('span'),q=b.getBoundingClientRect(),s=Math.max(q.width,q.height);r.className='rip';r.style.cssText=`width:${s}px;height:${s}px;left:${e.clientX-q.left-s/2}px;top:${e.clientY-q.top-s/2}px`;b.appendChild(r);setTimeout(()=>r.remove(),520)}
 let m;if(m=t.closest('[data-go]'))go(m.dataset.go);if(m=t.closest('[data-c]'))cmd(m.dataset.c);if(m=t.closest('[data-mod]'))window.modModal&&modModal(m.dataset.mod);if(m=t.closest('[data-wf]')){send({type:'run_workflow',id:m.dataset.wf});closeM()}
 if(m=t.closest('[data-lay]'))setUi('layout',m.dataset.lay);
 if(m=t.closest('[data-col]')){const p=m.closest('.pn');p.classList.toggle('collapsed');const c=[...document.querySelectorAll('.pn.collapsed')].map(x=>x.id).filter(Boolean);setUi('collapsed',c)}});
document.addEventListener('DOMContentLoaded',()=>{$('#mdl').onclick=e=>e.target.id==='mdl'&&closeM();$('#pin').oninput=plist;
 $('#pin').onkeydown=e=>{const L=$$('#plist .pi');if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();psel=(psel+(e.key==='ArrowDown'?1:-1)+L.length)%L.length;L.forEach((x,i)=>x.classList.toggle('sel',i===psel))}if(e.key==='Enter'&&_pit[psel]){_pit[psel].f();pal(false)}};
 $('#plist').onclick=e=>{const r=e.target.closest('[data-pi]');if(r){_pit[+r.dataset.pi].f();pal(false)}};$('#pal').onclick=e=>e.target.id==='pal'&&pal(false);$('#srch').onclick=()=>pal(true);
 $('#bell').onclick=e=>{e.stopPropagation();const n=$('#notif');n.innerHTML=`<div class="ph"><div class="pt">Alerts</div><span class="sp"></span><a id="nclr">Clear</a></div>`+(S.notes.map(window.feedItem).join('')||'<div class="empty">No alerts. Reminders and errors show up here.</div>');n.classList.toggle('show');$('#nclr')&&($('#nclr').onclick=()=>{S.notes=[];bell();n.classList.remove('show')})};
 const api=()=>window.pywebview&&pywebview.api;$('#wmin').onclick=()=>api()&&api().minimize();$('#wmax').onclick=()=>api()&&api().maximize();$('#wx').onclick=()=>api()?api().close():send({type:'close'});
 $('#wc').style.display='none';addEventListener('pywebviewready',()=>{$('#wc').style.display='flex'});});
function bell(){const n=S.notes.length,b=$('#bbd');b.style.display=n?'grid':'none';b.textContent=n}
