"""Small persistent store used by the Command Center pages (tasks, calendar, memory, notes, workflows).

Lives in <APP_DIR>/data/store.json. Does not touch the assistant backend.
"""
import json
import threading
import time
import uuid

import config

COLLECTIONS = ("tasks", "events", "memory", "notes", "workflows", "routines")
AGENTS = ("coding", "research", "memory", "browser", "task", "system")


class Store:
    def __init__(self) -> None:
        self.path = config.APP_DIR / "data" / "store.json"
        self._lock = threading.Lock()
        self.data = {c: [] for c in COLLECTIONS}
        self.data["agents"] = {a: True for a in AGENTS}
        self.data["ui"] = {}   # layout, accent, scale, flags (persisted)
        self._load()

    @staticmethod
    def default_routines() -> list:
        keep = "jarvis, python, program manager"
        mk = lambda i, n, p, st: {"id": i, "name": n, "phrases": p, "steps": st, "ts": time.time()}
        o = lambda v: {"type": "open", "v": v, "v2": ""}
        wait = lambda s: {"type": "wait", "v": str(s), "v2": ""}
        return [
            mk("rt_start", "Work start", ["start", "start work", "work mode"],
               [o("chrome"), wait(1.5), o("https://chatgpt.com"), o("https://claude.ai"),
                o("vs code"), o("terminal"), o("explorer")]),
            mk("rt_game", "Game mode", ["game", "game mode"],
               [{"type": "close_all", "v": keep, "v2": "ask"}, wait(2), o("TLauncher")]),
            mk("rt_gaming", "Gaming (auto-click)", ["gaming", "start gaming"],
               [o("TLauncher"), wait(15), {"type": "click_image", "v": "", "v2": "30"}]),
        ]

    def _load(self) -> None:
        try:
            saved = json.loads(self.path.read_text(encoding="utf-8"))
            for key in self.data:
                if key in saved:
                    self.data[key] = saved[key]
            if "routines" not in saved:
                self.data["routines"] = self.default_routines()
                self._save()
        except (OSError, ValueError):
            self.data["routines"] = self.default_routines()
            self.data["workflows"] = [
                {"id": "wf_morning", "name": "Morning briefing",
                 "commands": ["what time is it", "system status"], "ts": time.time()},
                {"id": "wf_focus", "name": "Focus setup",
                 "commands": ["volume down", "stay active"], "ts": time.time()},
            ]
            self._save()

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.data, indent=1), encoding="utf-8")

    def apply(self, msg: dict) -> None:
        """msg: {op: add|update|delete|agent, coll, id, item}"""
        op, coll = msg.get("op"), msg.get("coll")
        with self._lock:
            if op == "ui" and isinstance(msg.get("item"), dict):
                self.data["ui"].update({str(k)[:40]: v for k, v in msg["item"].items()
                                        if isinstance(v, (str, int, float, bool))})
            elif op == "agent" and coll:
                self.data["agents"][str(coll)] = bool(msg.get("on"))
            elif coll in COLLECTIONS:
                items = self.data[coll]
                if op == "add" and isinstance(msg.get("item"), dict):
                    item = {k: str(v)[:2000] if not isinstance(v, (list, bool)) else v
                            for k, v in msg["item"].items()}
                    item.update(id=uuid.uuid4().hex[:8], ts=time.time())
                    items.append(item)
                elif op == "update":
                    for it in items:
                        if it.get("id") == msg.get("id") and isinstance(msg.get("item"), dict):
                            it.update(msg["item"])
                elif op == "delete":
                    self.data[coll] = [i for i in items if i.get("id") != msg.get("id")]
            self._save()

    def find_workflow(self, wf_id: str):
        return next((w for w in self.data["workflows"] if w.get("id") == wf_id), None)

    def due_events(self, now: time.struct_time, fired: set) -> list:
        """Events whose date+time equals the current minute and were not announced yet."""
        stamp = time.strftime("%Y-%m-%d %H:%M", now)
        out = []
        for e in self.data["events"]:
            key = (e.get("id"), stamp)
            if f"{e.get('date', '')} {e.get('time', '')}" == stamp and key not in fired:
                fired.add(key)
                out.append(e)
        return out
