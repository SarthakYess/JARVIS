"""JARVIS holographic HUD.

Plain Tk + Pillow (no customtkinter needed). Everything is drawn in pixels and scaled
with the Windows display scale, so it stays sharp on 125% / 150% screens.

Public API used by main.py (unchanged):
    set_status(status)  set_mic(state)  set_mode(mode)  append_log(text, tag)
    set_submit_callback(fn)  protocol(...)  mainloop()  destroy()

All of those can be called from the voice thread: they only put an event on a queue,
and the Tk thread applies it a few milliseconds later.
"""
from __future__ import annotations

import math
import os
import queue
import random
import sys
import time
import tkinter as tk
from tkinter import font as tkfont
from typing import Callable, Optional

from PIL import Image, ImageDraw, ImageOps, ImageTk

try:
    import psutil
except ImportError:  # the HUD still works, the gauges just stay empty
    psutil = None

try:
    import config

    ASSISTANT = str(getattr(config, "ASSISTANT_NAME", "JARVIS")).strip() or "JARVIS"
    USER_TITLE = (str(getattr(config, "USER_TITLE", "sir")).strip() or "sir").title()
except Exception:  # pragma: no cover - running the GUI on its own
    ASSISTANT, USER_TITLE = "JARVIS", "Sir"

# --------------------------------------------------------------------------- palette
BG = "#030a16"          # window
PANEL = "#061528"       # panel fill
PANEL_HI = "#0a2340"    # hover / raised
TRACK = "#0a2a45"       # gauge + meter tracks
EDGE = "#0e5a8c"        # panel outline
EDGE_DIM = "#0a3556"
ACCENT = "#1ec8ff"
ACCENT_HI = "#8fe9ff"
TEXT = "#d9f4ff"
SOFT = "#7fd0ee"
MUTED = "#6f9fbd"
DIM = "#3b6a89"
DANGER = "#ff5d6c"
WARN = "#ffb454"

# status -> (orb colour, spin speed, label inside the orb, waveform style)
STATES = {
    "Idle": ("#1ec8ff", 1.0, "SYSTEMS ONLINE", "idle"),
    "Listening": ("#35e0ff", 1.9, "LISTENING", "listen"),
    "Thinking": ("#7f9bff", 3.6, "THINKING", "think"),
    "Processing": ("#7f9bff", 3.6, "PROCESSING", "think"),
    "Speaking": ("#3dffc8", 2.5, "SPEAKING", "speak"),
}

LOG_TAGS = {
    "user": dict(foreground="#ffffff"),
    "jarvis": dict(foreground=ACCENT),
    "info": dict(foreground=MUTED),
    "output": dict(foreground="#b8d9ea"),
    "error": dict(foreground=DANGER),
    "warning": dict(foreground=WARN),
    "success": dict(foreground="#3dffc8"),
}

# --------------------------------------------------------------------------- scaling + fonts
_SCALE = 1.0
_FONTS = {"display": "Segoe UI", "body": "Segoe UI", "mono": "Consolas"}


def px(v: float) -> int:
    """Scale a design pixel (authored at 96 dpi) to this screen."""
    return max(1, int(round(v * _SCALE)))


def font(role: str, size: float, bold: bool = False, italic: bool = False):
    style = " ".join(s for s, on in (("bold", bold), ("italic", italic)) if on) or "normal"
    return (_FONTS[role], -px(size), style)


def _init_fonts() -> None:
    have = {f.lower(): f for f in tkfont.families()}

    def pick(options, default):
        for name in options:
            if name.lower() in have:
                return have[name.lower()]
        return default

    _FONTS["display"] = pick(["Orbitron", "Rajdhani", "Bahnschrift SemiBold", "Bahnschrift",
                              "Segoe UI Semibold", "Segoe UI", "DejaVu Sans"], "TkDefaultFont")
    _FONTS["body"] = pick(["Rajdhani", "Bahnschrift", "Segoe UI", "Helvetica", "DejaVu Sans"], "TkDefaultFont")
    _FONTS["mono"] = pick(["Cascadia Mono", "Consolas", "Menlo", "DejaVu Sans Mono", "Courier New"],
                          "TkFixedFont")


def _enable_dpi_awareness() -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes

        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


# --------------------------------------------------------------------------- small helpers
def _rgb(c: str):
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def mix(a: str, b: str, t: float) -> str:
    t = max(0.0, min(1.0, t))
    ra, rb = _rgb(a), _rgb(b)
    return "#%02x%02x%02x" % tuple(int(round(x + (y - x) * t)) for x, y in zip(ra, rb))


def round_rect(cv: tk.Canvas, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2,
           x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return cv.create_polygon(pts, smooth=True, **kw)


def draw_icon(cv: tk.Canvas, name: str, cx: float, cy: float, s: float, color: str,
              width: Optional[int] = None, tag: str = "icon") -> None:
    """Tiny line icons, drawn with canvas primitives. s is the half-size in pixels."""
    w = width or max(1, round(1.5 * _SCALE))

    def P(*p):
        return [v for x, y in zip(p[0::2], p[1::2]) for v in (cx + x * s, cy + y * s)]

    def line(*p):
        cv.create_line(*P(*p), fill=color, width=w, capstyle="round", joinstyle="round", tags=tag)

    def oval(*p):
        cv.create_oval(*P(*p), outline=color, width=w, tags=tag)

    def rect(*p):
        cv.create_rectangle(*P(*p), outline=color, width=w, tags=tag)

    def poly(*p):
        cv.create_polygon(*P(*p), outline=color, fill="", width=w, joinstyle="round", tags=tag)

    def arc(x1, y1, x2, y2, start, extent):
        cv.create_arc(*P(x1, y1, x2, y2), start=start, extent=extent, style="arc",
                      outline=color, width=w, tags=tag)

    if name == "home":
        line(-1, 0, 0, -1, 1, 0)
        line(-0.7, -0.2, -0.7, 0.9, 0.7, 0.9, 0.7, -0.2)
        line(-0.2, 0.9, -0.2, 0.35, 0.2, 0.35, 0.2, 0.9)
    elif name == "folder":
        line(-1, -0.6, -0.3, -0.6, 0, -0.3, 1, -0.3, 1, 0.8, -1, 0.8, -1, -0.6)
    elif name == "globe":
        oval(-1, -1, 1, 1)
        oval(-0.45, -1, 0.45, 1)
        line(-1, 0, 1, 0)
    elif name == "grid":
        rect(-1, -1, -0.12, -0.12)
        rect(0.12, -1, 1, -0.12)
        rect(-1, 0.12, -0.12, 1)
        rect(0.12, 0.12, 1, 1)
    elif name == "search":
        oval(-1, -1, 0.35, 0.35)
        line(0.3, 0.3, 1, 1)
    elif name == "clock":
        oval(-1, -1, 1, 1)
        line(0, 0, 0, -0.6)
        line(0, 0, 0.45, 0.2)
    elif name == "chat":
        poly(-1, -0.8, 1, -0.8, 1, 0.4, -0.1, 0.4, -0.6, 0.95, -0.6, 0.4, -1, 0.4)
    elif name == "camera":
        rect(-1, -0.5, 1, 0.75)
        line(-0.4, -0.5, -0.25, -0.85, 0.25, -0.85, 0.4, -0.5)
        oval(-0.4, -0.3, 0.4, 0.5)
    elif name == "note":
        poly(-0.7, -1, 0.35, -1, 0.8, -0.5, 0.8, 1, -0.7, 1)
        line(-0.4, 0, 0.5, 0)
        line(-0.4, 0.45, 0.5, 0.45)
    elif name == "sleep":
        line(-0.7, -0.7, 0.7, -0.7, -0.7, 0.7, 0.7, 0.7)
    elif name == "bolt":
        poly(0.2, -1, -0.6, 0.2, 0, 0.2, -0.2, 1, 0.6, -0.2, 0, -0.2)
    elif name == "send":
        poly(-1, -0.8, 1, 0, -1, 0.8, -0.5, 0)
    elif name == "trash":
        rect(-0.7, -0.5, 0.7, 1)
        line(-1, -0.6, 1, -0.6)
        line(-0.3, -0.6, -0.3, -1, 0.3, -1, 0.3, -0.6)
    elif name == "mic":
        arc(-0.35, -1, 0.35, -0.3, 0, 180)
        arc(-0.35, -0.15, 0.35, 0.55, 180, 180)
        line(-0.35, -0.65, -0.35, 0.2)
        line(0.35, -0.65, 0.35, 0.2)
        arc(-0.7, -0.55, 0.7, 0.75, 180, 180)
        line(0, 0.75, 0, 1)
        line(-0.4, 1, 0.4, 1)


# --------------------------------------------------------------------------- widgets
class TechPanel(tk.Canvas):
    """A chamfered HUD panel. Put your widgets in `.body`."""

    def __init__(self, master, title: str = "", width: int = 300, height: int = 200, pad: int = 14):
        super().__init__(master, width=px(width), height=px(height), bg=BG, highlightthickness=0, bd=0)
        self._title = title
        self._c = px(16)
        self._pad = px(pad)
        self._top = px(46) if title else px(pad)
        self.body = tk.Frame(self, bg=PANEL)
        self._win = self.create_window(self._pad, self._top, window=self.body, anchor="nw")
        self.bind("<Configure>", self._redraw)

    def _redraw(self, _event=None):
        w, h = self.winfo_width(), self.winfo_height()
        if w < 30 or h < 30:
            return
        c, lw = self._c, px(2)
        self.delete("deco")
        self.create_polygon(c, 1, w - 1, 1, w - 1, h - c, w - c, h - 1, 1, h - 1, 1, c,
                            fill=PANEL, outline=EDGE, width=1, tags="deco")
        self.create_line(w - px(150), 1, w - px(64), 1, fill=ACCENT, width=lw, tags="deco")
        self.create_line(1, c + px(20), 1, c, c, 1, c + px(20), 1, fill=ACCENT, width=lw, tags="deco")
        self.create_line(w - 1, h - c - px(20), w - 1, h - c, w - c, h - 1, w - c - px(20), h - 1,
                         fill=ACCENT, width=lw, tags="deco")
        if self._title:
            self.create_text(self._pad + px(4), px(24), text=self._title, anchor="w", fill=ACCENT_HI,
                             font=font("body", 14, bold=True), tags="deco")
        self.tag_lower("deco")
        self.itemconfigure(self._win, width=max(1, w - 2 * self._pad),
                           height=max(1, h - self._top - self._pad))


class PillButton(tk.Canvas):
    """Rounded button with an optional line icon."""

    def __init__(self, master, text: str, command: Callable[[], None], icon: str = "", height: int = 42,
                 width: int = 150, bg: str = PANEL):
        super().__init__(master, width=px(width), height=px(height), bg=bg, highlightthickness=0, bd=0,
                         cursor="hand2")
        self._text, self._icon, self._cmd = text, icon, command
        self._hover = False
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<ButtonRelease-1>", self._click)

    def _set_hover(self, on: bool) -> None:
        self._hover = on
        self._draw()

    def _click(self, event) -> None:
        if 0 <= event.x <= self.winfo_width() and 0 <= event.y <= self.winfo_height():
            self._cmd()

    def _draw(self) -> None:
        w, h = self.winfo_width(), self.winfo_height()
        if w < 10:
            return
        self.delete("all")
        hot = self._hover
        round_rect(self, 1, 1, w - 1, h - 1, h / 2, fill=PANEL_HI if hot else "#071a30",
                   outline=ACCENT if hot else EDGE, width=1)
        x = px(18)
        if self._icon:
            draw_icon(self, self._icon, x + px(8), h / 2, px(8), ACCENT_HI if hot else ACCENT)
            x += px(28)
        self.create_text(x, h / 2, text=self._text, anchor="w", fill=TEXT, font=font("body", 14))


class NavButton(tk.Canvas):
    """Sidebar entry."""

    def __init__(self, master, text: str, icon: str, command: Callable[[], None], active: bool = False):
        super().__init__(master, width=px(116), height=px(46), bg=BG, highlightthickness=0, bd=0,
                         cursor="hand2")
        self._text, self._icon, self._cmd = text, icon, command
        self.active, self._hover = active, False
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._hov(True))
        self.bind("<Leave>", lambda e: self._hov(False))
        self.bind("<ButtonRelease-1>", lambda e: self._cmd())

    def _hov(self, on: bool) -> None:
        self._hover = on
        self._draw()

    def flash(self) -> None:
        """Light up briefly (for entries that run an action instead of switching page)."""
        self.active = True
        self._draw()
        self.after(650, self._unflash)

    def _unflash(self) -> None:
        self.active = False
        self._draw()

    def _draw(self) -> None:
        w, h = self.winfo_width(), self.winfo_height()
        if w < 10:
            return
        self.delete("all")
        on = self.active
        if on or self._hover:
            self.create_rectangle(0, 2, w, h - 2, fill="#0a2d50" if on else PANEL, outline=EDGE if on else "",
                                  width=1)
        if on:
            self.create_rectangle(0, 2, px(3), h - 2, fill=ACCENT, width=0)
        col = ACCENT_HI if (on or self._hover) else ACCENT
        draw_icon(self, self._icon, px(26), h / 2, px(9), col)
        self.create_text(px(48), h / 2, text=self._text, anchor="w", fill=TEXT if (on or self._hover) else SOFT,
                         font=font("body", 15))


class CapRow(tk.Canvas):
    """One line of the 'what can I do' list: round icon + label + hairline."""

    def __init__(self, master, text: str, icon: str, command: Callable[[], None]):
        super().__init__(master, height=px(48), bg=PANEL, highlightthickness=0, bd=0, cursor="hand2")
        self._text, self._icon, self._cmd, self._hover = text, icon, command, False
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._hov(True))
        self.bind("<Leave>", lambda e: self._hov(False))
        self.bind("<ButtonRelease-1>", lambda e: self._cmd())

    def _hov(self, on: bool) -> None:
        self._hover = on
        self._draw()

    def _draw(self) -> None:
        w, h = self.winfo_width(), self.winfo_height()
        if w < 10:
            return
        self.delete("all")
        r = px(17)
        self.create_oval(px(2), h / 2 - r, px(2) + 2 * r, h / 2 + r,
                         outline=ACCENT if self._hover else EDGE, fill=PANEL_HI if self._hover else "#071a30")
        draw_icon(self, self._icon, px(2) + r, h / 2, px(8), ACCENT_HI if self._hover else ACCENT)
        self.create_text(px(52), h / 2, text=self._text, anchor="w", fill=TEXT if self._hover else SOFT,
                         font=font("body", 14))
        self.create_line(px(52), h - 1, w, h - 1, fill=EDGE_DIM)


class Gauge(tk.Canvas):
    """Round percentage dial with eased movement."""

    def __init__(self, master, label: str, size: int = 104):
        s = px(size)
        super().__init__(master, width=s, height=s, bg=PANEL, highlightthickness=0, bd=0)
        m = px(8)
        self._value = self._target = 0.0
        self._shown = -1.0
        self.create_oval(m, m, s - m, s - m, outline=TRACK, width=px(6))
        self._arc = self.create_arc(m, m, s - m, s - m, start=90, extent=0, style="arc", outline=ACCENT,
                                    width=px(6))
        self._txt = self.create_text(s / 2, s / 2 - px(5), text="--", fill=TEXT, font=font("display", 19, True))
        self.create_text(s / 2, s / 2 + px(17), text=label, fill=MUTED, font=font("body", 11))

    def set(self, value: float) -> None:
        self._target = max(0.0, min(100.0, float(value)))

    def step(self) -> None:
        self._value += (self._target - self._value) * 0.22
        if abs(self._value - self._shown) < 0.05:
            return
        self._shown = self._value
        self.itemconfigure(self._arc, extent=-min(359.9, self._value * 3.6))
        self.itemconfigure(self._txt, text=f"{round(self._value)}%")


class Meter(tk.Frame):
    """Label + value on one line with a thin bar under it."""

    def __init__(self, master, label: str):
        super().__init__(master, bg=PANEL)
        top = tk.Frame(self, bg=PANEL)
        top.pack(fill="x")
        tk.Label(top, text=label, bg=PANEL, fg=TEXT, font=font("body", 13)).pack(side="left")
        self.value = tk.Label(top, text="--", bg=PANEL, fg=MUTED, font=font("body", 12))
        self.value.pack(side="right")
        self.bar = tk.Canvas(self, height=px(5), bg=PANEL, highlightthickness=0, bd=0)
        self.bar.pack(fill="x", pady=(px(5), 0))
        self._frac = 0.0
        self.bar.bind("<Configure>", lambda e: self._draw())

    def set(self, frac: float, text: str) -> None:
        self._frac = max(0.0, min(1.0, frac))
        self.value.configure(text=text)
        self._draw()

    def _draw(self) -> None:
        w, h = self.bar.winfo_width(), self.bar.winfo_height()
        self.bar.delete("all")
        self.bar.create_rectangle(0, 0, w, h, fill=TRACK, width=0)
        self.bar.create_rectangle(0, 0, w * self._frac, h, fill=ACCENT, width=0)


class SlimScroll(tk.Canvas):
    """Thin scrollbar that matches the HUD."""

    def __init__(self, master, command: Callable):
        super().__init__(master, width=px(8), bg=PANEL, highlightthickness=0, bd=0)
        self._cmd, self._first, self._last, self._grab = command, 0.0, 1.0, 0.0
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<ButtonPress-1>", self._press)
        self.bind("<B1-Motion>", self._drag)

    def set(self, first, last) -> None:
        self._first, self._last = float(first), float(last)
        self._draw()

    def _draw(self) -> None:
        h, w = self.winfo_height(), self.winfo_width()
        self.delete("all")
        if self._last - self._first >= 0.999:
            return
        self.create_line(w / 2, 0, w / 2, h, fill=TRACK, width=1)
        round_rect(self, 1, self._first * h, w - 1, max(self._last * h, self._first * h + px(18)), px(3),
                   fill=EDGE, outline="")

    def _press(self, e) -> None:
        h = max(1, self.winfo_height())
        mid = (self._first + self._last) / 2
        self._grab = e.y / h - mid
        if not (self._first <= e.y / h <= self._last):
            self._cmd("moveto", max(0.0, e.y / h - (self._last - self._first) / 2))
            self._grab = 0.0

    def _drag(self, e) -> None:
        h = max(1, self.winfo_height())
        span = self._last - self._first
        self._cmd("moveto", max(0.0, min(1.0 - span, e.y / h - self._grab - span / 2)))


class CommandInput(tk.Frame):
    """Text command box with a placeholder and a send button."""

    PLACEHOLDER = "Type a command and press Enter"

    def __init__(self, master, on_submit: Callable[[str], None]):
        super().__init__(master, bg=BG)
        self._on_submit, self._ph = on_submit, False
        self.entry = tk.Entry(self, bg="#071a30", fg=TEXT, insertbackground=ACCENT, relief="flat", bd=0,
                              highlightthickness=px(1), highlightbackground=EDGE, highlightcolor=ACCENT,
                              font=font("body", 15), selectbackground=EDGE, selectforeground=TEXT)
        self.entry.pack(side="left", fill="both", expand=True, ipady=px(9), padx=(0, px(10)))
        self.entry.bind("<Return>", lambda e: self.submit())
        self.entry.bind("<FocusIn>", lambda e: self._focus_in())
        self.entry.bind("<FocusOut>", lambda e: self._show_placeholder())
        PillButton(self, "Send", self.submit, icon="send", width=104, height=44, bg=BG).pack(side="right")
        self._show_placeholder()

    def _show_placeholder(self) -> None:
        if not self.entry.get():
            self._ph = True
            self.entry.insert(0, self.PLACEHOLDER)
            self.entry.configure(fg=DIM)

    def _focus_in(self) -> None:
        if self._ph:
            self.entry.delete(0, "end")
            self.entry.configure(fg=TEXT)
            self._ph = False

    def text(self) -> str:
        return "" if self._ph else self.entry.get().strip()

    def set_text(self, text: str) -> None:
        self._focus_in()
        self.entry.delete(0, "end")
        self.entry.insert(0, text)
        self.entry.focus_set()
        self.entry.icursor("end")

    def submit(self) -> None:
        text = self.text()
        if text:
            self._on_submit(text)
            self.entry.delete(0, "end")


# --------------------------------------------------------------------------- header
class HeaderBar(tk.Canvas):
    def __init__(self, master):
        super().__init__(master, height=px(86), bg=BG, highlightthickness=0, bd=0)
        self._status, self._status_color, self._mode = "IDLE", ACCENT, "Wake word"
        self._ring = None
        self.bind("<Configure>", lambda e: self._build())

    def _build(self) -> None:
        w, h = self.winfo_width(), self.winfo_height()
        if w < 200:
            return
        self.delete("all")
        cy = h / 2 - px(4)
        # logo: dashed outer ring, solid mid ring, core
        lx = px(44)
        self._ring = self.create_oval(lx - px(31), cy - px(31), lx + px(31), cy + px(31), outline=ACCENT,
                                      width=px(3), dash=(px(5), px(4)))
        self.create_oval(lx - px(21), cy - px(21), lx + px(21), cy + px(21), outline=EDGE, width=px(2))
        self.create_oval(lx - px(11), cy - px(11), lx + px(11), cy + px(11), outline=ACCENT_HI, width=px(2))
        self.create_text(px(100), cy - px(11), text=" ".join(ASSISTANT.upper()), anchor="w", fill=ACCENT,
                         font=font("display", 30, True))
        self.create_text(px(102), cy + px(24), text="JUST A RATHER VERY INTELLIGENT SYSTEM", anchor="w",
                         fill=SOFT, font=font("body", 12))
        # baseline
        self.create_line(px(8), h - 2, w * 0.38, h - 2, fill=EDGE)
        self.create_line(px(8), h - 2, px(130), h - 2, fill=ACCENT, width=px(2))
        # right side: date + clock, divider, status
        sx = w - px(26)
        self.create_line(sx - px(226), cy - px(26), sx - px(226), cy + px(30), fill=EDGE_DIM)
        self._dot = self.create_oval(sx - px(210), cy - px(15), sx - px(198), cy - px(3), fill=self._status_color,
                                     outline="")
        self._st = self.create_text(sx - px(186), cy - px(9), text=self._status, anchor="w", fill=TEXT,
                                    font=font("display", 16, True))
        self._md = self.create_text(sx - px(208), cy + px(18), text=self._mode, anchor="w", fill=MUTED,
                                    font=font("body", 13))
        self._date = self.create_text(sx - px(250), cy - px(17), anchor="e", fill=SOFT, font=font("body", 14))
        self._clock = self.create_text(sx - px(250), cy + px(12), anchor="e", fill=TEXT,
                                       font=font("display", 28, True))
        self.update_clock()

    def update_clock(self) -> None:
        if not hasattr(self, "_clock"):
            return
        now = time.localtime()
        clock = time.strftime("%I:%M %p", now).lstrip("0")
        self.itemconfigure(self._clock, text=clock)
        self.itemconfigure(self._date, text=time.strftime("%a, %b %d, %Y", now).upper())

    def set_state(self, status: str, color: str, mode: str) -> None:
        self._status, self._status_color, self._mode = status, color, mode
        if hasattr(self, "_st"):
            self.itemconfigure(self._st, text=status)
            self.itemconfigure(self._dot, fill=color)
            self.itemconfigure(self._md, text=mode)

    def animate(self, t: float) -> None:
        if self._ring is not None:
            self.itemconfigure(self._ring, dashoffset=int(t * px(9)) % (px(9)))
            self.itemconfigure(self._dot, fill=mix(BG, self._status_color,
                                                   0.55 + 0.45 * (0.5 + 0.5 * math.sin(t * 3))))


# --------------------------------------------------------------------------- the orb
class OrbCanvas(tk.Canvas):
    """Glowing hologram sphere on a projector base. The sphere is a pre-rendered Pillow image; the rings
    that spin around it are canvas arcs, so the animation costs almost nothing."""

    def __init__(self, master):
        super().__init__(master, width=px(360), height=px(360), bg=BG, highlightthickness=0, bd=0)
        self._accent = self._target = ACCENT
        self._label = "SYSTEMS ONLINE"
        self._spd = self._spd_target = 1.0
        self._phase = 0.0
        self._dirty = False
        self._cache: dict = {}
        self._R = 0.0
        self._built = False
        self._job = None
        self._tint: list = []
        self._arcs: list = []
        self._dashes: list = []
        self.bind("<Configure>", self._schedule)

    # -- state
    def set_state(self, accent: str, speed: float, label: str) -> None:
        self._target, self._spd_target, self._label = accent, speed, label
        self._dirty = True
        if self._built:
            self.itemconfigure(self._glow_id, image=self._glow(accent))
            self.itemconfigure(self._sub, text=label)

    # -- layout
    def _schedule(self, _e=None) -> None:
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(90, self._build)

    def _glow(self, accent: str):
        key = (round(self._R), accent)
        if key not in self._cache:
            if len(self._cache) > 12:
                self._cache.clear()
            self._cache[key] = ImageTk.PhotoImage(_render_orb(self._R, accent))
        return self._cache[key]

    def _build(self) -> None:
        self._job = None
        w, h = self.winfo_width(), self.winfo_height()
        if w < 120 or h < 120:
            return
        R = min(w / 2.4, h / 2.62) * 0.94
        self._R = R
        cx = w / 2
        cy = (h - 2.5 * R) / 2 + 1.08 * R
        py = cy + 1.22 * R
        self.delete("all")
        self._tint, self._arcs, self._dashes = [], [], []
        self._glow_id = self.create_image(cx, cy, image=self._glow(self._target), anchor="center")

        def t_out(item, k, kind="a"):
            self._tint.append((item, "outline", kind, k))

        def t_fill(item, k):
            self._tint.append((item, "fill", "a", k))

        # projector base
        t_fill(self.create_oval(cx - R * .40, py - R * .08, cx + R * .40, py + R * .08, fill=BG, outline=""), 0.16)
        for f, wd, k, dashed in [(1.10, 1, .40, False), (0.92, 1, .55, True), (0.76, 2, .50, False),
                                 (0.58, 2, .80, True), (0.40, 3, 1.0, False), (0.24, 3, 1.0, False)]:
            rx = R * f
            ry = rx * 0.2
            kw = dict(dash=(px(10), px(8))) if dashed else {}
            item = self.create_oval(cx - rx, py - ry, cx + rx, py + ry, outline=ACCENT, width=px(wd), **kw)
            t_out(item, k)
            if dashed:
                self._dashes.append((item, -28 if f > .7 else 40, px(18)))
        # light beam from sphere to base: a tapered glow (brighter than the halo behind it) + a core line
        t_fill(self.create_polygon(cx - .075 * R, cy + .64 * R, cx + .075 * R, cy + .64 * R,
                                   cx + .028 * R, py, cx - .028 * R, py, fill=BG, outline=""), 0.50)
        core = self.create_line(cx, cy + .64 * R, cx, py, fill=ACCENT_HI, width=px(2))
        self._tint.append((core, "fill", "h", .45))
        # tick ring
        tick = mix(BG, ACCENT, .38)
        for i in range(120):
            a = math.radians(i * 3)
            r1, r2 = 1.10 * R, (1.145 if i % 5 == 0 else 1.125) * R
            self.create_line(cx + r1 * math.cos(a), cy - r1 * math.sin(a), cx + r2 * math.cos(a),
                             cy - r2 * math.sin(a), fill=tick, width=1)
        # rings
        self._dashes.append((self._ring(cx, cy, 1.06 * R, 1, .50, dash=(px(2), px(7))), 22, px(9)))
        self._arc_ring(cx, cy, 1.00 * R, [20, 140, 260], 62, px(4), "h", .25, 14)
        self._ring(cx, cy, 0.93 * R, 1, .32)
        self._arc_ring(cx, cy, 0.86 * R, [60, 240], 104, px(5), "a", .95, -22)
        self._dashes.append((self._ring(cx, cy, 0.78 * R, px(2), .55, dash=(px(12), px(7))), -34, px(19)))
        self._arc_ring(cx, cy, 0.73 * R, [0, 90, 180, 270], 34, px(2), "h", .45, 52)
        self._core = self.create_oval(0, 0, 1, 1, outline=ACCENT_HI, width=px(2))
        self._tint.append((self._core, "outline", "h", .35))
        self._cx, self._cy = cx, cy
        # lettering
        self.create_text(cx, cy - .02 * R, text=" ".join(ASSISTANT.upper()), fill="#eaffff",
                         font=font("display", max(14, R * .17), True))
        self._sub = self.create_text(cx, cy + .21 * R, text=self._label, fill=ACCENT_HI,
                                     font=font("body", max(10, R * .062)))
        self._built = True
        self._dirty = True
        self._accent = self._target

    def _ring(self, cx, cy, r, width, k, **kw):
        item = self.create_oval(cx - r, cy - r, cx + r, cy + r, outline=ACCENT, width=width, **kw)
        self._tint.append((item, "outline", "a", k))
        return item

    def _arc_ring(self, cx, cy, r, starts, extent, width, kind, k, speed):
        for s in starts:
            item = self.create_arc(cx - r, cy - r, cx + r, cy + r, start=s, extent=extent, style="arc",
                                   outline=ACCENT, width=width)
            self._tint.append((item, "outline", kind, k))
            self._arcs.append((item, s, speed))

    # -- animation
    def animate(self, dt: float, t: float) -> None:
        if not self._built:
            return
        self._spd += (self._spd_target - self._spd) * min(1.0, dt * 3.0)
        self._phase += dt * self._spd
        for item, base, speed in self._arcs:
            self.itemconfigure(item, start=(base + self._phase * speed) % 360)
        for item, speed, period in self._dashes:
            self.itemconfigure(item, dashoffset=int(self._phase * speed) % period)
        if self._accent != self._target:
            self._accent = mix(self._accent, self._target, min(1.0, dt * 4.0))
            if sum(abs(a - b) for a, b in zip(_rgb(self._accent), _rgb(self._target))) < 4:
                self._accent = self._target
            self._dirty = True
        if self._dirty:
            for item, opt, kind, k in self._tint:
                col = mix(BG, self._accent, k) if kind == "a" else mix(self._accent, "#ffffff", k)
                self.itemconfigure(item, **{opt: col})
            self._dirty = self._accent != self._target
        r = self._R * (0.665 + 0.008 * math.sin(t * 2.2))
        self.coords(self._core, self._cx - r, self._cy - r, self._cx + r, self._cy + r)


def _render_orb(R: float, accent: str) -> Image.Image:
    """Sphere with a bright rim, a soft halo and some circuitry inside."""
    half = max(8, int(R * 1.25))
    size = half * 2
    grad = Image.radial_gradient("L").resize((size, size), Image.BICUBIC)
    lut = []
    for p in range(256):
        d = p / 255 * 1.25 * math.sqrt(2)        # Pillow's gradient hits 255 at the corner, not the edge
        if d > 0.66:                             # halo outside the rim
            v = 0.62 * math.exp(-((d - 0.66) / 0.17) ** 2)
        else:                                    # body: dim core, bright rim
            u = d / 0.66
            v = 0.11 + 0.47 * u ** 2.3 + 0.08 * math.exp(-(u / 0.4) ** 2)
        lut.append(int(max(0.0, min(1.0, v * 1.3)) * 255))
    img = ImageOps.colorize(grad.point(lut), black=BG, white=mix(accent, "#ffffff", 0.25)).convert("RGBA")

    # circuitry inside the sphere (drawn 2x and scaled down for smooth lines)
    ss, rs = 2, int(R * 0.66)
    ov = Image.new("RGBA", (2 * rs * ss, 2 * rs * ss), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    c = rs * ss
    hi = _rgb(mix(accent, "#ffffff", 0.45))
    rnd = random.Random(7)
    for rf in (0.58, 0.50, 0.41, 0.29):
        rr = rf * R * ss
        od.ellipse((c - rr, c - rr, c + rr, c + rr), outline=hi + (70,), width=ss)
    for _ in range(170):
        rr = rnd.uniform(0.08, 0.63) * R * ss
        a = rnd.uniform(0, 360)
        od.arc((c - rr, c - rr, c + rr, c + rr), a, a + rnd.uniform(12, 110),
               fill=hi + (int(rnd.uniform(60, 190)),), width=ss * rnd.choice((1, 1, 2)))
    ov = ov.resize((2 * rs, 2 * rs), Image.LANCZOS)
    img.alpha_composite(ov, (half - rs, half - rs))
    return img.convert("RGB")


# --------------------------------------------------------------------------- voice bar
class VoiceBar(tk.Canvas):
    BARS = 9

    def __init__(self, master):
        super().__init__(master, height=px(122), bg=BG, highlightthickness=0, bd=0)
        self._shown = ("", "")
        self._bars: list = []
        self.bind("<Configure>", lambda e: self._build())

    def _build(self) -> None:
        w, h = self.winfo_width(), self.winfo_height()
        if w < 200:
            return
        self.delete("all")
        top = px(34)
        cx = w / 2
        round_rect(self, px(2), top, w - px(2), h - px(4), px(28), fill=PANEL, outline=EDGE, width=1)
        self._bars = []
        self._bar_y = top + px(58)
        if w >= px(470):
            for side in (-1, 1):
                for i in range(self.BARS):
                    x = (px(34) + i * px(8)) if side < 0 else (w - px(34) - i * px(8))
                    self._bars.append(self.create_line(x, self._bar_y, x, self._bar_y, fill=ACCENT,
                                                       width=px(3), capstyle="round"))
        mr = px(29)
        self._ring = self.create_oval(0, 0, 1, 1, outline=ACCENT, width=1)
        self._mic_bg = self.create_oval(cx - mr, top - mr, cx + mr, top + mr, fill=BG, outline=ACCENT, width=px(2))
        draw_icon(self, "mic", cx, top, px(11), ACCENT_HI, tag="mic")
        self._cx, self._top, self._mr = cx, top, mr
        self._main = self.create_text(cx, top + px(46), text="", fill=TEXT, font=font("display", 16, True))
        self._hint = self.create_text(cx, top + px(70), text="", fill=MUTED, font=font("body", 12))
        self._shown = ("", "")

    def animate(self, t: float, status: str, mic: str) -> None:
        if not hasattr(self, "_main"):
            return
        accent, _spd, _label, style = STATES.get(status, STATES["Idle"])
        main, hint = {
            "idle": ("Standing by", f'Say "{ASSISTANT.title()}", then give a command'),
            "listen": ("Listening\u2026", 'Try "open notepad" or "what time is it"'),
            "think": ("Thinking\u2026", "Working on your request"),
            "speak": ("Speaking\u2026", f"{ASSISTANT.title()} is replying"),
        }[style]
        ring_col = accent if mic != "wake" else DIM
        if mic == "error":
            main, hint, ring_col, style = ("Microphone unavailable",
                                           "Check Windows privacy settings, or type a command below",
                                           DANGER, "idle")
        if (main, hint) != self._shown:
            self._shown = (main, hint)
            self.itemconfigure(self._main, text=main, fill=DANGER if mic == "error" else TEXT)
            self.itemconfigure(self._hint, text=hint)
        self.itemconfigure(self._mic_bg, outline=ring_col)
        self.itemconfigure("mic", fill=ring_col if mic == "error" else ACCENT_HI)
        pulse = (0.5 + 0.5 * math.sin(t * 4)) if style in ("listen", "speak") else 0.0
        rr = self._mr + px(5) + px(7) * pulse
        self.coords(self._ring, self._cx - rr, self._top - rr, self._cx + rr, self._top + rr)
        self.itemconfigure(self._ring, outline=mix(BG, ring_col, 0.15 + 0.55 * (1 - pulse)) if pulse else BG)
        # waveform
        n = self.BARS
        for idx, bar in enumerate(self._bars):
            i = idx % n
            if style == "listen":
                a = 0.30 + 0.70 * abs(math.sin(t * 5.1 + i * 0.9) * math.cos(t * 2.3 + i * 0.5))
            elif style == "speak":
                a = 0.25 + 0.75 * abs(math.sin(t * 7.0 + i * 1.3))
            elif style == "think":
                a = 0.15 + 0.85 * max(0.0, math.sin(t * 6.0 - i * 0.7)) ** 2
            else:
                a = 0.10 + 0.05 * math.sin(t * 1.5 + i * 0.6)
            x = self.coords(bar)[0]
            hh = max(px(2), px(17) * a)
            self.coords(bar, x, self._bar_y - hh, x, self._bar_y + hh)
            self.itemconfigure(bar, fill=mix(BG, accent if mic != "error" else DANGER, 0.35 + 0.65 * a))


# --------------------------------------------------------------------------- the window
class AppWindow(tk.Tk):
    def __init__(self):
        global _SCALE
        _enable_dpi_awareness()
        super().__init__()
        _SCALE = max(1.0, min(3.0, self.winfo_fpixels("1i") / 96.0))
        _init_fonts()

        self.title(ASSISTANT)
        self.configure(bg=BG)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(px(1460), sw - px(40)), min(px(900), sh - px(90))
        self.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 2 - px(20))}")
        self.minsize(min(px(1240), w), min(px(740), h))

        self._status, self._mode, self._mic = "Idle", "wake", "wake"
        self._submit_callback: Optional[Callable[[str], None]] = None
        self._events: "queue.Queue[tuple]" = queue.Queue()
        self._alive = True
        self._t = 0.0
        self._last = time.perf_counter()
        self._clock_sec = -1
        self._net_prev = None

        self._build_ui()
        self._apply_status("Idle")
        self.after(30, self._frame)
        self.after(300, self._poll_stats)

    # ------------------------------------------------------------------ construction
    def _build_ui(self) -> None:
        self.header = HeaderBar(self)
        self.header.pack(fill="x", padx=px(20), pady=(px(12), 0))

        content = tk.Frame(self, bg=BG)
        content.pack(fill="both", expand=True, padx=px(20), pady=(px(10), px(16)))
        content.rowconfigure(0, weight=1)
        content.columnconfigure(2, weight=1)

        # sidebar
        side = tk.Frame(content, bg=BG)
        side.grid(row=0, column=0, sticky="ns", padx=(0, px(14)))
        self.nav_home = NavButton(side, "Home", "home", lambda: self.log_text.see("end"), active=True)
        self.nav_home.pack(pady=(px(4), px(6)))
        for text, icon, cmd in [
            ("Files", "folder", lambda: self._run("list files")),
            ("Browser", "globe", lambda: self._prefill("search for ")),
            ("Tools", "grid", lambda: self._run("what tools do you have")),
        ]:
            btn = NavButton(side, text, icon, lambda: None)
            btn._cmd = lambda c=cmd, b=btn: (b.flash(), c())
            btn.pack(pady=px(3))

        # left column
        left = tk.Frame(content, bg=BG)
        left.grid(row=0, column=1, sticky="ns", padx=(0, px(14)))
        greet = TechPanel(left, width=290, height=400)
        greet.pack(fill="both", expand=True)
        g = greet.body
        tk.Label(g, text=f"Hello, {USER_TITLE}.", bg=PANEL, fg=TEXT, anchor="w",
                 font=font("display", 24, True)).pack(fill="x", pady=(px(4), px(2)))
        tk.Label(g, text=f"I am {ASSISTANT}. Your personal AI assistant. How can I help you today?",
                 bg=PANEL, fg=SOFT, anchor="w", justify="left", wraplength=px(246),
                 font=font("body", 14)).pack(fill="x")
        tk.Frame(g, bg=EDGE_DIM, height=1).pack(fill="x", pady=(px(14), px(4)))
        for text, icon, cmd in [
            ("Search the web", "search", lambda: self._prefill("search for ")),
            ("Open applications", "folder", lambda: self._prefill("open ")),
            ("Manage your files", "note", lambda: self._prefill("create a file called ")),
            ("Check system status", "grid", lambda: self._run("system status")),
            ("Take a screenshot", "camera", lambda: self._run("take a screenshot")),
            ("Ask a question", "chat", lambda: self._prefill("what is ")),
        ]:
            CapRow(g, text, icon, cmd).pack(fill="x")

        quote = TechPanel(left, width=290, height=124)
        quote.pack(fill="x", pady=(px(14), 0))
        tk.Label(quote.body, text="\u201cThe future is not something we enter. The future is something we create.\u201d",
                 bg=PANEL, fg=TEXT, anchor="w", justify="left", wraplength=px(246),
                 font=font("body", 14, italic=True)).pack(fill="x", pady=(px(2), 0))
        tk.Label(quote.body, text=ASSISTANT.upper(), bg=PANEL, fg=MUTED, anchor="e",
                 font=font("body", 11)).pack(fill="x", pady=(px(4), 0))

        # centre column
        centre = tk.Frame(content, bg=BG)
        centre.grid(row=0, column=2, sticky="nsew", padx=(0, px(14)))
        self.orb = OrbCanvas(centre)
        self.orb.pack(fill="both", expand=True)
        self.voice = VoiceBar(centre)
        self.voice.pack(fill="x", padx=px(6))
        self.command = CommandInput(centre, self._run)
        self.command.pack(fill="x", padx=px(6), pady=(px(12), 0))

        # right column
        right = tk.Frame(content, bg=BG)
        right.grid(row=0, column=3, sticky="ns")
        acts = TechPanel(right, "QUICK ACTIONS", width=330, height=156)
        acts.pack(side="bottom", fill="x")
        stat = TechPanel(right, "SYSTEM STATUS", width=330, height=262)
        stat.pack(fill="x")
        row = tk.Frame(stat.body, bg=PANEL)
        row.pack(fill="x")
        self.cpu = Gauge(row, "CPU")
        self.cpu.pack(side="left", expand=True)
        self.ram = Gauge(row, "RAM")
        self.ram.pack(side="right", expand=True)
        self.disk = Meter(stat.body, "Disk usage")
        self.disk.pack(fill="x", pady=(px(8), 0))
        self.net = Meter(stat.body, "Network")
        self.net.pack(fill="x", pady=(px(8), 0))

        logp = TechPanel(right, "ACTIVITY LOG", width=330, height=110)
        logp.pack(fill="both", expand=True, pady=px(14))
        clear = tk.Label(logp, text="Clear", bg=PANEL, fg=MUTED, cursor="hand2", font=font("body", 12))
        clear.place(relx=1.0, x=-px(48), y=px(16))
        clear.bind("<Button-1>", lambda e: self._clear_log())
        clear.bind("<Enter>", lambda e: clear.configure(fg=ACCENT_HI))
        clear.bind("<Leave>", lambda e: clear.configure(fg=MUTED))
        self.log_text = tk.Text(logp.body, bg=PANEL, fg=TEXT, relief="flat", bd=0, highlightthickness=0,
                                wrap="word", font=font("body", 13), padx=0, pady=0, spacing1=px(2),
                                spacing3=px(3), cursor="arrow", state="disabled", insertwidth=0,
                                selectbackground=EDGE)
        sb = SlimScroll(logp.body, self.log_text.yview)
        sb.pack(side="right", fill="y", padx=(px(6), 0))
        self.log_text.pack(side="left", fill="both", expand=True)
        self.log_text.configure(yscrollcommand=sb.set)
        for tag, opts in LOG_TAGS.items():
            self.log_text.tag_configure(tag, **opts)
        self.log_text.tag_configure("output", font=font("mono", 12))

        grid = acts.body
        grid.columnconfigure((0, 1), weight=1, uniform="a")
        for i, (text, icon, cmd) in enumerate([
            ("Notepad", "note", lambda: self._run("open notepad")),
            ("Screenshot", "camera", lambda: self._run("take a screenshot")),
            ("Stay Active", "bolt", lambda: self._run("stay active")),
            ("Sleep Mode", "sleep", lambda: self._run("go to sleep")),
        ]):
            PillButton(grid, text, cmd, icon=icon, height=38, width=140).grid(
                row=i // 2, column=i % 2, sticky="ew",
                padx=(0, px(5)) if i % 2 == 0 else (px(5), 0), pady=px(4))

    # ------------------------------------------------------------------ actions
    def _run(self, text: str) -> None:
        if self._submit_callback is not None:
            self._submit_callback(text)

    def _prefill(self, text: str) -> None:
        self.command.set_text(text)

    def _clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")
        self._write_log("Log cleared.", "info")

    # ------------------------------------------------------------------ public API (thread safe)
    def set_submit_callback(self, callback: Callable[[str], None]) -> None:
        self._submit_callback = callback

    def append_log(self, text, tag="info") -> None:
        self._events.put(("log", (str(text), tag)))

    def set_status(self, status) -> None:
        self._events.put(("status", status))

    def set_mic(self, state) -> None:
        self._events.put(("mic", state))

    def set_mode(self, mode) -> None:
        self._events.put(("mode", mode))

    def destroy(self) -> None:
        self._alive = False
        super().destroy()

    # ------------------------------------------------------------------ applying events (Tk thread)
    def _drain(self) -> None:
        for _ in range(200):
            try:
                kind, value = self._events.get_nowait()
            except queue.Empty:
                return
            if kind == "log":
                self._write_log(*value)
            elif kind == "status":
                self._apply_status(value)
            elif kind == "mic":
                self._mic = value
            elif kind == "mode":
                self._mode = value
                self._apply_status(self._status)

    def _write_log(self, text: str, tag: str) -> None:
        log = self.log_text
        at_end = log.yview()[1] >= 0.98
        log.configure(state="normal")
        if int(log.index("end-1c").split(".")[0]) > 1200:
            log.delete("1.0", "300.0")
        log.insert("end", text + "\n", tag if tag in LOG_TAGS else "info")
        log.configure(state="disabled")
        if at_end:
            log.see("end")

    def _apply_status(self, status: str) -> None:
        self._status = status
        accent, speed, label, _ = STATES.get(status, STATES["Idle"])
        self.orb.set_state(accent, speed, label)
        mode = "Wake word mode" if self._mode == "wake" else "Always listening"
        self.header.set_state(status.upper(), accent, mode)

    # ------------------------------------------------------------------ loops
    def _frame(self) -> None:
        if not self._alive:
            return
        try:
            now = time.perf_counter()
            dt = min(0.1, now - self._last)
            self._last, self._t = now, self._t + dt
            self._drain()
            self.orb.animate(dt, self._t)
            self.voice.animate(self._t, self._status, self._mic)
            self.header.animate(self._t)
            self.cpu.step()
            self.ram.step()
            if int(now) != self._clock_sec:
                self._clock_sec = int(now)
                self.header.update_clock()
        except tk.TclError:
            return
        self.after(33, self._frame)

    def _poll_stats(self) -> None:
        if not self._alive:
            return
        if psutil is not None:
            try:
                self.cpu.set(psutil.cpu_percent(None))
                self.ram.set(psutil.virtual_memory().percent)
                disk = psutil.disk_usage(os.path.abspath(os.sep)).percent
                self.disk.set(disk / 100, f"{disk:.0f}%")
                io = psutil.net_io_counters()
                now = time.time()
                if io is not None and self._net_prev is not None:
                    total, stamp = self._net_prev
                    mbps = max(0.0, (io.bytes_sent + io.bytes_recv - total) * 8 / 1e6 / max(0.2, now - stamp))
                    self.net.set(min(1.0, mbps / 100), f"{mbps:.1f} Mbps")
                if io is not None:
                    self._net_prev = (io.bytes_sent + io.bytes_recv, now)
            except Exception:
                pass
        self.after(1000, self._poll_stats)
