"""Type or paste text into the currently active window."""
import time

TOOL_NAME = "type_text"
TOOL_DESCRIPTION = "Types text (or code) into whichever window is currently active."
TRIGGER_PHRASES = ["type text", "type", "dictate"]
TOOL_ARGS = '{"text": "the text to type", "mode": "paste" (default, fast) or "type" (key by key)}'


def run(args: dict) -> str:
    text = args.get("text") or ""
    if not text.strip():
        return "What should I type, sir?"
    import pyautogui

    time.sleep(float(args.get("delay", 0.6)))  # let the target window settle
    if args.get("mode") == "type":
        pyautogui.write(text, interval=0.01)
    else:
        import pyperclip

        previous = None
        try:
            previous = pyperclip.paste()
        except Exception:
            pass
        pyperclip.copy(text)
        time.sleep(0.1)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.3)
        if previous is not None:
            try:
                pyperclip.copy(previous)
            except Exception:
                pass
    return f"Typed {len(text)} characters."
