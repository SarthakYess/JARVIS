"""Browser control: open websites in Chrome, search Google, search YouTube, or play a YouTube video."""
import logging
import os
import re
import shutil
import subprocess
import urllib.request
import webbrowser
from pathlib import Path
from urllib.parse import quote_plus

TOOL_NAME = "browser"
TOOL_DESCRIPTION = "Opens a website in Chrome, searches Google, searches YouTube, or plays a YouTube video."
TRIGGER_PHRASES = ["go to", "browse to", "visit", "play"]
TOOL_ARGS = ('{"action": "open" or "google" or "youtube_search" or "youtube_play", '
             '"query": "search words or video name", "site": "site name or url for action open"}')

log = logging.getLogger("jarvis.tools.browser")

SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com", "gmail": "https://mail.google.com",
    "chatgpt": "https://chatgpt.com", "claude": "https://claude.ai", "github": "https://github.com",
    "whatsapp": "https://web.whatsapp.com", "whatsapp web": "https://web.whatsapp.com",
    "instagram": "https://www.instagram.com", "facebook": "https://www.facebook.com",
    "twitter": "https://x.com", "x": "https://x.com", "linkedin": "https://www.linkedin.com",
    "reddit": "https://www.reddit.com", "netflix": "https://www.netflix.com", "amazon": "https://www.amazon.in",
    "flipkart": "https://www.flipkart.com", "maps": "https://maps.google.com", "google maps": "https://maps.google.com",
    "drive": "https://drive.google.com", "google drive": "https://drive.google.com", "stack overflow": "https://stackoverflow.com",
    "stackoverflow": "https://stackoverflow.com", "spotify": "https://open.spotify.com", "wikipedia": "https://www.wikipedia.org",
    "translate": "https://translate.google.com", "calendar": "https://calendar.google.com", "gemini": "https://gemini.google.com",
    "perplexity": "https://www.perplexity.ai", "groq": "https://console.groq.com", "telegram": "https://web.telegram.org",
    "discord": "https://discord.com/app", "pinterest": "https://www.pinterest.com", "twitch": "https://www.twitch.tv",
}


def _chrome_path() -> str:
    found = shutil.which("chrome")
    if found:
        return found
    for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        candidate = Path(os.environ.get(env, "")) / "Google/Chrome/Application/chrome.exe"
        if candidate.exists():
            return str(candidate)
    return ""


def open_url(url: str) -> None:
    """Open a URL in Chrome (new tab) when installed, otherwise in the default browser."""
    chrome = _chrome_path()
    if chrome:
        subprocess.Popen([chrome, url])
    else:
        webbrowser.open(url)


def resolve_site(name: str) -> str:
    """'youtube' -> url, 'example.com' -> https://example.com, unknown -> ''."""
    name = name.lower().strip(" .")
    if name in SITES:
        return SITES[name]
    squashed = name.replace(" dot ", ".").replace(" ", "")
    if re.fullmatch(r"[\w-]+(?:\.[\w-]+)+(?:/\S*)?", squashed):
        return "https://" + squashed
    return ""


def google(query: str) -> str:
    open_url("https://www.google.com/search?q=" + quote_plus(query))
    return f"Searching Google for {query}."


def youtube_search(query: str) -> str:
    open_url("https://www.youtube.com/results?search_query=" + quote_plus(query))
    return f"Searching YouTube for {query}."


def youtube_play(query: str) -> str:
    """Find the top YouTube result for the query and open it directly so it starts playing."""
    results_url = "https://www.youtube.com/results?search_query=" + quote_plus(query)
    try:
        request = urllib.request.Request(results_url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9"})
        html = urllib.request.urlopen(request, timeout=8).read().decode("utf-8", "ignore")
        ids = re.findall(r'"videoId":"([\w-]{11})"', html)
        if ids:
            open_url(f"https://www.youtube.com/watch?v={ids[0]}")
            return f"Playing {query} on YouTube."
    except Exception as exc:
        log.warning("YouTube lookup failed: %s", exc)
    open_url(results_url)
    return f"Showing YouTube results for {query}."


def run(args: dict) -> str:
    action = str(args.get("action", "")).lower()
    query = str(args.get("query") or args.get("text") or "").strip(" .,")
    site = str(args.get("site") or args.get("url") or "").strip()
    if action in ("youtube_play", "play"):
        return youtube_play(query) if query else "What should I play, sir?"
    if action == "youtube_search":
        return youtube_search(query) if query else "What should I search for, sir?"
    if action == "google":
        return google(query) if query else "What should I search for, sir?"
    if not action and not site and re.match(r"(?:go to|visit|browse to)\b", str(args.get("command", "")).lower()) and query:
        site = query  # "go to claude" arriving through the generic trigger
    if action == "open" or site:
        url = resolve_site(site or query)
        if not url:
            return f"I don't know the website {site or query}, sir."
        open_url(url)
        return f"Opening {site or query}."
    if query:  # bare "play ..." trigger
        return youtube_play(query)
    return "Which website should I open, sir?"
