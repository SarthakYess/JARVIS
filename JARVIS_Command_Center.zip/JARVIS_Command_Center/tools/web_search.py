"""Search the web (Google) or YouTube in the default browser."""
import webbrowser
from urllib.parse import quote_plus

TOOL_NAME = "web_search"
TOOL_DESCRIPTION = "Searches Google, or YouTube when asked, in the default browser."
TRIGGER_PHRASES = [
    "search the web for", "search youtube for", "search for", "look up", "search", "google",
    "youtube search",
]
TOOL_ARGS = '{"query": "search words", "site": "google" or "youtube"}'


def run(args: dict) -> str:
    query = (args.get("query") or args.get("text") or "").strip(" .,")
    command = (args.get("command") or "").lower()
    if not query:
        return "What should I search for, sir?"
    site = (args.get("site") or ("youtube" if "youtube" in command else "google")).lower()
    if site == "youtube":
        query = query.lower().replace("on youtube", "").strip() or query
        webbrowser.open("https://www.youtube.com/results?search_query=" + quote_plus(query))
        return f"Searching YouTube for {query}."
    webbrowser.open("https://www.google.com/search?q=" + quote_plus(query))
    return f"Searching the web for {query}."
