"""Politely close a running application (asks it to close, so it can offer to save)."""
import logging
import os
import re
import subprocess

TOOL_NAME = "close_app"
TOOL_DESCRIPTION = "Closes a running application by name (the app may ask to save unsaved work)."
TRIGGER_PHRASES = ["close", "quit", "exit", "kill", "terminate"]
TOOL_ARGS = '{"name": "app name, e.g. notepad"}'

log = logging.getLogger("jarvis.tools.close_app")

PROCESS_NAMES = {
    "notepad": "notepad.exe", "calculator": "calculatorapp.exe", "calc": "calculatorapp.exe",
    "paint": "mspaint.exe", "chrome": "chrome.exe", "google chrome": "chrome.exe", "edge": "msedge.exe",
    "firefox": "firefox.exe", "word": "winword.exe", "excel": "excel.exe", "powerpoint": "powerpnt.exe",
    "vs code": "code.exe", "vscode": "code.exe", "spotify": "spotify.exe", "task manager": "taskmgr.exe",
    "command prompt": "cmd.exe", "powershell": "powershell.exe",
}
PROTECTED = {
    "explorer.exe", "system", "svchost.exe", "winlogon.exe", "csrss.exe", "services.exe", "lsass.exe",
    "wininit.exe", "dwm.exe", "python.exe", "pythonw.exe", "jarvis.exe", "smss.exe",
}
_FILLER = re.compile(r"\b(?:the|app|application|program|please|window|for me|my)\b", re.IGNORECASE)


def _name(args: dict) -> str:
    return _FILLER.sub(" ", str(args.get("name") or args.get("text") or "")).strip(" .,!?").lower()


def _matching_exes(name: str) -> set:
    import psutil

    wanted = PROCESS_NAMES.get(name)
    squashed = name.replace(" ", "")
    found = set()
    for proc in psutil.process_iter(["name", "pid"]):
        try:
            exe = (proc.info["name"] or "").lower()
            if proc.info["pid"] == os.getpid():
                continue
            if (wanted and exe == wanted) or (not wanted and squashed and exe.startswith(squashed)):
                found.add(exe)
        except Exception:
            continue
    return found


def needs_confirmation(args: dict):
    name = _name(args)
    if not name:
        return None
    return f"Close {name}? Unsaved work may be lost, sir. Please say yes to confirm."


def run(args: dict) -> str:
    name = _name(args)
    if not name:
        return "Which app should I close, sir?"
    exes = _matching_exes(name)
    blocked = exes & PROTECTED
    exes -= PROTECTED
    if blocked and not exes:
        return f"I won't close {name}, sir. It is a protected process."
    if not exes:
        return f"I couldn't find {name} running."
    for exe in sorted(exes):
        # No /F flag: the app is asked to close normally and may prompt to save.
        subprocess.run(["taskkill", "/IM", exe], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        log.info("Asked %s to close", exe)
    return f"Asked {name} to close."
