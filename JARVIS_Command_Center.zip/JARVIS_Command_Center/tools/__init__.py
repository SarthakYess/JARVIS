"""JARVIS tools. Every non-underscore module here is auto-loaded by core.tool_registry."""
