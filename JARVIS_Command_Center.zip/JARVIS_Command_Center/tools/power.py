"""Shut down, restart or lock the computer (always asks for confirmation first, except lock/cancel)."""
import subprocess

TOOL_NAME = "power"
TOOL_DESCRIPTION = "Shuts down, restarts or locks the computer, or cancels a pending shutdown."
TRIGGER_PHRASES = [
    "shut down the computer", "shut down the pc", "shut down", "shutdown", "restart the computer",
    "restart the pc", "restart", "reboot", "lock the computer", "lock my pc", "lock the screen",
    "lock screen", "cancel shutdown", "cancel the shutdown",
]
TOOL_ARGS = '{"action": "shutdown" or "restart" or "lock" or "cancel"}'
_FLAGS = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _action(args: dict) -> str:
    action = (args.get("action") or "").lower()
    text = (args.get("command") or "").lower()
    if action in ("shutdown", "restart", "lock", "cancel"):
        return action
    if "cancel" in text:
        return "cancel"
    if "lock" in text:
        return "lock"
    if "restart" in text or "reboot" in text:
        return "restart"
    return "shutdown"


def needs_confirmation(args: dict):
    action = _action(args)
    if action == "shutdown":
        return "Are you sure you want to shut down the computer, sir?"
    if action == "restart":
        return "Are you sure you want to restart the computer, sir?"
    return None


def run(args: dict) -> str:
    action = _action(args)
    if action == "shutdown":
        subprocess.run(["shutdown", "/s", "/t", "15"], creationflags=_FLAGS)
        return "Shutting down in fifteen seconds. Say cancel shutdown to stop it."
    if action == "restart":
        subprocess.run(["shutdown", "/r", "/t", "15"], creationflags=_FLAGS)
        return "Restarting in fifteen seconds. Say cancel shutdown to stop it."
    if action == "cancel":
        subprocess.run(["shutdown", "/a"], creationflags=_FLAGS)
        return "Shutdown cancelled."
    subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"], creationflags=_FLAGS)
    return "Locking the computer."
