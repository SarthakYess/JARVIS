"""Create, read, list and delete files inside the user's home folder (default: Documents/JARVIS_Files)."""
import re
from pathlib import Path

TOOL_NAME = "file_ops"
TOOL_DESCRIPTION = "Creates, reads, lists or deletes files. Relative paths live in Documents/JARVIS_Files."
TRIGGER_PHRASES = [
    "create a new file", "create a file", "create file", "make a new file", "make a file", "make file",
    "new file", "read the file", "read file", "list files", "list my files", "show files", "show my files",
    "delete the file", "delete file", "remove the file", "remove file",
]
TOOL_ARGS = '{"action": "create" or "read" or "list" or "delete", "path": "file name", "content": "text for create"}'

WORKSPACE = Path.home() / "Documents" / "JARVIS_Files"
MAX_READ_CHARS = 1500


def _action(args: dict) -> str:
    action = str(args.get("action") or "").lower()
    if action in ("create", "read", "list", "delete"):
        return action
    text = str(args.get("command") or "").lower()
    if re.search(r"\b(delete|remove)\b", text):
        return "delete"
    if re.search(r"\b(list|show)\b.*\bfiles\b|\bwhat files\b", text):
        return "list"
    if re.search(r"\bread\b", text):
        return "read"
    return "create"


def _parse(args: dict):
    """Return (action, relative_or_absolute_name, content)."""
    action = _action(args)
    name = args.get("path") or args.get("name")
    content = args.get("content")
    if not name:
        text = str(args.get("text") or "")
        parts = re.split(r"\s+(?:with|containing|that says|saying|and write)\s+", text, maxsplit=1, flags=re.IGNORECASE)
        name = parts[0]
        if content is None and len(parts) > 1:
            content = parts[1]
        name = re.sub(r"^(?:called|named|the|a|an|file)\s+", "", name.strip(), flags=re.IGNORECASE)
        name = re.sub(r"^(?:called|named|the|file)\s+", "", name, flags=re.IGNORECASE)
        name = re.sub(r"\s+dot\s+", ".", name, flags=re.IGNORECASE).strip(" .,\"'").replace(" ", "_")
    name = str(name or "").strip()
    if name and not Path(name).suffix:
        name += ".txt"
    return action, name, content or ""


def _resolve(name: str) -> Path:
    path = Path(name).expanduser()
    if not path.is_absolute():
        path = WORKSPACE / path
    path = path.resolve()
    home = Path.home().resolve()
    if home != path and home not in path.parents:
        raise PermissionError("outside your home folder")
    return path


def needs_confirmation(args: dict):
    action, name, _ = _parse(args)
    if action == "delete" and name:
        return f"Are you sure you want to permanently delete {Path(name).name}, sir?"
    return None


def run(args: dict) -> str:
    action, name, content = _parse(args)
    try:
        if action == "list":
            WORKSPACE.mkdir(parents=True, exist_ok=True)
            names = sorted(p.name for p in WORKSPACE.iterdir() if p.is_file())
            if not names:
                return "Your JARVIS files folder is empty."
            shown = ", ".join(names[:15])
            return f"You have {len(names)} files: {shown}."
        if not name:
            return "Which file, sir?"
        path = _resolve(name)
        if action == "create":
            if path.exists():
                return f"{path.name} already exists, sir."
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return f"Created {path.name}."
        if action == "read":
            if not path.is_file():
                return f"I couldn't find {path.name}."
            text = path.read_text(encoding="utf-8", errors="replace").strip()
            if not text:
                return f"{path.name} is empty."
            return f"{path.name} says: {text[:MAX_READ_CHARS]}"
        if action == "delete":
            if not path.is_file():
                return f"I couldn't find {path.name}."
            path.unlink()
            return f"Deleted {path.name}."
        return "I don't know that file operation."
    except PermissionError:
        return "I can only work with files inside your home folder, sir."
    except OSError as exc:
        return f"The file operation failed: {exc.strerror or exc}."
