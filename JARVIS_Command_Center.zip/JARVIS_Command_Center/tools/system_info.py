"""Report CPU, memory, disk and battery status using psutil."""
from pathlib import Path

TOOL_NAME = "system_info"
TOOL_DESCRIPTION = "Reports CPU, memory, disk and battery status."
TRIGGER_PHRASES = [
    "system info", "system information", "system status", "cpu usage", "cpu", "memory usage", "ram usage",
    "disk space", "storage space", "battery level", "battery status", "battery", "how much battery",
    "how much ram",
]
TOOL_ARGS = '{"what": "cpu" or "memory" or "disk" or "battery" or "all"}'


def run(args: dict) -> str:
    import psutil

    text = f"{args.get('command', '')} {args.get('what', '')}".lower()
    parts = []
    everything = not any(k in text for k in ("cpu", "memory", "ram", "disk", "storage", "battery"))
    if everything or "cpu" in text:
        parts.append(f"CPU is at {psutil.cpu_percent(interval=0.5):.0f} percent")
    if everything or "memory" in text or "ram" in text:
        parts.append(f"memory is at {psutil.virtual_memory().percent:.0f} percent")
    if everything or "disk" in text or "storage" in text:
        try:
            usage = psutil.disk_usage(Path.home().anchor or "/")
            parts.append(f"the main disk is {usage.percent:.0f} percent full with {usage.free / 1e9:.0f} gigabytes free")
        except OSError:
            parts.append("I could not read the disk")
    if everything or "battery" in text:
        battery = psutil.sensors_battery()
        if battery is None:
            parts.append("there is no battery")
        else:
            state = "charging" if battery.power_plugged else "on battery"
            parts.append(f"battery is at {battery.percent:.0f} percent and {state}")
    sentence = ", ".join(parts)
    return sentence[0].upper() + sentence[1:] + "."
