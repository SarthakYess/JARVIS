"""Template for new JARVIS tools. Files starting with "_" are NOT loaded.

Copy this file, rename it, and fill in the four required names below.
  args["command"]  the full spoken command
  args["text"]     the words that follow the trigger phrase
Optional extras a tool may define:
  TOOL_ARGS = '{"name": "what this argument means"}'   # helps the AI planner ("AI ...")
  def needs_confirmation(args) -> str | None:           # return a yes/no question for risky actions
"""

TOOL_NAME = "example"
TOOL_DESCRIPTION = "What the tool does"
TRIGGER_PHRASES = ["open example", "start example"]
TOOL_ARGS = '{"text": "optional input for the tool"}'


def run(args: dict) -> str:
    # Generated tools must return early on a dry run so validation has no side effects.
    if args.get("dry_run"):
        return "dry run ok"
    # do the work, return a short result string
    return "Done"
