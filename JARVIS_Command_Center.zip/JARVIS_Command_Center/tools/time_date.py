"""Tell the current time and date."""
from datetime import datetime

TOOL_NAME = "time_date"
TOOL_DESCRIPTION = "Tells the current time and/or date."
TRIGGER_PHRASES = [
    "what time", "what's the time", "what is the time", "the time", "current time", "tell me the time",
    "what's the date", "what is the date", "today's date", "the date", "what day", "current date",
]
TOOL_ARGS = '{"what": "time" or "date" or "both"}'


def run(args: dict) -> str:
    now = datetime.now()
    text = f"{args.get('command', '')} {args.get('what', '')}".lower()
    time_part = f"It is {now.strftime('%I:%M %p').lstrip('0')}"
    date_part = f"today is {now.strftime('%A, %B')} {now.day}, {now.year}"
    wants_date = any(word in text for word in ("date", "day", "today"))
    wants_time = "time" in text or not wants_date
    if wants_time and wants_date:
        return f"{time_part}, and {date_part}."
    if wants_date:
        return date_part.capitalize() + "."
    return time_part + "."
