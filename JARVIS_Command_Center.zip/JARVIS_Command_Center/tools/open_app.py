"""Open desktop apps and well-known websites, then bring the app window to the front."""
import logging
import re
import subprocess
import time
import webbrowser

TOOL_NAME = "open_app"
TOOL_DESCRIPTION = "Opens a desktop application (notepad, calculator, chrome, ...) or a website (youtube, github, ...)."
TRIGGER_PHRASES = ["open", "launch", "start", "run"]
TOOL_ARGS = '{"name": "app or website name, e.g. notepad"}'

log = logging.getLogger("jarvis.tools.open_app")

# name -> (what to launch, window title keyword used to focus it)
APPS = {
    "notepad": ("notepad.exe", "notepad"),
    "calculator": ("calc.exe", "calculator"),
    "paint": ("mspaint.exe", "paint"),
    "command prompt": ("cmd.exe", "command prompt"),
    "powershell": ("powershell.exe", "powershell"),
    "task manager": ("taskmgr.exe", "task manager"),
    "file explorer": ("explorer.exe", "file explorer"),
    "snipping tool": ("snippingtool.exe", "snipping"),
    "settings": ("ms-settings:", "settings"),
    "chrome": ("chrome", "chrome"),
    "edge": ("msedge", "edge"),
    "firefox": ("firefox", "firefox"),
    "word": ("winword", "word"),
    "excel": ("excel", "excel"),
    "powerpoint": ("powerpnt", "powerpoint"),
    "vs code": ("code", "visual studio code"),
    "spotify": ("spotify", "spotify"),
}
ALIASES = {
    "calc": "calculator", "cmd": "command prompt", "terminal": "command prompt", "explorer": "file explorer",
    "files": "file explorer", "ms paint": "paint", "google chrome": "chrome", "browser": "chrome",
    "microsoft edge": "edge", "microsoft word": "word", "ms word": "word", "microsoft excel": "excel",
    "ms excel": "excel", "microsoft powerpoint": "powerpoint", "vscode": "vs code",
    "visual studio code": "vs code", "code": "vs code", "task manager": "task manager",
    "windows settings": "settings",
}
SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com", "gmail": "https://mail.google.com",
    "github": "https://github.com", "whatsapp web": "https://web.whatsapp.com", "maps": "https://maps.google.com",
    "netflix": "https://www.netflix.com", "reddit": "https://www.reddit.com",
}
_FILLER = re.compile(r"\b(?:the|app|application|program|please|for me|up|my|software)\b", re.IGNORECASE)


def _clean(name: str) -> str:
    name = re.sub(r"\s+dot\s+", ".", name, flags=re.IGNORECASE)
    name = _FILLER.sub(" ", name).strip(" .,!?").lower()
    name = re.sub(r"\s+", " ", name)
    return ALIASES.get(name, name)


def _launch(target: str) -> None:
    # 'start' resolves App Paths (chrome, winword, ...) and URI schemes (ms-settings:).
    # The target always comes from the APPS table above, never from raw user text.
    subprocess.Popen(["cmd", "/c", "start", "", target], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def _focus_window(keyword: str, timeout: float = 6.0) -> bool:
    try:
        import pygetwindow as gw
    except Exception:
        time.sleep(1.5)
        return False
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            windows = gw.getWindowsWithTitle(keyword)
        except Exception:
            windows = []
        for window in windows:
            try:
                if window.isMinimized:
                    window.restore()
                window.activate()
            except Exception:
                pass  # pygetwindow sometimes raises even though the window did come forward
            time.sleep(0.4)
            return True
        time.sleep(0.3)
    return False


def run(args: dict) -> str:
    name = _clean(str(args.get("name") or args.get("text") or ""))
    if not name:
        return "Which app should I open, sir?"
    try:
        if name in SITES:
            webbrowser.open(SITES[name])
            return f"Opening {name}."
        if re.fullmatch(r"[\w-]+(?:\.[\w-]+)+", name):
            webbrowser.open("https://" + name)
            return f"Opening {name}."
        if name in APPS:
            target, keyword = APPS[name]
            _launch(target)
            _focus_window(keyword)
            return f"Opening {name}."
        # Unknown app: ask the Windows Start menu to find it.
        import pyautogui

        pyautogui.press("win")
        time.sleep(0.7)
        pyautogui.write(name, interval=0.03)
        time.sleep(0.9)
        pyautogui.press("enter")
        _focus_window(name, timeout=5.0)
        return f"Trying to open {name}."
    except Exception as exc:
        log.error("open_app failed for %s: %s", name, exc)
        return f"I couldn't open {name}."
