"""Control the Windows master volume (pycaw, with a media-key fallback)."""
import logging
import re

TOOL_NAME = "volume"
TOOL_DESCRIPTION = "Raises, lowers, sets, mutes or unmutes the system volume, or reports the current level."
TRIGGER_PHRASES = [
    "volume up", "volume down", "turn up the volume", "turn down the volume", "increase the volume",
    "decrease the volume", "increase volume", "decrease volume", "raise the volume", "lower the volume",
    "set the volume", "set volume", "what's the volume", "what is the volume", "volume", "unmute", "mute",
]
TOOL_ARGS = '{"action": "up" or "down" or "set" or "mute" or "unmute", "level": number 0-100 (step size for up/down)}'

log = logging.getLogger("jarvis.tools.volume")
DEFAULT_STEP = 10


def _intent(args: dict):
    text = f"{args.get('command', '')} {args.get('text', '')}".lower()
    action = str(args.get("action") or "").lower()
    level = args.get("level")
    if not action:
        if "unmute" in text:
            action = "unmute"
        elif "mute" in text:
            action = "mute"
        elif re.search(r"\b(up|increase|raise|louder)\b", text):
            action = "up"
        elif re.search(r"\b(down|decrease|lower|reduce|quieter)\b", text):
            action = "down"
        elif re.search(r"\d", text) or "set" in text:
            action = "set"
        else:
            action = "report"
    if level is None:
        match = re.search(r"(\d{1,3})", text)
        level = int(match.group(1)) if match else None
    if level is not None:
        level = max(0, min(100, int(level)))
    return action, level


def _endpoint():
    from ctypes import POINTER, cast

    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

    speakers = AudioUtilities.GetSpeakers()
    if hasattr(speakers, "EndpointVolume"):  # newer pycaw
        return speakers.EndpointVolume
    interface = speakers.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(interface, POINTER(IAudioEndpointVolume))


def _with_pycaw(action: str, level) -> str:
    import comtypes

    comtypes.CoInitialize()
    try:
        endpoint = _endpoint()
        current = round(endpoint.GetMasterVolumeLevelScalar() * 100)
        if action == "mute":
            endpoint.SetMute(1, None)
            return "Muted."
        if action == "unmute":
            endpoint.SetMute(0, None)
            return "Unmuted."
        if action == "report":
            return f"The volume is at {current} percent."
        if action == "set":
            if level is None:
                return "What volume level should I set, sir?"
            target = level
        elif action == "up":
            target = min(100, current + (level if level is not None else DEFAULT_STEP))
        else:
            target = max(0, current - (level if level is not None else DEFAULT_STEP))
        endpoint.SetMute(0, None)
        endpoint.SetMasterVolumeLevelScalar(target / 100.0, None)
        return f"Volume set to {target} percent."
    finally:
        comtypes.CoUninitialize()


def _with_keys(action: str, level) -> str:
    import pyautogui

    step = level if level is not None else DEFAULT_STEP
    presses = max(1, step // 2)  # each media key press changes the volume by about 2 percent
    if action in ("mute", "unmute"):
        pyautogui.press("volumemute")
        return "Toggled mute."
    if action == "up":
        pyautogui.press("volumeup", presses=presses)
        return "Volume increased."
    if action == "down":
        pyautogui.press("volumedown", presses=presses)
        return "Volume decreased."
    if action == "set" and level is not None:
        pyautogui.press("volumedown", presses=50)
        pyautogui.press("volumeup", presses=level // 2)
        return f"Volume set to about {level} percent."
    return "I can't read the volume without the audio library, sir."


def run(args: dict) -> str:
    action, level = _intent(args)
    try:
        return _with_pycaw(action, level)
    except Exception as exc:
        log.warning("pycaw failed (%s); using media keys instead.", exc)
        return _with_keys(action, level)
