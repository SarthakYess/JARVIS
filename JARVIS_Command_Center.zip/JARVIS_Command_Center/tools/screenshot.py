"""Take a screenshot and save it to Pictures/JARVIS_Screenshots."""
import logging
from datetime import datetime
from pathlib import Path

TOOL_NAME = "screenshot"
TOOL_DESCRIPTION = "Takes a screenshot of the whole screen and saves it in the Pictures folder."
TRIGGER_PHRASES = ["take a screenshot", "take screenshot", "screenshot", "capture the screen", "screen capture"]
TOOL_ARGS = "{}"

log = logging.getLogger("jarvis.tools.screenshot")


def run(args: dict) -> str:
    import pyautogui

    folder = Path.home() / "Pictures" / "JARVIS_Screenshots"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
    pyautogui.screenshot().save(path)
    log.info("Screenshot saved to %s", path)
    return "Screenshot saved in your Pictures folder."
