"""Central settings for JARVIS: paths, model names, wake word, timings, logging."""
import logging
import os
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from dotenv import load_dotenv

# --------------------------------------------------------------------------
# Paths. BASE_DIR holds the code, APP_DIR holds user data (.env, logs, versions).
# They are the same when running from source and differ inside a PyInstaller exe.
# --------------------------------------------------------------------------
FROZEN = bool(getattr(sys, "frozen", False))
if FROZEN:
    BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    APP_DIR = Path(sys.executable).resolve().parent
else:
    BASE_DIR = Path(__file__).resolve().parent
    APP_DIR = BASE_DIR

load_dotenv(APP_DIR / ".env")

TOOLS_DIR = BASE_DIR / "tools"
LOG_DIR = APP_DIR / "logs"
VERSIONS_DIR = APP_DIR / "versions"
LOG_FILE = LOG_DIR / "jarvis.log"

# --------------------------------------------------------------------------
# Identity and wake word
# --------------------------------------------------------------------------
ASSISTANT_NAME = "JARVIS"
USER_TITLE = "sir"
WAKE_WORD = "jarvis"
# Speech engines often mishear the name, so a few close variants also count.
WAKE_WORD_PATTERN = re.compile(r"\b(?:jar\s?vis|jarvas|jervis|garvis|travis|javis)\b", re.IGNORECASE)

# --------------------------------------------------------------------------
# LLM (Groq). The key comes from .env and is never printed or logged.
# --------------------------------------------------------------------------
MAX_API_KEYS = 10


def _load_api_keys() -> list:
    """Collect up to 10 Groq keys: GROQ_API_KEY_1..GROQ_API_KEY_10, GROQ_API_KEYS (comma separated), GROQ_API_KEY."""
    found = [os.getenv(f"GROQ_API_KEY_{i}", "") for i in range(1, MAX_API_KEYS + 1)]
    found += os.getenv("GROQ_API_KEYS", "").split(",")
    found.append(os.getenv("GROQ_API_KEY", ""))
    keys = []
    for key in (k.strip().strip("\"'") for k in found):
        if key and key not in keys and not key.startswith("your_"):
            keys.append(key)
    return keys[:MAX_API_KEYS]


GROQ_API_KEYS = _load_api_keys()          # rotated automatically by core/llm.py
GROQ_API_KEY = GROQ_API_KEYS[0] if GROQ_API_KEYS else ""  # kept for backward compatibility
KEY_COOLDOWN_SECONDS = 60                 # how long a rate-limited key rests before it is used again
FAST_MODEL = os.getenv("JARVIS_FAST_MODEL", "openai/gpt-oss-20b")      # questions
STRONG_MODEL = os.getenv("JARVIS_STRONG_MODEL", "openai/gpt-oss-120b")  # code, plans, new tools
LLM_TIMEOUT_SECONDS = 40

# --------------------------------------------------------------------------
# Voice
# --------------------------------------------------------------------------
SPEECH_LANGUAGE = "en-US"
WAKE_LISTEN_TIMEOUT = 1.0      # seconds to wait for speech while idle
WAKE_PHRASE_LIMIT = 5          # max seconds of a wake phrase
COMMAND_TIMEOUT = 6            # seconds to wait for a command after the wake word
COMMAND_PHRASE_LIMIT = 15      # max seconds of a command
ACTIVE_LISTEN_TIMEOUT = 1.5    # polling interval in "stay active" mode
CONFIRM_TIMEOUT = 12           # seconds to wait for a yes/no answer
SPEECH_RATE = 185
SPEECH_VOLUME = 1.0
MAX_SPOKEN_CHARS = 250         # longer text goes to the GUI log with a short spoken summary

# Optional offline speech model for the wake word (https://alphacephei.com/vosk/models).
VOSK_MODEL_PATH = Path(os.getenv("VOSK_MODEL_PATH") or (APP_DIR / "models" / "vosk-model-small-en-us-0.15"))


def ensure_dirs() -> None:
    for directory in (LOG_DIR, VERSIONS_DIR):
        directory.mkdir(parents=True, exist_ok=True)


class _Redactor(logging.Filter):
    """Scrubs anything that looks like the API key from every log record."""

    _pattern = re.compile(r"gsk_[A-Za-z0-9]{10,}")

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
        except Exception:
            return True
        for key in GROQ_API_KEYS:
            message = message.replace(key, "[REDACTED]")
        record.msg = self._pattern.sub("[REDACTED]", message)
        record.args = ()
        return True


_configured = False


def get_logger() -> logging.Logger:
    """Return the shared 'jarvis' logger (all child loggers write to logs/jarvis.log)."""
    global _configured
    logger = logging.getLogger("jarvis")
    if not _configured:
        ensure_dirs()
        logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        handler.addFilter(_Redactor())
        logger.addHandler(handler)
        logger.propagate = False
        _configured = True
    return logger
