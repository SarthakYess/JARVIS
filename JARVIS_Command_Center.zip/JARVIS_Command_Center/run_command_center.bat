@echo off
cd /d "%~dp0"
if not exist venv python -m venv venv
call venv\Scripts\activate

rem Install only on the first run, or when requirements.txt changes.
fc /b requirements.txt venv\requirements.installed >nul 2>&1
if errorlevel 1 goto install
goto run

:install
echo Installing requirements - first run or requirements.txt changed...
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
copy /y requirements.txt venv\requirements.installed >nul

:run
python main_web.py
if errorlevel 1 pause
exit /b 0

:failed
echo.
echo Install failed. Read the error above, fix it, then run this file again.
pause
exit /b 1
