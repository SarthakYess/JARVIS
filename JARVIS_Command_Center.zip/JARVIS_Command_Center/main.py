"""JARVIS entry point: starts the GUI and the background voice loop."""
import logging
import queue
import re
import threading
import time
from typing import Optional

import config

config.ensure_dirs()
config.get_logger()

from core import tool_registry  # noqa: E402  (imported after logging is configured)
from core.llm import LLM  # noqa: E402
from core.router import Router  # noqa: E402
from core.self_manager import SelfManager  # noqa: E402
from core.voice_input import VoiceInput  # noqa: E402
from core.voice_output import VoiceOutput  # noqa: E402
from core.wake_word import WakeWordListener  # noqa: E402
from gui.app_window import AppWindow  # noqa: E402

log = logging.getLogger("jarvis.main")

STAY_ACTIVE = re.compile(r"\b(stay active|stay awake|keep listening|always listen)\b", re.IGNORECASE)
GO_TO_SLEEP = re.compile(r"\b(go to sleep|sleep mode|stand ?by|stop listening)\b", re.IGNORECASE)
YES_WORDS = {"yes", "yeah", "yep", "yup", "sure", "confirm", "confirmed", "proceed", "affirmative", "okay",
             "ok", "absolutely", "definitely"}
NO_WORDS = {"no", "nope", "nah", "cancel", "stop", "don't", "negative", "never"}


class Assistant:
    """Owns the voice loop. Also acts as the 'io' object used by the router and self manager."""

    def __init__(self, window: AppWindow) -> None:
        self.window = window
        self.voice_in = VoiceInput(on_error=self._speech_problem)
        self.voice_out = VoiceOutput()
        self.wake = WakeWordListener(self.voice_in)
        self.llm = LLM()
        tool_registry.load_tools()
        self.self_manager = SelfManager(io=self, llm=self.llm)
        self.router = Router(io=self, llm=self.llm, self_manager=self.self_manager)
        self.mode = "wake"  # "wake" = idle until "JARVIS", "active" = always listening
        self._status = "Idle"
        self._text_queue: "queue.Queue[str]" = queue.Queue()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name="voice-loop", daemon=True)

    # ------------------------------------------------------------ lifecycle
    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def submit_text(self, text: str) -> None:
        """Called by the GUI text box (runs on the Tk thread)."""
        self._text_queue.put(text)

    # --------------------------------------------------- io for router etc.
    def _set_status(self, status: str) -> None:
        self._status = status
        self.window.set_status(status)

    def _ui(self, text: str, tag: str = "info") -> None:
        self.window.append_log(text, tag)

    def say(self, text: str) -> None:
        """Speak a short reply and show it in the log."""
        log.info("SAY %s", text)
        self._ui(f"JARVIS: {text}", "jarvis")
        previous = self._status
        self._set_status("Speaking")
        try:
            self.voice_out.speak(text)
        finally:
            self._set_status(previous)

    def show(self, text: str) -> None:
        """Log-only output (long text, code, plans). Nothing is spoken."""
        log.info("SHOW %s", text[:500])
        self._ui(text, "output")

    def confirm(self, prompt: str) -> bool:
        """Ask a yes/no question by voice (or the text box). Only an explicit yes returns True."""
        self.say(prompt)
        self._set_status("Listening")
        self.window.set_mic("active")
        reply = self._get_reply(config.CONFIRM_TIMEOUT)
        self._set_status("Thinking")
        if not reply:
            self._ui("(no answer heard, treating it as no)", "info")
            return False
        self._ui(f"You: {reply}", "user")
        log.info("CONFIRM %r -> %r", prompt, reply)
        lowered = reply.lower()
        words = set(re.findall(r"[a-z']+", lowered))
        if words & NO_WORDS:
            return False
        return bool(words & YES_WORDS) or "go ahead" in lowered or "do it" in lowered

    def _get_reply(self, timeout: float) -> str:
        deadline = time.time() + timeout
        while time.time() < deadline and not self._stop.is_set():
            try:
                return self._text_queue.get_nowait()
            except queue.Empty:
                pass
            heard = self.voice_in.listen_once(timeout=1.5, phrase_limit=5)
            if heard:
                return heard
            if self.voice_in.mic_error:
                time.sleep(0.2)
        return ""

    def _speech_problem(self, message: str) -> None:
        self._ui(f"JARVIS: {message}", "error")
        self.voice_out.speak(message)

    # ------------------------------------------------------------ voice loop
    def _loop(self) -> None:
        self._greet()
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception:
                log.exception("Voice loop error")
                self._ui("An internal error occurred. Details are in logs/jarvis.log.", "error")
                self._set_status("Idle")
                time.sleep(1.0)

    def _greet(self) -> None:
        tools = len(tool_registry.list_tools())
        self._ui(f"Loaded {tools} tools and indexed {len(self.self_manager.files)} files.", "info")
        if not config.GROQ_API_KEYS:
            self._ui("No Groq API key found. Copy .env.example to .env and add GROQ_API_KEY_1 to _10. "
                     "Local commands still work.", "error")
        else:
            self._ui(f"Groq key rotation active with {len(config.GROQ_API_KEYS)} key(s).", "info")
        if config.VOSK_MODEL_PATH.exists() and self.voice_in.vosk_ready:
            self._ui("Offline wake word enabled (Vosk).", "info")
        self.say("JARVIS online. Say my name when you need me, sir.")

    def _tick(self) -> None:
        try:
            typed = self._text_queue.get_nowait()
        except queue.Empty:
            typed = None
        if typed is not None:
            self.handle(typed)
            return

        if self.mode == "active":
            self._set_status("Listening")
            self.window.set_mic("error" if self.voice_in.mic_error else "active")
            heard = self.voice_in.listen_once(config.ACTIVE_LISTEN_TIMEOUT, config.COMMAND_PHRASE_LIMIT)
            if heard:
                self.handle(heard)
            return

        self._set_status("Idle")
        self.window.set_mic("error" if self.voice_in.mic_error else "wake")
        remainder = self.wake.listen()
        if remainder is None:
            return
        self._ui("Wake word heard.", "info")
        if remainder:  # "JARVIS open notepad" in one breath
            self.handle(remainder)
            return
        self.say("Yes, sir?")
        self._set_status("Listening")
        self.window.set_mic("active")
        command = self.voice_in.listen_once(config.COMMAND_TIMEOUT, config.COMMAND_PHRASE_LIMIT)
        if command:
            self.handle(command)
        else:
            self._ui("(no command heard, going back to idle)", "info")

    # -------------------------------------------------------------- handling
    def handle(self, text: str) -> Optional[bool]:
        text = text.strip()
        wake = config.WAKE_WORD_PATTERN.match(text)
        if wake:  # "jarvis open notepad" typed or heard in always-active mode
            text = text[wake.end():].strip(" ,.!?")
        if not text:
            return None
        log.info("COMMAND %s", text)
        self._ui(f"You: {text}", "user")
        self._set_status("Thinking")
        try:
            if STAY_ACTIVE.search(text):
                self._set_mode("active")
                self.say("Staying active, sir. I'm listening without the wake word.")
            elif GO_TO_SLEEP.search(text):
                self._set_mode("wake")
                self.say("Going to sleep, sir. Say my name to wake me.")
            else:
                self.router.process(text)
        except Exception:
            log.exception("Command failed: %s", text)
            self._ui("Something went wrong. Details are in logs/jarvis.log.", "error")
            self.say("Sorry sir, something went wrong with that command.")
        finally:
            self._set_status("Idle" if self.mode == "wake" else "Listening")
        return True

    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        self.window.set_mode(mode)
        log.info("MODE %s", mode)


def main() -> None:
    log.info("JARVIS starting")
    window = AppWindow()
    assistant = Assistant(window)
    window.set_submit_callback(assistant.submit_text)

    def on_close() -> None:
        assistant.stop()
        window.destroy()

    window.protocol("WM_DELETE_WINDOW", on_close)
    assistant.start()
    window.mainloop()
    log.info("JARVIS stopped")


if __name__ == "__main__":
    main()
