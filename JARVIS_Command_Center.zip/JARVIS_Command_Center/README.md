# JARVIS: voice-controlled desktop assistant for Windows

JARVIS listens for the wake word **"JARVIS"**, runs local tools (open apps, type text, volume, screenshots ...)
without any AI call, answers questions with Groq, and can plan multi-step jobs when you say **"AI ..."**.
It can also describe its own code and write new tools for itself, safely, in a separate version folder.

## 1. Install

Requirements: Windows 10/11, Python 3.10 or newer, a microphone.

```bat
cd jarvis
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Microphone input uses `sounddevice`, which installs as a ready-made wheel on every Python version, including 3.14.
No C++ build tools are needed (JARVIS does not use PyAudio).

## 2. Get a Groq API key

1. Go to https://console.groq.com and sign in (free).
2. Open **API Keys** and click **Create API Key**. Copy the key (it starts with `gsk_`).
3. Copy `.env.example` to `.env` and paste your key(s). **Key rotation:** you can use up to 10 keys
   (for example from 10 free Groq accounts):

```
GROQ_API_KEY_1=gsk_first_key
GROQ_API_KEY_2=gsk_second_key
GROQ_API_KEY_3=gsk_third_key
GROQ_API_KEY_4=gsk_fourth_key
GROQ_API_KEY_5=gsk_fifth_key
GROQ_API_KEY_6=gsk_sixth_key
GROQ_API_KEY_7=gsk_seventh_key
GROQ_API_KEY_8=gsk_eighth_key
GROQ_API_KEY_9=gsk_ninth_key
GROQ_API_KEY_10=gsk_tenth_key
```

How rotation works: every request starts on the next key (round-robin) so load is spread evenly. If Groq answers
"rate limit" for a key, that key rests for 60 seconds (or the time Groq asks for) and JARVIS instantly retries
the same request on the next key. If a key is rejected as invalid, it is disabled for the session. JARVIS only
says it is rate limited when all keys are resting at once. Logs mention keys by slot number only ("Key #3").
A comma separated `GROQ_API_KEYS=a,b,c` line or a single `GROQ_API_KEY` also works.

Keys are only read from `.env`. JARVIS never prints, speaks or logs it, and log lines are scrubbed for
anything that looks like a key. Never share or commit `.env`.

Model names are in `config.py` (`FAST_MODEL` for questions, `STRONG_MODEL` for code, plans and new tools) and can
be overridden in `.env` with `JARVIS_FAST_MODEL` and `JARVIS_STRONG_MODEL`.
The default models are `openai/gpt-oss-20b` and `openai/gpt-oss-120b`; the previous Llama models were retired
by Groq on August 16, 2026.

System prompts are the `ASK_SYSTEM`, `CODE_SYSTEM`, `TEXT_SYSTEM`, `PLAN_SYSTEM`, and `TOOL_SYSTEM` constants
near the top of `core/llm.py`. `ASK_SYSTEM` defines JARVIS's conversational identity and behavior (including
the assistant name JARVIS and user name Sarthak); edit it to personalize regular AI answers. Edit the other
prompts to change code generation, text generation, planning, or new-tool generation.

## 3. Run

```bat
python main.py
```

A holographic HUD opens: a glowing orb that changes colour and speed with the status (Idle / Listening / Thinking /
Speaking), a voice bar with a live waveform and mic indicator, live CPU / RAM / disk / network gauges, the activity
log, quick-action buttons and a text box. For the closest look to the design, install the free Orbitron (titles) and
Rajdhani (text) fonts; without them JARVIS falls back to Bahnschrift or Segoe UI automatically. The GUI uses plain
Tk and Pillow, so `customtkinter` is no longer required by it. Say **"JARVIS"**, wait for "Yes, sir?", then say a command. You can also say it in one breath
("JARVIS open notepad") or type any command in the text box (useful if the microphone is unavailable).

Notes:
- Speech recognition uses Google's free web service, so it needs internet. While idle, short audio snippets are
  sent to that service to check for the wake word. For a fully offline wake word, install Vosk (below).
- Offline wake word (optional): `pip install vosk`, download a small English model from
  https://alphacephei.com/vosk/models, unzip it to `models/vosk-model-small-en-us-0.15` (or set `VOSK_MODEL_PATH`
  in `.env`). JARVIS then detects the wake word offline and also falls back to Vosk if the internet is down.

## 4. Example voice commands

| You say | What happens |
|---|---|
| "open notepad", "launch chrome", "open youtube" | `open_app` (local, no AI) |
| "close notepad" | `close_app`, asks for confirmation first |
| "type hello world" | `type_text` types into the active window |
| "search for best pizza near me", "search youtube for lo-fi music" | `web_search` |
| "what time is it", "what's the date" | `time_date` |
| "volume up", "volume down", "set volume to 40", "mute" | `volume` |
| "take a screenshot" | `screenshot` (saved in Pictures/JARVIS_Screenshots) |
| "system status", "how much battery is left" | `system_info` |
| "create a file called notes.txt with buy milk", "list files", "delete file notes.txt" | `file_ops` (deleting asks first) |
| "shut down the computer", "restart", "lock the screen" | `power` (shutdown and restart ask first) |
| "what is the capital of France", "explain recursion" | question, answered by Groq |
| "AI and open notepad and write python code for a calculator" | Groq plans the steps, JARVIS runs them |
| "what tools do you have?", "show me your router code" | self-awareness, shown in the log |
| "stay active" / "go to sleep" | always listening / back to wake-word mode |
| anything unknown | "I don't have a tool for that yet. Should I create one?" |

## 5. How the router decides

1. **"AI ..."**: Groq returns a JSON plan (tools plus any generated text or code) and JARVIS runs each step.
   This is checked first, because "AI and open notepad ..." also contains a local trigger phrase. The older
   **"use AI ..."** form is still accepted for compatibility.
2. **Local command**: if the command matches a tool's trigger phrases (or is a question about JARVIS itself),
   the tool runs directly. No LLM call.
3. **Question** (what, why, how, who, explain, tell me ...): Groq answers and JARVIS speaks it. This is the only
   default LLM use. Long answers and code go to the GUI log, with a short spoken summary.
4. **No tool found**: JARVIS offers to create one.

## 6. Adding tools by hand

Copy `tools/_template.py` to `tools/my_tool.py` and set `TOOL_NAME`, `TOOL_DESCRIPTION`, `TRIGGER_PHRASES` and
`run(args)`. Files starting with `_` are ignored; everything else in `tools/` is loaded automatically at startup.
Optional: `TOOL_ARGS` (helps the AI planner) and `needs_confirmation(args)` (return a yes/no question for risky actions).

## 7. Self-update process (safe by design)

JARVIS never edits the folder it is running from.

1. You say something JARVIS has no tool for, and answer **yes** to "Should I create one?".
2. Groq writes a tool that follows `tools/_template.py`. The code is **shown in the log and written to
   `logs/jarvis.log` before anything is saved**.
3. The code is validated: `ast.parse`, required names present, forbidden calls rejected (`eval`, `exec`,
   `__import__`, file deletion calls), then a dry run (`run({"dry_run": True})`) with a timeout.
   If it fails, JARVIS retries once, then gives up and tells you.
4. JARVIS asks you to confirm saving. On yes, it copies the whole project to `versions/jarvis_v<N>` (next number),
   puts the new tool there, and writes `CHANGELOG.txt`. Then it says:
   *"Update is ready in jarvis_v2. Replace the source folder when you are ready, sir."*
5. You replace the old source folder yourself, and copy your `.env` into the new folder (it is deliberately
   not copied). Old versions are never deleted.

Self-update is meant for running from source. A built `.exe` can create versions of its bundled files, but you
will normally maintain the source folder and rebuild.

## 8. Build an .exe (PyInstaller)

```bat
venv\Scripts\activate
pip install pyinstaller
pyinstaller --noconfirm --onedir --windowed --name JARVIS ^
  --collect-all customtkinter --collect-all speech_recognition ^
  --add-data "tools;tools" ^
  --hidden-import pyttsx3.drivers --hidden-import pyttsx3.drivers.sapi5 ^
  --hidden-import pyautogui --hidden-import pygetwindow --hidden-import pyperclip ^
  --hidden-import psutil --hidden-import comtypes --hidden-import pycaw.pycaw ^
  main.py
```

The result is `dist\JARVIS\JARVIS.exe`. Tools are bundled as plain files and imported at runtime, which is why
`--add-data "tools;tools"` and the `--hidden-import` lines are needed. Put your `.env` file **next to
`JARVIS.exe`**; logs and versions are also created there. If you installed Vosk, add `--collect-all vosk`.
If a tool is missing in the exe, check `logs\jarvis.log` for an import error and add the missing module with
`--hidden-import`.

## 9. Safety summary

- Voice confirmation before deleting files, shutting down or restarting, and closing apps.
  Closing uses a normal close request (no force kill), so apps can ask to save.
- The API key is never printed, spoken or logged.
- Generated tool code is always shown and logged before it is saved.
- Every command, action and result is logged to `logs/jarvis.log`.
- `type_text` types into whichever window is active, so click the target window first if you use it by hand.

## 10. Troubleshooting

- **"I can't access the microphone"**: check Windows Settings > Privacy > Microphone, and that `pip install sounddevice` succeeded.
- **No spoken replies**: make sure a Windows SAPI5 voice exists (Settings > Time & Language > Speech).
- **"I can't reach the speech service"**: no internet; install Vosk for offline fallback.
- **Rate limit message**: Groq's free tier has per-minute limits. Wait a minute or change the model in `config.py`.
- Everything JARVIS does is in `logs/jarvis.log`.

## Project layout

```
main.py  config.py  requirements.txt  .env.example  README.md
core/   wake_word, voice_input, voice_output, router, llm, tool_registry, self_manager
tools/  open_app, close_app, type_text, web_search, system_info, volume, screenshot,
        file_ops, time_date, power, _template
gui/    app_window
versions/  new versions are created here        logs/  jarvis.log
```

---
## Command Center (desktop app)

First run: copy `.env.example` to `.env` and add your Groq keys (10 slots), then double-click `run_command_center.bat`.
Installs once, then opens the JARVIS desktop window (Edge WebView2, not a browser tab; works offline). `JARVIS_no_console.vbs` starts it without a console.
`python main.py` still starts the classic Tk GUI. `build_exe.bat` makes `dist\JARVIS\JARVIS.exe`.

### What JARVIS understands now (gui/brain.py - core/ is untouched)
Speech: commands are transcribed with Groq Whisper (your existing keys), with Google as automatic fallback. Say "Jarvis ..." or tap the mic.
Examples: "play lo-fi on YouTube" (opens the top result in Chrome and plays it), "open YouTube and search for python tutorials",
"search for best laptops", "open ChatGPT / Claude / GitHub / Instagram ...", "open TLauncher" (finds Start Menu/Desktop shortcuts),
"remember that my locker code is 4821" (stored in Memory, used in answers), "what do you remember".
Natural phrasing works: "can you please play ... for me", and mishearings like "you tube", "chat gpt", "crome" are corrected.
Anything it cannot match goes to your AI planner (it uses your tools) instead of asking to create a new tool.

### Voice routines (Voice Routines page)
Phrases are what you say AFTER the wake word ("start jarvis gaming" triggers `gaming`). Steps: open, close all windows (asks first),
wait, click position (RECORD POSITION), click a button image, press keys, type text, say. Edit/add as many as you like.
For `gaming`: set the click step (record the position of the launcher's Enter button) after you have opened the launcher once.

### Pages (all real, no placeholder data)
Command Center, AI Core, Modules (real tools: run counts, last used, on/off that really blocks them), Tasks, Calendar
(reminders appear when due), Memory, Conversations, Knowledge Base, Workflows, Voice Routines, Settings. Ctrl+K palette, bell, fullscreen.
Your data is in `data/store.json`.

## v4.0: Command Center redesign

**New UI** (`gui/web/ui.css`, `ui.js`, `earth.js`, `dash.js`, `pages.js`): design tokens (semantic colours, 4-pt spacing, type scale, motion), three panel tiers (hero / standard / ambient), accent picker (cyan, Stark gold, crimson, emerald), UI scale 80-130%, high-contrast mode, Performance mode (auto below 40 fps), focus rings and ARIA labels, grouped navigation with Ctrl+1..9, Ctrl+K palette, Ctrl+B sidebar, layout presets (Command / Focus / Monitor, icon rail below 1400 px), collapsible panels, persistent actionable banners (offline, no key, mic error), stacked toasts with Undo.

**Holographic Earth**: continents come from Natural Earth (`gui/web/earth/land.png`, 2048x1024 mask rasterised offline), about 15.9k points in one draw call, coastline glow, Fresnel atmosphere tinted by JARVIS state, real sub-solar point from UTC (night side dims and shows city lights), drifting clouds, pin at your longitude (from time-zone offset), great-circle arcs when tools run, drag with inertia, wheel zoom, double-click to recentre, hover lat/lon. Say or type "show me Tokyo / India / Brazil" (city table in `gui/brain.py`).

**Voice flow**: live caption strip (Listening, Transcribing, Heard), intent chip, and an Action Trace per command (Heard, Understood, Executed with duration, Result, Retry on failure). Whisper is batch speech-to-text, so the caption shows the transcript once the phrase ends, not word by word.

**Other**: conversation panel (timestamps, markdown, highlighted code with Copy, copy / run again / pin to memory, search, Up/Down history, suggestions), System events separated from dialogue, monitor sparklines, per-core bars, real End task (confirmed, protected names refused), Tasks board, month Calendar, Settings (appearance, sound, mic level meter, API key health, export / import), custom frameless title bar (set `JARVIS_FRAMED=1` in `.env` for the native one).
New Python dependency: `numpy` (mic level meter).

**Added in the second pass**: Workflows as step cards (drag-reorder, test a step, enable/disable, import/export JSON), draggable Routine steps, Memory cards with #tags and search, module usage charts, opt-in widgets (weather via open-meteo, world clocks, quick notes), Windows desktop integration in `gui/desktop.py` (global Ctrl+Space summon, tray icon with `pip install pystray`, start with Windows; all guarded and untested outside Windows).

**Added in the third pass**: orb mode, Calendar drag-to-create, clipboard-history and now-playing widgets (now-playing needs the optional `winrt` packages), optional GPU/VRAM/temperature readout (`nvidia-ml-py`), Memory graph view, Settings for speech engine (Whisper/Google), listening sensitivity, TTS voice and speed with a test button, and an input device that is used for recognition too.

**New voice commands**: "remind me in 20 minutes to ...", "remind me at 5 pm to ...", "summarize clipboard", "translate clipboard to French", "what is on my screen" (vision model; set `JARVIS_VISION_MODEL` in `.env` if the default is unavailable), "daily briefing", "do that again". The `tools/` folder is the plugin folder: drop a tool file in and enable it on the Modules page.

**Hardware-dependent parts** (written and guarded, not run on Windows during development): microphone, TTS voices, tray, Ctrl+Space, start with Windows, orb mode window resize, GPU, clipboard, now-playing, screen description.
