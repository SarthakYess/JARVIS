"""Start JARVIS with the Command Center HUD. main.py and the backend stay untouched."""
import logging

from main import Assistant  # importing main also configures logging/dirs
from gui.brain import Brain
from gui.routines import RoutineEngine
from gui.web_window import WebWindow

log = logging.getLogger("jarvis.main")


def run() -> None:
    log.info("JARVIS starting (web HUD)")
    window = WebWindow()
    assistant = Assistant(window)          # Assistant only needs the AppWindow-style methods
    window.assistant = assistant

    # Brain: voice routines -> natural-language rules -> original router (core/ is not modified).
    engine = RoutineEngine(assistant, window.store, window)
    Brain(assistant, window, engine).install()
    window.set_submit_callback(assistant.submit_text)
    window.protocol("WM_DELETE_WINDOW", lambda: (assistant.stop(), window.destroy()))
    assistant.start()
    window.mainloop()
    log.info("JARVIS stopped")


if __name__ == "__main__":
    run()
