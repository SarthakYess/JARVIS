"""Always-on listener for the wake word "JARVIS" (call listen() repeatedly from the voice loop)."""
import logging
from typing import Optional

import config
from core.voice_input import VoiceInput

log = logging.getLogger("jarvis.wake")


class WakeWordListener:
    def __init__(self, voice: VoiceInput) -> None:
        self.voice = voice

    def listen(self) -> Optional[str]:
        """Listen for one short phrase.

        Returns None when the wake word was not heard. Returns the text spoken after the
        wake word when it was heard ("" if the user only said "JARVIS").
        """
        audio = self.voice.capture(config.WAKE_LISTEN_TIMEOUT, config.WAKE_PHRASE_LIMIT)
        if audio is None:
            return None
        # With a Vosk model installed the idle listening stays fully offline.
        text = self.voice.transcribe(audio, prefer_offline=self.voice.vosk_ready)
        if not text:
            return None
        match = config.WAKE_WORD_PATTERN.search(text)
        if not match:
            return None
        log.info("Wake word detected.")
        return text[match.end():].strip(" ,.!?")
