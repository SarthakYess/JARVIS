"""Text to speech using pyttsx3 (offline). Spoken text is always plain, with no markdown."""
import logging
import re
import threading

import config

log = logging.getLogger("jarvis.voice_out")
_thread_state = threading.local()


def clean_for_speech(text: str) -> str:
    """Strip markdown, code blocks and URLs so the voice only reads natural text."""
    text = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"https?://\S+", "a link", text)
    text = re.sub(r"^\s*(?:[-*\u2022]|\d+\.)\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"[*_#>~|]+", "", text)
    return re.sub(r"\s+", " ", text).strip()


def _ensure_com() -> None:
    """SAPI5 needs COM initialised once per thread on Windows."""
    if getattr(_thread_state, "com_ready", False):
        return
    try:
        import comtypes  # type: ignore

        comtypes.CoInitialize()
    except Exception:
        pass
    _thread_state.com_ready = True


class VoiceOutput:
    def __init__(self) -> None:
        self._lock = threading.Lock()

    def speak(self, text: str) -> bool:
        """Speak text and block until finished. Returns False if speech failed."""
        spoken = clean_for_speech(text)
        if not spoken:
            return True
        with self._lock:
            try:
                import pyttsx3

                _ensure_com()
                # A fresh engine per call avoids the Windows "runAndWait hangs on 2nd call" bug.
                engine = pyttsx3.init()
                engine.setProperty("rate", config.SPEECH_RATE)
                engine.setProperty("volume", config.SPEECH_VOLUME)
                for voice in engine.getProperty("voices") or []:
                    if "david" in (voice.name or "").lower():
                        engine.setProperty("voice", voice.id)
                        break
                engine.say(spoken)
                engine.runAndWait()
                try:
                    engine.stop()
                except Exception:
                    pass
                return True
            except Exception as exc:
                log.error("Text to speech failed: %s", exc)
                self.beep()
                return False

    def beep(self) -> None:
        """Short beep, used as a fallback when speech is unavailable."""
        try:
            import winsound

            winsound.Beep(880, 150)
        except Exception:
            pass
