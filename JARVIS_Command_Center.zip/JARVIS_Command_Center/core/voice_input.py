"""Speech to text. Uses speech_recognition (Google) and falls back to Vosk when a model is installed."""
import json
import logging
import math
import time
from array import array
from collections import deque
from typing import Callable, Optional

import speech_recognition as sr

import config

log = logging.getLogger("jarvis.voice_in")

SAMPLE_RATE = 16000
BLOCK_FRAMES = 1600            # 0.1 second per block
BLOCK_SECONDS = BLOCK_FRAMES / SAMPLE_RATE
MIN_THRESHOLD = 350            # minimum loudness (RMS) that counts as speech
END_SILENCE_SECONDS = 0.8      # silence that ends a phrase


def _rms(data: bytes) -> float:
    samples = array("h")
    samples.frombytes(data[: len(data) - (len(data) % 2)])
    if not samples:
        return 0.0
    return math.sqrt(sum(x * x for x in samples) / len(samples))


class VoiceInput:
    def __init__(self, on_error: Optional[Callable[[str], None]] = None) -> None:
        self.recognizer = sr.Recognizer()
        self.on_error = on_error
        self.mic_error = False
        self.vosk_ready = False
        self._vosk_model = None
        self._threshold = None
        self._ambient = 0.0
        self._last_notice: dict = {}
        self._load_vosk()

    # ------------------------------------------------------------------ setup
    def _load_vosk(self) -> None:
        if not config.VOSK_MODEL_PATH.exists():
            return
        try:
            from vosk import Model, SetLogLevel  # type: ignore

            SetLogLevel(-1)
            self._vosk_model = Model(str(config.VOSK_MODEL_PATH))
            self.vosk_ready = True
            log.info("Vosk offline model loaded.")
        except Exception as exc:
            log.warning("Vosk model could not be loaded: %s", exc)

    def _notify(self, key: str, message: str, interval: float = 60.0) -> None:
        """Tell the user about a problem, but not more often than once per interval."""
        now = time.time()
        if self.on_error and now - self._last_notice.get(key, 0.0) > interval:
            self._last_notice[key] = now
            try:
                self.on_error(message)
            except Exception:
                pass

    # -------------------------------------------------------------- listening
    def capture(self, timeout: float, phrase_limit: float):
        """Record one phrase with sounddevice (no PyAudio needed).

        Waits up to `timeout` seconds for speech to start, then records until about
        0.8 s of silence or `phrase_limit` seconds. Returns AudioData, or None on
        silence or microphone trouble.
        """
        try:
            import sounddevice as sd

            with sd.RawInputStream(samplerate=SAMPLE_RATE, channels=1, dtype="int16",
                                   blocksize=BLOCK_FRAMES) as stream:
                if self._threshold is None:
                    levels = [_rms(bytes(stream.read(BLOCK_FRAMES)[0])) for _ in range(5)]
                    self._ambient = sum(levels) / len(levels)
                    self._threshold = max(MIN_THRESHOLD, self._ambient * 3)
                preroll: deque = deque(maxlen=3)  # keeps the start of the first word
                waited = 0.0
                frames = None
                while frames is None:
                    data = bytes(stream.read(BLOCK_FRAMES)[0])
                    level = _rms(data)
                    if level > self._threshold:
                        frames = list(preroll) + [data]
                    else:
                        preroll.append(data)
                        self._ambient = 0.95 * self._ambient + 0.05 * level  # adapt to room noise
                        self._threshold = max(MIN_THRESHOLD, self._ambient * 3)
                        waited += BLOCK_SECONDS
                        if waited >= timeout:
                            self.mic_error = False
                            return None
                recorded, quiet = 0.0, 0.0
                while recorded < phrase_limit and quiet < END_SILENCE_SECONDS:
                    data = bytes(stream.read(BLOCK_FRAMES)[0])
                    frames.append(data)
                    recorded += BLOCK_SECONDS
                    quiet = quiet + BLOCK_SECONDS if _rms(data) < self._threshold else 0.0
            self.mic_error = False
            if len(frames) < 4:  # a click or cough, not speech
                return None
            return sr.AudioData(b"".join(frames), SAMPLE_RATE, 2)
        except Exception as exc:  # no mic, device busy, sounddevice missing ...
            self.mic_error = True
            log.error("Microphone problem: %s", exc)
            self._notify("mic", "I can't access the microphone, sir. You can still type commands.", 120)
            time.sleep(1.0)
            return None

    def transcribe(self, audio, prefer_offline: bool = False) -> str:
        """Convert AudioData to text. Returns an empty string if nothing was understood."""
        if prefer_offline and self.vosk_ready:
            return self._transcribe_vosk(audio)
        try:
            return self.recognizer.recognize_google(audio, language=config.SPEECH_LANGUAGE).strip()
        except sr.UnknownValueError:
            return ""
        except sr.RequestError as exc:
            log.error("Speech service unreachable: %s", exc)
            if self.vosk_ready:
                return self._transcribe_vosk(audio)
            self._notify("net", "I can't reach the speech service. Please check your internet connection, sir.")
            return ""
        except Exception as exc:
            log.error("Transcription failed: %s", exc)
            return ""

    def _transcribe_vosk(self, audio) -> str:
        try:
            from vosk import KaldiRecognizer  # type: ignore

            recognizer = KaldiRecognizer(self._vosk_model, 16000)
            recognizer.AcceptWaveform(audio.get_raw_data(convert_rate=16000, convert_width=2))
            return json.loads(recognizer.FinalResult()).get("text", "").strip()
        except Exception as exc:
            log.error("Vosk transcription failed: %s", exc)
            return ""

    def listen_once(self, timeout: float = config.COMMAND_TIMEOUT,
                    phrase_limit: float = config.COMMAND_PHRASE_LIMIT) -> str:
        """Record and transcribe one phrase. Returns '' on silence or failure."""
        audio = self.capture(timeout, phrase_limit)
        if audio is None:
            return ""
        return self.transcribe(audio)
