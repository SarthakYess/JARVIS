"""Decides what to do with a command. The LLM is NOT used for every task.

Order:
  0. "AI ..."      explicit request: Groq returns a JSON plan, the router runs it with tools.
                   (Checked first because "AI and open notepad ..." also contains a tool phrase.)
  1. LOCAL COMMAND a tool (or a question about JARVIS itself) matches: run it, no LLM call.
  2. QUESTION      what / why / how / who / explain / tell me ...: ask Groq and speak the answer.
  3. NO TOOL FOUND offer to create a new tool through self_manager.
"""
import json
import logging
import re
from typing import Tuple

import config
from core import tool_registry
from core.llm import LLM, LLMError
from core.self_manager import SelfManager

log = logging.getLogger("jarvis.router")

QUESTION_START = re.compile(
    r"^(?:what|what's|whats|why|how|who|who's|whom|whose|when|where|which|explain|tell me|describe|define|"
    r"is|are|was|were|does|can|could|should|would|will)\b",
    re.IGNORECASE,
)
AI_COMMAND = re.compile(
    r"^\s*(?:(?:use|using)\s+)?(?:the\s+)?(?:a\.?\s?i\.?|artificial intelligence)(?![a-z])[\s,:;.\-]*"
    r"(?:(?:and|to)\s+)?(.*)$",
    re.IGNORECASE | re.DOTALL,
)
PLACEHOLDER = "{{last_output}}"


def spoken_summary(text: str) -> str:
    """Short, markdown-free text that is safe to speak for a long answer."""
    head = text.split("```", 1)[0]
    head = re.sub(r"[*_#>`~|]+", "", head)
    head = re.sub(r"\s+", " ", head).strip()
    sentences = re.split(r"(?<=[.!?])\s+", head)
    summary = " ".join(sentences[:2]).strip()
    if len(summary) > config.MAX_SPOKEN_CHARS:
        summary = summary[:config.MAX_SPOKEN_CHARS].rsplit(" ", 1)[0] + "..."
    return summary


class Router:
    def __init__(self, io, llm: LLM, self_manager: SelfManager) -> None:
        self.io = io              # needs: say(text), show(text), confirm(prompt) -> bool
        self.llm = llm
        self.self_manager = self_manager

    # ---------------------------------------------------------------- entry
    def process(self, command: str) -> None:
        core = tool_registry.clean_command(command)
        if not core:
            return
        log.info("ROUTE command=%r", core)

        match = AI_COMMAND.match(core)
        if match:
            self._use_ai(match.group(1).strip())
            return

        meta = self.self_manager.answer_meta(core)
        if meta:
            spoken, detail = meta
            if detail:
                self.io.show(detail)
            self.io.say(spoken)
            return

        found = tool_registry.find_tool(core)
        if found:
            name, args = found
            ok, message = self._run_checked(name, args)
            self.deliver(message)
            return

        if core.endswith("?") or QUESTION_START.match(core):
            self._answer(core)
            return

        self._no_tool(core)

    # ---------------------------------------------------------------- pieces
    def deliver(self, text: str) -> None:
        """Speak short text; send long text or code to the log and speak a short summary."""
        text = (text or "").strip()
        if not text:
            return
        if "```" in text or len(text) > config.MAX_SPOKEN_CHARS or text.count("\n") > 2:
            self.io.show(text)
            summary = spoken_summary(text)
            self.io.say((summary + " " if summary else "") + "The full text is in the log, sir.")
        else:
            self.io.say(text)

    def _run_checked(self, name: str, args: dict) -> Tuple[bool, str]:
        """Run a tool, asking for voice confirmation first when the tool requires it."""
        question = tool_registry.needs_confirmation(name, args)
        if question and not self.io.confirm(question):
            log.info("ACTION cancelled by user: %s", name)
            return False, "Cancelled, sir."
        try:
            return True, tool_registry.run_tool(name, args)
        except Exception as exc:
            log.exception("Tool %s failed", name)
            return False, f"The {name.replace('_', ' ')} tool failed: {type(exc).__name__}."

    def _answer(self, question: str) -> None:
        try:
            answer = self.llm.ask(question)
        except LLMError as exc:
            self.io.say(str(exc))
            return
        self.deliver(answer or "I don't have an answer for that, sir.")

    def _no_tool(self, command: str) -> None:
        if self.io.confirm("I don't have a tool for that yet. Should I create one?"):
            self.io.say("Working on it, sir.")
            self.deliver(self.self_manager.create_tool(command))
            self.self_manager.refresh_index()
        else:
            self.io.say("Understood, sir.")

    # ------------------------------------------------------------------- AI
    def _use_ai(self, task: str) -> None:
        if not task:
            self.io.say("What would you like me to do, sir?")
            return
        try:
            plan = self.llm.plan(task, tool_registry.catalog())
        except LLMError as exc:
            self.io.say(str(exc))
            return
        steps = plan["steps"]
        self.io.show("Plan:\n" + "\n".join(
            f"{i}. {s['tool']} {json.dumps(s['args'], ensure_ascii=False)[:150]}" for i, s in enumerate(steps, 1)))
        log.info("PLAN %s", json.dumps(plan, ensure_ascii=False)[:1000])

        last_output = ""
        spoke_last = False
        for index, step in enumerate(steps, 1):
            tool = step["tool"]
            args = self._fill(step["args"], last_output)
            spoke_last = False
            if tool == "llm_generate":
                try:
                    generate_text = str(args.get("kind", "code")).lower() == "text"
                    task_text = str(args.get("task") or task)
                    last_output = self.llm.generate_text(task_text) if generate_text else self.llm.generate_code(task_text)
                except LLMError as exc:
                    self.io.say(str(exc))
                    return
                self.io.show(f"Generated content (step {index}):\n{last_output}")
            elif tool == "say":
                self.io.say(str(args.get("text", "")))
                spoke_last = True
            else:
                if tool == "type_text" and not str(args.get("text", "")).strip():
                    args["text"] = last_output
                ok, message = self._run_checked(tool, args)
                self.io.show(f"[{tool}] {message}")
                if not ok:
                    self.io.say(message)
                    return
        if not spoke_last:
            self.io.say(f"Done, {config.USER_TITLE}.")

    def _fill(self, value, last_output: str):
        """Replace the {{last_output}} placeholder inside step arguments."""
        if isinstance(value, str):
            return value.replace(PLACEHOLDER, last_output)
        if isinstance(value, dict):
            return {k: self._fill(v, last_output) for k, v in value.items()}
        if isinstance(value, list):
            return [self._fill(v, last_output) for v in value]
        return value
