"""Groq client wrapper: short answers, code generation, JSON tool plans and new-tool generation."""
import json
import logging
import re
import threading
import time
from collections import deque
from typing import Dict, List, Optional

import config

log = logging.getLogger("jarvis.llm")

PSEUDO_TOOLS = {
    "llm_generate": 'Generate text or code with the AI. Args: {"task": "what to write", "kind": "code" or "text"}. '
                    'The result can be used in later steps as the string "{{last_output}}".',
    "say": 'Speak a short sentence to the user. Args: {"text": "sentence"}.',
}

ASK_SYSTEM = (
    "You are JARVIS, Sarthak's personal assistant. The user's name is Sarthak, and he is your boss. "
    "Refer to yourself as JARVIS and address the user as Sarthak. Be respectful, helpful, concise, and honest; "
    "say when you are unsure, and never claim an action succeeded unless it did. "
    "Answer in one to three short plain sentences. No markdown, no lists, no emojis. "
    "Only if code is truly required, give a one sentence summary and then a fenced code block."
    "Your behaviour is like you know everything you notice every thing you have permission all things but you are still my assistant and I am your boss"
    "Your behaviour is: a blend of hyper-advanced machine logic, dry British wit, and an deeply human sense of loyalty and empathy."
)
CODE_SYSTEM = (
    "You are an expert programmer. Return ONLY the requested code inside a single fenced code block. "
    "No explanations before or after the block. The code must be complete and runnable."
)
TEXT_SYSTEM = "You write clear, useful text. Return only the requested text, with no preamble."
PLAN_SYSTEM = """You are the planner of a Windows desktop voice assistant. Turn the user's request into a plan.
Return ONLY a JSON object, with no commentary, in exactly this shape:
{"steps": [{"tool": "<tool name>", "args": {...}}, ...]}

Available tools:
%s

Rules:
- Use only the tools listed above and give every step an "args" object (it may be empty).
- When the request needs generated content (code, an essay, a poem), add a step with the tool "llm_generate"
  BEFORE the step that uses it, then use the string "{{last_output}}" as the argument value, for example
  {"tool": "type_text", "args": {"text": "{{last_output}}"}}.
- Do not write long content directly inside the JSON; use llm_generate for that.
- Keep the plan as short as possible. Do not add a final "say" step unless it is useful.

Example request: open notepad and write python code for a calculator
Example answer:
{"steps": [{"tool": "open_app", "args": {"name": "notepad"}},
           {"tool": "llm_generate", "args": {"task": "python code for a simple calculator", "kind": "code"}},
           {"tool": "type_text", "args": {"text": "{{last_output}}"}}]}"""
TOOL_SYSTEM = """You write a new tool module for a Python voice assistant running on Windows.
Follow this template exactly (module level constants and a run function):

%s

Rules:
- TOOL_NAME is lowercase snake_case and unique. TRIGGER_PHRASES holds 2 to 6 lowercase phrases that clearly
  identify the tool; avoid single generic words.
- args["command"] holds the full spoken command and args["text"] holds what follows the trigger phrase.
- run() must begin with: if args.get("dry_run"): return "dry run ok"
- run() returns a short plain-text result string and never raises for normal problems.
- Import third-party or heavy modules INSIDE run(), not at the top of the file.
- Use only the standard library plus: pyautogui, psutil, pyperclip, pygetwindow.
- Never delete files or folders. Never use eval, exec or __import__.
- Return ONLY the complete Python file inside one fenced code block, with no explanation."""


class LLMError(Exception):
    """Raised with a short, speakable message when the LLM cannot be used."""


def _scrub(text: str) -> str:
    for key in config.GROQ_API_KEYS:
        text = text.replace(key, "[REDACTED]")
    return re.sub(r"gsk_[A-Za-z0-9]{10,}", "[REDACTED]", text)


def extract_code(text: str) -> str:
    """Return the code from a fenced block, or the raw text if there is no fence."""
    blocks = re.findall(r"```[a-zA-Z0-9_+-]*[ \t]*\n(.*?)```", text, flags=re.DOTALL)
    if blocks:
        return max(blocks, key=len).strip("\n")
    return text.strip()


def extract_json(text: str) -> dict:
    """Parse a JSON object from a model reply, tolerating code fences and stray text."""
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end <= start:
        raise ValueError("no JSON object found")
    return json.loads(text[start:end + 1])


def validate_plan(plan: object, allowed: set) -> dict:
    """Return the plan if it is valid, otherwise raise ValueError with the reason."""
    if not isinstance(plan, dict) or not isinstance(plan.get("steps"), list):
        raise ValueError('top level must be an object with a "steps" list')
    if not plan["steps"]:
        raise ValueError("the plan has no steps")
    if len(plan["steps"]) > 15:
        raise ValueError("the plan has too many steps")
    for index, step in enumerate(plan["steps"], 1):
        if not isinstance(step, dict):
            raise ValueError(f"step {index} is not an object")
        if not isinstance(step.get("tool"), str) or step["tool"] not in allowed:
            raise ValueError(f'step {index} uses unknown tool "{step.get("tool")}"')
        if step.get("args") is None:
            step["args"] = {}
        if not isinstance(step["args"], dict):
            raise ValueError(f'step {index} "args" must be an object')
    return plan


class KeyPool:
    """Round-robin pool of API keys. Only slot numbers (1..10) are ever logged, never key values."""

    def __init__(self, keys: List[str]) -> None:
        self.keys = list(keys)
        self._next = 0
        self._cooldown: Dict[int, float] = {}
        self._dead: set = set()
        self._clients: Dict[int, object] = {}
        self._lock = threading.Lock()

    def acquire(self) -> Optional[int]:
        """Index of the next usable key (not cooling down, not rejected), or None."""
        with self._lock:
            now = time.time()
            for offset in range(len(self.keys)):
                index = (self._next + offset) % len(self.keys)
                if index not in self._dead and self._cooldown.get(index, 0.0) <= now:
                    return index
            return None

    def advance(self, index: int) -> None:
        with self._lock:
            self._next = (index + 1) % len(self.keys)

    def rest(self, index: int, seconds: float) -> None:
        with self._lock:
            self._cooldown[index] = time.time() + seconds

    def disable(self, index: int) -> None:
        with self._lock:
            self._dead.add(index)

    def all_rejected(self) -> bool:
        return len(self._dead) >= len(self.keys)

    def client(self, index: int):
        if index not in self._clients:
            from groq import Groq

            self._clients[index] = Groq(api_key=self.keys[index], timeout=config.LLM_TIMEOUT_SECONDS)
        return self._clients[index]

    def status(self) -> str:
        now = time.time()
        resting = sum(1 for i, t in self._cooldown.items() if t > now and i not in self._dead)
        return f"{len(self.keys)} keys, {resting} resting, {len(self._dead)} rejected"


def _retry_after(exc, default: float) -> float:
    try:
        value = float(exc.response.headers.get("retry-after"))
        return max(5.0, min(value, 300.0))
    except Exception:
        return default


class LLM:
    def __init__(self) -> None:
        self._pool = KeyPool(config.GROQ_API_KEYS)
        self._history: deque = deque(maxlen=6)
        log.info("Groq key pool: %s", self._pool.status())

    # ------------------------------------------------------------- plumbing
    def _chat(self, model: str, messages: List[dict], temperature: float = 0.3,
              max_tokens: int = 1024, json_mode: bool = False) -> str:
        """Call Groq, rotating to the next key on rate limits or rejected keys."""
        pool = self._pool
        if not pool.keys:
            raise LLMError("My Groq API key is missing. Please add it to the dot env file.")
        import groq

        extra = {"response_format": {"type": "json_object"}} if json_mode else {}
        for _ in range(len(pool.keys)):
            index = pool.acquire()
            if index is None:
                break
            try:
                response = pool.client(index).chat.completions.create(
                    model=model, messages=messages, temperature=temperature, max_tokens=max_tokens, **extra)
                pool.advance(index)  # spread load: the next request starts on the next key
                return (response.choices[0].message.content or "").strip()
            except groq.RateLimitError as exc:
                pool.rest(index, _retry_after(exc, config.KEY_COOLDOWN_SECONDS))
                pool.advance(index)
                log.warning("Key #%d is rate limited; rotating to the next key. (%s)", index + 1, pool.status())
            except groq.AuthenticationError:
                pool.disable(index)
                pool.advance(index)
                log.error("Key #%d was rejected by Groq and is disabled. (%s)", index + 1, pool.status())
            except groq.APIConnectionError as exc:  # includes timeouts; another key will not help
                log.warning("Groq connection error: %s", _scrub(str(exc)))
                raise LLMError("I can't reach the internet right now, sir.") from exc
            except groq.APIStatusError as exc:
                log.error("Groq API error %s: %s", exc.status_code, _scrub(str(exc)))
                raise LLMError("The AI service returned an error, sir.") from exc
            except Exception as exc:
                log.error("Unexpected LLM failure: %s", _scrub(str(exc)))
                raise LLMError("Something went wrong while contacting the AI, sir.") from exc
        if pool.all_rejected():
            raise LLMError("Groq rejected all of my API keys. Please check the dot env file.")
        raise LLMError("All of my API keys are rate limited, sir. Please try again in a minute.")

    # ------------------------------------------------------------ public API
    def ask(self, question: str) -> str:
        """Fast model: answer a spoken question briefly."""
        messages = [{"role": "system", "content": ASK_SYSTEM}, *self._history,
                    {"role": "user", "content": question}]
        answer = self._chat(config.FAST_MODEL, messages, temperature=0.4, max_tokens=500)
        self._history.append({"role": "user", "content": question})
        self._history.append({"role": "assistant", "content": answer})
        return answer

    def generate_code(self, task: str) -> str:
        """Strong model: return runnable code (fences removed) for a task."""
        reply = self._chat(config.STRONG_MODEL, [{"role": "system", "content": CODE_SYSTEM},
                                                 {"role": "user", "content": task}],
                           temperature=0.2, max_tokens=3000)
        return extract_code(reply)

    def generate_text(self, task: str) -> str:
        """Strong model: return plain text for a task."""
        return self._chat(config.STRONG_MODEL, [{"role": "system", "content": TEXT_SYSTEM},
                                                {"role": "user", "content": task}],
                          temperature=0.5, max_tokens=2000)

    def plan(self, task: str, catalog: Dict[str, str]) -> dict:
        """Strong model: return a validated {"steps": [...]} plan. Retries once if invalid."""
        full_catalog = {**catalog, **PSEUDO_TOOLS}
        allowed = set(full_catalog)
        tool_lines = "\n".join(f"- {name}: {desc}" for name, desc in full_catalog.items())
        messages = [{"role": "system", "content": PLAN_SYSTEM % tool_lines},
                    {"role": "user", "content": task}]
        last_problem = "unknown"
        for attempt in range(2):
            reply = self._chat(config.STRONG_MODEL, messages, temperature=0.1, max_tokens=1500, json_mode=True)
            try:
                return validate_plan(extract_json(reply), allowed)
            except (ValueError, json.JSONDecodeError) as exc:
                last_problem = str(exc)
                log.warning("Invalid plan on attempt %d: %s", attempt + 1, last_problem)
                messages.append({"role": "assistant", "content": reply})
                messages.append({"role": "user", "content": (
                    f"That plan was invalid ({last_problem}). Return ONLY valid JSON in the required "
                    "shape, using only the listed tools.")})
        raise LLMError("I couldn't work out a valid plan for that, sir.")

    def generate_tool(self, request: str, template_source: str, existing_tools: List[str],
                      feedback: Optional[str] = None) -> str:
        """Strong model: write a new tool file that follows tools/_template.py."""
        user = (f"Write a tool for this request: {request}\n"
                f"Existing tool names (do not reuse): {', '.join(existing_tools)}")
        if feedback:
            user += f"\nYour previous attempt failed validation: {feedback}\nFix these problems."
        reply = self._chat(config.STRONG_MODEL, [{"role": "system", "content": TOOL_SYSTEM % template_source},
                                                 {"role": "user", "content": user}],
                           temperature=0.2, max_tokens=3000)
        return extract_code(reply)
