"""Auto-loads every tool in tools/ and matches spoken commands to tools.

A tool is a module with TOOL_NAME, TOOL_DESCRIPTION, TRIGGER_PHRASES and run(args).
Optional: TOOL_ARGS (text describing args for the AI planner) and
needs_confirmation(args) -> str | None (a question to ask before running).
"""
import importlib
import logging
import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import config

log = logging.getLogger("jarvis.registry")

REQUIRED = ("TOOL_NAME", "TOOL_DESCRIPTION", "TRIGGER_PHRASES", "run")


@dataclass
class Tool:
    name: str
    description: str
    triggers: List[str]
    module: object
    arg_help: str = ""
    patterns: Dict[str, "re.Pattern"] = field(default_factory=dict)


_tools: Dict[str, Tool] = {}

_POLITE = re.compile(
    r"^\s*(?:(?:hey|ok|okay)[\s,]+)?(?:jarvis[\s,]+)?(?:please[\s,]+)?"
    r"(?:(?:can|could|would|will)\s+you[\s,]+(?:please[\s,]+)?)?",
    re.IGNORECASE,
)


def clean_command(text: str) -> str:
    """Remove polite filler ("hey jarvis, can you please ...") but keep the original casing."""
    core = _POLITE.sub("", text or "", count=1).strip()
    core = re.sub(r"[\s,]*\bplease\W*$", "", core, flags=re.IGNORECASE)
    return core.strip()


def _phrase_pattern(phrase: str) -> "re.Pattern":
    words = [re.escape(word) for word in phrase.lower().split()]
    return re.compile(r"(?<![\w'])" + r"[\W_]+".join(words) + r"(?![\w'])", re.IGNORECASE)


def load_tools() -> List[str]:
    """(Re)load every tool module from tools/. Broken tools are logged and skipped."""
    _tools.clear()
    if str(config.BASE_DIR) not in sys.path:
        sys.path.insert(0, str(config.BASE_DIR))
    importlib.invalidate_caches()
    for path in sorted(config.TOOLS_DIR.glob("*.py")):
        if path.stem.startswith("_"):
            continue
        module_name = f"tools.{path.stem}"
        try:
            if module_name in sys.modules:
                module = importlib.reload(sys.modules[module_name])
            else:
                module = importlib.import_module(module_name)
            missing = [attr for attr in REQUIRED if not hasattr(module, attr)]
            if missing:
                log.warning("Tool %s skipped, missing: %s", path.name, ", ".join(missing))
                continue
            triggers = [str(t).lower().strip() for t in module.TRIGGER_PHRASES if str(t).strip()]
            tool = Tool(
                name=str(module.TOOL_NAME),
                description=str(module.TOOL_DESCRIPTION),
                triggers=triggers,
                module=module,
                arg_help=str(getattr(module, "TOOL_ARGS", "")),
                patterns={t: _phrase_pattern(t) for t in triggers},
            )
            if tool.name in _tools:
                log.warning("Duplicate tool name %s; the later file wins.", tool.name)
            _tools[tool.name] = tool
        except Exception as exc:
            log.error("Tool %s failed to load: %s", path.name, exc)
    log.info("Loaded %d tools: %s", len(_tools), ", ".join(_tools))
    return list(_tools)


def list_tools() -> List[Tool]:
    return list(_tools.values())


def catalog() -> Dict[str, str]:
    """Tool name -> description (with argument help), used in the AI planning prompt."""
    return {t.name: f"{t.description} Args: {t.arg_help}" if t.arg_help else t.description
            for t in _tools.values()}


def find_tool(command: str) -> Optional[Tuple[str, dict]]:
    """Match a spoken command to a tool using its trigger phrases.

    A one-word trigger must start the command ("open notepad"). A multi-word trigger may
    appear anywhere ("turn the volume up" contains "volume up"). The longest, earliest match wins.
    Returns (tool_name, args) where args = {"command": ..., "text": <text after the trigger>}.
    """
    core = clean_command(command)
    if not core:
        return None
    best = None
    for tool in _tools.values():
        for phrase, pattern in tool.patterns.items():
            match = pattern.search(core)
            if not match:
                continue
            at_start = match.start() == 0
            if not at_start and " " not in phrase:
                continue
            score = (1 if at_start else 0, len(phrase))
            if best is None or score > best[0]:
                best = (score, tool, match)
    if best is None:
        return None
    _, tool, match = best
    if match.start() == 0:
        remainder = core[match.end():]
    else:
        remainder = f"{core[:match.start()]} {core[match.end():]}"
    remainder = remainder.strip(" ,.:;-")
    return tool.name, {"command": core, "text": remainder}


def needs_confirmation(name: str, args: dict) -> Optional[str]:
    """Return a yes/no question if the tool wants confirmation for these args, else None."""
    tool = _tools.get(name)
    check = getattr(tool.module, "needs_confirmation", None) if tool else None
    if not callable(check):
        return None
    try:
        return check(args)
    except Exception as exc:
        log.error("needs_confirmation failed for %s: %s", name, exc)
        return f"I could not check whether {name} is safe to run. Shall I continue, sir?"


def run_tool(name: str, args: dict) -> str:
    """Run a tool by name and return its result text."""
    tool = _tools.get(name)
    if tool is None:
        raise KeyError(f"Unknown tool: {name}")
    shown = {k: (str(v)[:120] + "...") if len(str(v)) > 120 else v for k, v in (args or {}).items()}
    log.info("ACTION tool=%s args=%s", name, shown)
    result = tool.module.run(args or {})
    result = "" if result is None else str(result)
    log.info("RESULT tool=%s -> %s", name, result[:200])
    return result
