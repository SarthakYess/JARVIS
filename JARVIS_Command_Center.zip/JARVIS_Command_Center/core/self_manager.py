"""Self-awareness and safe self-extension.

- Indexes its own project files and tools.
- Answers "what tools do you have?" and "show me your router code".
- Creates new tools with the LLM, validates them, and saves them ONLY into versions/jarvis_v<N>.
  The running source folder is never modified and old versions are never deleted.
"""
import ast
import importlib.util
import logging
import re
import shutil
import tempfile
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import config
from core import tool_registry
from core.llm import LLM, LLMError

log = logging.getLogger("jarvis.self")

SKIP_DIRS = {"versions", "logs", "__pycache__", ".git", "venv", ".venv", "build", "dist", "models"}
INDEXED_SUFFIXES = {".py", ".md", ".txt", ".example"}
NEVER_READ = {".env"}
MAX_SHOW_BYTES = 120_000
FORBIDDEN_NAMES = {"eval", "exec", "__import__", "compile"}
FORBIDDEN_ATTRS = {"rmtree", "remove", "unlink", "rmdir", "removedirs"}

_VERB_SHOW = re.compile(r"\b(show|read|display|print|tell me)\b", re.IGNORECASE)
_NOUN_CODE = re.compile(r"\b(code|source|script|file)\b", re.IGNORECASE)
_TOOLS_QUESTION = re.compile(
    r"\b(what|which|list|show|tell me)\b.*\b(tools|abilities|capabilities)\b|\bwhat can you do\b|\bwhat do you do\b",
    re.IGNORECASE,
)


class SelfManager:
    def __init__(self, io, llm: LLM) -> None:
        self.io = io
        self.llm = llm
        self.files: List[dict] = []
        self.tools: List[dict] = []
        self.refresh_index()

    # ------------------------------------------------------------ (a) index
    def refresh_index(self) -> None:
        """Scan the project folder and record files and tool metadata (read with ast, nothing is imported)."""
        files: List[dict] = []
        tools: List[dict] = []
        root = config.BASE_DIR
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.name in NEVER_READ:
                continue
            relative = path.relative_to(root)
            if any(part in SKIP_DIRS for part in relative.parts[:-1]) or path.suffix not in INDEXED_SUFFIXES:
                continue
            description = ""
            if path.suffix == ".py":
                try:
                    tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
                    description = (ast.get_docstring(tree) or "").strip().splitlines()[0] if ast.get_docstring(tree) else ""
                    if relative.parts[0] == "tools" and not path.name.startswith("_") and path.name != "__init__.py":
                        info = self._tool_info(tree)
                        if info:
                            info["file"] = relative.as_posix()
                            tools.append(info)
                except SyntaxError:
                    description = "(could not parse)"
            files.append({"path": relative.as_posix(), "description": description})
        self.files, self.tools = files, tools
        log.info("Indexed %d files and %d tools", len(files), len(tools))

    @staticmethod
    def _tool_info(tree: ast.AST) -> Optional[dict]:
        values: Dict[str, object] = {}
        for node in tree.body:  # type: ignore[attr-defined]
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                if node.targets[0].id in ("TOOL_NAME", "TOOL_DESCRIPTION", "TRIGGER_PHRASES"):
                    try:
                        values[node.targets[0].id] = ast.literal_eval(node.value)
                    except Exception:
                        pass
        if "TOOL_NAME" not in values:
            return None
        return {"name": values["TOOL_NAME"], "description": values.get("TOOL_DESCRIPTION", ""),
                "triggers": values.get("TRIGGER_PHRASES", [])}

    def describe_tools(self) -> Tuple[str, str]:
        """Return (spoken sentence, detailed text for the log)."""
        names = [str(t["name"]).replace("_", " ") for t in self.tools]
        detail = "\n".join(f"- {t['name']}: {t['description']}  (say: {', '.join(t['triggers'][:3])})"
                           for t in self.tools)
        if not names:
            return "I don't have any tools loaded, sir.", ""
        return f"I have {len(names)} tools: {', '.join(names)}. The details are in the log.", detail

    def find_file(self, text: str) -> Optional[dict]:
        """Find the indexed file a phrase refers to, e.g. 'router code' -> core/router.py."""
        text = text.lower().replace("_", " ")
        best, best_len = None, 0
        for entry in self.files:
            stem = Path(entry["path"]).stem.lower().replace("_", " ")
            if stem in ("__init__", "init"):
                continue
            if re.search(rf"\b{re.escape(stem)}\b", text) and len(stem) > best_len:
                best, best_len = entry, len(stem)
        return best

    def read_file(self, relative_path: str) -> str:
        """Read an indexed project file. The index never contains .env, so secrets stay unreachable."""
        if relative_path not in {f["path"] for f in self.files}:
            raise FileNotFoundError(relative_path)
        path = config.BASE_DIR / relative_path
        if path.stat().st_size > MAX_SHOW_BYTES:
            return path.read_text(encoding="utf-8", errors="replace")[:MAX_SHOW_BYTES] + "\n... (truncated)"
        return path.read_text(encoding="utf-8", errors="replace")

    def answer_meta(self, command: str) -> Optional[Tuple[str, Optional[str]]]:
        """Handle questions about JARVIS itself. Returns (spoken, log_text) or None if not a self question."""
        if _TOOLS_QUESTION.search(command) and re.search(r"\b(you|your)\b", command, re.IGNORECASE):
            spoken, detail = self.describe_tools()
            return spoken, detail or None
        if _VERB_SHOW.search(command) and _NOUN_CODE.search(command):
            entry = self.find_file(command)
            if entry:
                try:
                    code = self.read_file(entry["path"])
                except OSError:
                    return f"I couldn't read {entry['path']}, sir.", None
                return (f"I've put {entry['path'].replace('/', ' slash ')} in the log, sir.",
                        f"----- {entry['path']} -----\n{code}")
            if re.search(r"\b(your|own)\b", command, re.IGNORECASE):
                listing = "\n".join(f"- {f['path']}: {f['description']}" for f in self.files)
                return "I couldn't tell which file you meant, sir. I've listed my files in the log.", listing
        return None

    # ------------------------------------------------------- (b) new tools
    def validate_tool_code(self, code: str) -> Tuple[bool, str, str]:
        """Return (ok, problems, tool_name). Checks syntax, structure, forbidden calls, then does a dry run."""
        try:
            tree = ast.parse(code)
        except SyntaxError as exc:
            return False, f"Syntax error on line {exc.lineno}: {exc.msg}", ""

        found: Dict[str, object] = {}
        has_run = False
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                try:
                    found[node.targets[0].id] = ast.literal_eval(node.value)
                except Exception:
                    pass
            elif isinstance(node, ast.FunctionDef) and node.name == "run" and node.args.args:
                has_run = True
        problems = []
        if not isinstance(found.get("TOOL_NAME"), str) or not re.fullmatch(r"[a-z][a-z0-9_]*", found.get("TOOL_NAME", "")):
            problems.append("TOOL_NAME must be a lowercase snake_case string")
        if not isinstance(found.get("TOOL_DESCRIPTION"), str) or not found.get("TOOL_DESCRIPTION"):
            problems.append("TOOL_DESCRIPTION must be a non-empty string")
        phrases = found.get("TRIGGER_PHRASES")
        if not isinstance(phrases, list) or not phrases or not all(isinstance(p, str) and p.strip() for p in phrases):
            problems.append("TRIGGER_PHRASES must be a non-empty list of strings")
        if not has_run:
            problems.append("a function run(args) is required")
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_NAMES:
                    problems.append(f"forbidden call: {node.func.id}()")
                if isinstance(node.func, ast.Attribute) and node.func.attr in FORBIDDEN_ATTRS:
                    problems.append(f"forbidden call: .{node.func.attr}()")
        if problems:
            return False, "; ".join(problems), str(found.get("TOOL_NAME", ""))

        name = str(found["TOOL_NAME"])
        error = self._dry_run(code, name)
        if error:
            return False, error, name
        return True, "", name

    @staticmethod
    def _dry_run(code: str, name: str) -> str:
        """Import the module from a temp file and call run({'dry_run': True}) in a worker thread. '' means success."""
        outcome: Dict[str, str] = {}

        def work(path: Path) -> None:
            try:
                spec = importlib.util.spec_from_file_location(f"_dryrun_{name}", path)
                module = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
                spec.loader.exec_module(module)  # type: ignore[union-attr]
                result = module.run({"dry_run": True, "command": "", "text": ""})
                if not isinstance(result, str):
                    outcome["error"] = "run() must return a string"
            except Exception as exc:
                outcome["error"] = f"dry run raised {type(exc).__name__}: {exc}"

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / f"{name}.py"
            path.write_text(code, encoding="utf-8")
            thread = threading.Thread(target=work, args=(path,), daemon=True)
            thread.start()
            thread.join(10)
            if thread.is_alive():
                return "dry run timed out after 10 seconds"
        return outcome.get("error", "")

    def create_tool(self, request: str) -> str:
        """Ask the LLM for a new tool, validate it, show it, and (with approval) save it into a new version."""
        template = (config.BASE_DIR / "tools" / "_template.py").read_text(encoding="utf-8")
        existing = [t["name"] for t in self.tools]
        code, feedback = "", None
        for attempt in range(2):
            try:
                code = self.llm.generate_tool(request, template, existing, feedback)
            except LLMError as exc:
                return str(exc)
            ok, problems, name = self.validate_tool_code(code)
            # The generated code is always logged and shown BEFORE anything is saved.
            log.info("Generated tool code (attempt %d, valid=%s):\n%s", attempt + 1, ok, code)
            self.io.show(f"Generated tool code (attempt {attempt + 1}):\n{code}")
            if ok:
                break
            log.warning("Tool validation failed: %s", problems)
            self.io.show(f"Validation failed: {problems}")
            feedback = problems
        else:
            return "The new tool failed validation twice, sir. The code and the reasons are in the log."

        if name in existing:
            return f"I already have a tool called {name}, sir. I did not save the new one."
        if not self.io.confirm(f"I wrote a tool called {name.replace('_', ' ')}. "
                               "The code is in the log. Shall I save it into a new version?"):
            return "Understood, sir. I discarded the new tool."
        try:
            destination, number = self.new_version()
            tool_file = destination / "tools" / f"{name}.py"
            tool_file.write_text(code.rstrip() + "\n", encoding="utf-8")
            self._write_changelog(destination, number, [f"Added tool '{name}' ({tool_file.name}) for request: {request}"])
        except OSError as exc:
            log.error("Could not create new version: %s", exc)
            return "I couldn't create the new version folder, sir."
        log.info("Created %s with new tool %s", destination.name, name)
        return f"Update is ready in jarvis_v{number}. Replace the source folder when you are ready, sir."

    # ----------------------------------------------------- (c) safe update
    def new_version(self) -> Tuple[Path, int]:
        """Copy the whole project into versions/jarvis_v<N>. Never touches the running source or old versions."""
        config.VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
        numbers = [int(m.group(1)) for p in config.VERSIONS_DIR.iterdir()
                   if (m := re.fullmatch(r"jarvis_v(\d+)", p.name))]
        number = max(numbers + [1]) + 1
        destination = config.VERSIONS_DIR / f"jarvis_v{number}"
        shutil.copytree(
            config.BASE_DIR, destination,
            ignore=shutil.ignore_patterns("versions", "logs", "__pycache__", "*.pyc", ".env", ".git",
                                          "venv", ".venv", "build", "dist", "models", "*.spec"),
        )
        for folder in ("versions", "logs"):
            (destination / folder).mkdir(exist_ok=True)
        return destination, number

    @staticmethod
    def _write_changelog(destination: Path, number: int, entries: List[str]) -> None:
        changelog = destination / "CHANGELOG.txt"
        previous = changelog.read_text(encoding="utf-8") if changelog.exists() else ""
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        block = f"jarvis_v{number} - {stamp}\n" + "\n".join(f"  - {e}" for e in entries) + "\n\n"
        changelog.write_text(block + previous, encoding="utf-8")
